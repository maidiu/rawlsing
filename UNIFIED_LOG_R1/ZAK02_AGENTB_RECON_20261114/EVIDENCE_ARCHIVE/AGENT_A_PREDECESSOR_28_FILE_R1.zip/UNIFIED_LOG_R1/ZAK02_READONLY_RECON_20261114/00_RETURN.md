# 00_RETURN — ZAK-02 bounded read-only unified reconnaissance, 2026-11-14

**Disposition:** `ZAK02_UNIFIED_R1_READONLY_S1__HISTORICAL_OPEN_DISCOVERY__NO_ENGINEERING`.

**Source cuts:** selected original `9253064bc9423a0f0ccda4fbdea43c2f54f800c6`; protected PRE-MAIN `6a5c12f04323d74001f9632063ec907f4fc4468e`; prior ZAK-02 candidate PR #904 at `2030007c96cf2681f4aee6f3cb609d2648ec518b`; VMC-T1 R5 / six archive records PR #871 at `5827cdb74f6820c338b79db0c423e9e0dc88a992`. Exact source, blob, line and claim-level evidence is in `EVIDENCE.tsv`. Uploaded R1 standard itself is the common schema, not a permission expansion.

**1. Commission and identity accounting:** **9/9 named ZAK-02 MCR-C obligation IDs accounted**, **0/9 discharged by this read-only documentary pass**. Six inherited VMC-T1 noninverse identities recovered **6/6 by exact archive row**, but **0/6 proven native/same-grain inverse**. Original ZAK-02 TSV case-row census is **not imported as new T**; 13 selected historical source cases remain linked by prior return IDs, not falsely counted as 13 unique T. No independent receiver appointed.

**2. Historical discovery:** 12 **provisional substantive T**, covering selected V549b, F03, F08, V550J registry/pattern/association, V551, V551J, V552 and V552J. Historical T universe **OPEN DISCOVERY**. Historical sub-strata pre-Vozhd/Vozhd/Verkhovod/entire Dva/Trii/Chetiri/Long Memory and comprehensive output-driven omitted-T countersearch remain uncompleted. Original T denominator is not replaced by the 12 discoveries. Newly recovered source-specific information includes V549b missing-anchor comparator, independent J registry governance, VMC six candidate rows and M1 J analogue.

**3. Two-axis cross-domain coverage:** 45/144 domain cells received an actual bounded source/document/locator observation; of 144 total, **FOUND=30, UNRESOLVED=15, NOT_INSPECTED=99**; bounded NOT_FOUND=0 (no unjustified absence); no source/domain is silently blank. All results represent code/document inspection, not actual executed science.

**4. Mechanisms and first readers:** 20 S/M comparison edges recorded at S1, **{'CHANGED': 2, 'UNKNOWN': 2, 'SOURCE_RETAINED': 8, 'ANALOGOUS': 3, 'PARTIAL': 5}**. These are *comparison records*, not 20 proved preserved historical mechanisms. Current consumer code is located for V553 and issued C11 workloads, and existing J tests are located. **Qualifying current executed first-reader receipts: 0/12 substantive T**; no original-native executable effects were newly observed. `REVERSE_CONSUMERS.tsv` has 16 reader/modern-first rows; their grades are explicit.

**5. Evidence / independent closure:** 54 pinned claim-specific evidence IDs, 22 bounded source-search receipts, 12 T-level open unjoins and 48 old/new shape records. Source-only S1. Sourcefree M1 tests **defined but NOT_RUN**, no selected historical-native S2/S3, no source rights, no independent reviewer, no accepted original35 or whole machine. Engineering/science/authority verdicts: **ENGINEERING=S1 CODE-READ ONLY; SCIENTIFIC=BOUNDED HISTORICAL MECHANISMS/UNREVIEWED; AUTHORITY=NO NEW ADMISSION**.

## Strongest recovered claims and material disputes

- **Additional original historical T discoveries:** Single-answer top-code cohort associations and recursive V548 branch-node associations are separately substantive from literal presence/absence anchors; their selected output/reader and current same-grain lineage remain open (EV0051–EV0054).
- **New V550 cloud alternate and real source consumers:** V550 cloud engine pairs only jointly answered respondent-ID records, applies stricter bilateral semantic authority, chooses modal response pair and emits a different diagnostic shape; 3 non-test static V550 compiler callsites found. Not a same-grain V549b replacement (EV0044–EV0048).
- **V549b missing-anchor comparator:** literal 1/0 anchors, but False comparison mask can include missing anchor rows when candidate values observed; old likelihood/rank may change if a current implementation filters such rows (EV0001, EV0004). Conditional reporter unbound-name branch remains source-visible, not executed (EV0002).
- **V552 overcount contradiction:** response count > respondent denominator produces BLOCKED coverage, while eligible scoring can still produce OBSERVED/ALLOW; live scientific permission is **held**, do not normalize away mismatch (EV0018–EV0021).
- **Modern M1 J recovered:** genuine six-state exact role authority vector and current test definitions; lacks demonstrated original respondent joint measurement, original packet genealogy and live M1 consumer at this site (EV0029–EV0032). This improves previous omitted modern-source reconnaissance, but is only partial functional overlap.
- **C4R1 reduced-carrier loss:** seven V551J grain classes not carried in the canonical V552J→V553 reduced interface, even though upstream original artifacts survive; modern M1 J cannot automatically close a separate consumer route (EV0016, EV0023, EV0026, EV0028).
- **False-friend F8 vs F08:** modern `pre553_service_f8_source_scope_binding.py` is an F8 source-applicability binder and does not implement the historical F08 manual-question override. Do not count it as F08 equivalence (EV0050).
- **V551 source recovery:** missing assumed `ddm_v551_contract.py` is a wrong locator; actual atom/adjudication producer recovered in `ddm_v551_atoms.py` (EV0049).
- **F09 historical vs current C11:** exact historical F1 routing executable identity was **not proved** by archive record; modern C11 release validator and I03/I05 executor exist with actual static workload caller. No same-grain inverse asserted (EV0033–EV0036).
- **Six inherited noninverse records:** rows 15,46,58,88,185,217 of VMC-T1 fates archive located by PR #871 listing after indexed search false negatives; these contain mixed evidence classes and cannot be collapsed into six missing executable functions (EV0036–EV0041).

## Document inventory

- `SCOPE_CONTRACT.md` — two axes, denominator/source cuts, owner/rights and outside boundary.
- `HUMAN_STORY.md` — readable data journeys, case index, source limitations.
- `FINDINGS.tsv`, `OPERATION_TRACES.tsv`, `AUTHORITY_USE.tsv`, `EVIDENCE.tsv`, `COVERAGE.tsv`, `UNJOINS.tsv`, `CHANGED_FILES.txt` — nine VMESTYE-facing core files (including this `00_RETURN.md`).
- `MECHANISM_RECONCILIATION.tsv`, `SOURCE_SEARCH_LOG.tsv`, `REVERSE_CONSUMERS.tsv`, `DATA_SHAPES.tsv` — four supplementary common registers.
- `CASES/ZAK02-T-0001.md` through `CASES/ZAK02-T-0010.md` — stand-alone T cases.
- `RECOVERED_CANDIDATE_FATES.md` — six original archive identities/row locators, no duplicate T.
- `MANIFEST.json` — actual file counts and content checksums for user-approved documentary intake.

**Boundary:** No repository changes, agents, tests, CI, execution or source/authority publication undertaken under the read-only correction. Prior engineering PR #1041 remains preserved, not promoted. The appointed VMESTYE/ZL-15 receiver alone can map this into accepted central atlas; unsupported equivalence remains OPEN.

**Required terminal sentence:** **Contract identities:** 9/9 accounted, 0/9 discharged; six fates 6/6 located. **Historical discovery:** 12 provisional, OPEN. **Applicable T×domain matrix:** 45/144 bounded observations, 15 unresolved and 99 not inspected. **Mechanism and consumer reconciliation:** 20 S/M edges (S1 comparisons only), 0/12 executed first readers. **Independent evidence grade:** S1 static/documentary, no independent reviewer. **Can use next for:** targeted issuer/source retrieval and a separately commissioned same-input first-reader/negative decision. **Cannot claim:** exhaustive original T discovery, S2/native operational parity, whole-machine conservation, selected authority, acceptance or permission to engineer.
