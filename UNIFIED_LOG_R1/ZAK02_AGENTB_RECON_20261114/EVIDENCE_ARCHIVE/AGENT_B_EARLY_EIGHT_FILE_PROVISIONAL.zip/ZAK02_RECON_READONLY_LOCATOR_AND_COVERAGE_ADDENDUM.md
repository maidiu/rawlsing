# ZAK-02 — Read-only unified-scope reconnaissance, provisional crosswalk + locator addendum

**Grade:** S1 direct source and inherited-documentary; no new historical code execution; source custody and present operational succession separated. **Not compliant-certified to the exact Unified Functional Reconnaissance Logging Standard R1** because its complete attached specification and canonical filename/column template were not available in this conversation. These are provisional joinable records, not the shared official ledger; source records and IDs are preserved.

## Governing user correction and new locator rule

All ZAK-02S building, source edits, CI runs, test development, branches, code repair and delegated engineering are withdrawn. This answer's new files are **local documentation exports only**, not repository engineering or publication. Search reported missing objects across the repository (tree, source bodies, code index, issue/PR bodies, relevant archive/version) before declaring absence. For unresolved objects, log all search surfaces, nearby clues, expected creation window, origin and unproved link in `ZAK02_RECON_LOCATOR_SEARCH_RECEIPTS.jsonl`.

## Territory and denominator

Historical: **specified tranche**, not all historical functions: V549b response/anchor/cloud; V550 F03 question-relation authority plus F08 manual overrides; V550J registry/same-person joint/eligible-and-answered denominators; V551 expected/actual directionality, atom, conditional and audit; V551J packet component certification, review and sidecar; V552 coverage/scoring/recomputation; V552J exact-scope structural handoff; six named inherited noninverse obligations. ZAK-02S's six-function execution subset does not remove original ZAK-02 accounting scope.

Modern: **bounded relevant territory**, not all modern Pyat/Sorok: source right/routing and C11, I03/I05 sourcefree empirical, M1 J role/certification, structural admission/Field Forge boundary, legacy retained V553 canonical/temporal adapters, selected issuance/consumer receipts. Any other stage is a relevant first-reader target only when the source makes that dependence concrete.

Existing original ZAK-02 file `HISTORIC_OPERATION_BEFORE_AFTER_NEGATIVE.tsv` (blob `f5cf47797597b1f905f20725b183f341b11aaf9d`) has **19 case IDs**, 13 historical operation cases and six exact inherited noninverse IDs. The local source-case ledger has **26 linked records**, including further V551/V551J/V552 and modern-reader addenda. This count is **not** an independent proof that every historically operative subfunction was discovered. The parent full-function denominator remains **NOT_EXHAUSTIVELY_CERTIFIED**.

## Inherited vs newly located results

- The six historic source modules remain byte-identical at protected commit `6a5c12f04323d74001f9632063ec907f4fc4468e` relative to pinned `9253064bc9423a0f0ccda4fbdea43c2f54f800c6`. Byte retention **does not** certify operational use.
- V549b build produces two Parquet targets, DuckDB tables and YAML; candidate/branch/anchor rules and reporter-specific 50th callback vulnerability belong to different submechanisms. No non-test consumer of the V549b output files was authenticated.
- F03's no-registry-row carry-through has a five-factor eligibility exception; F08 selects or refuses manual override conflicts. Current C11 authority checks are **related**, not proven same-grain successor implementations.
- V550J uses respondent identity joins and independent baseline/answered denominators; registry classifier `AssociationLaneRegistry` is a separate required source function. Current I03/I05 carries related exact respondent and risk/routing authority, but legacy output parity is not established.
- V551 directional-stamp audit, V551J review-sidecar, and V552 distribution-pressure recomputation have been positively located on the protected tree and now have separate case records. A review sidecar is not a certified relation runtime.
- Modern M1 J role/certification was *not* absent: protected `rawlsing_next/pre553_j_role_certification.py` (blob `d96e0b1230b38c59ba4fa7716d6dfd3b9fdbe889`) implements ordered authority-bound role vectors, named M1 channel, and six-state validator, with existing H01–H15 sourcefree tests (not rerun). HQD121/HQD122 differentiated adopted rule from implementation and actual issuer occupancy. Exact current non-test J first consumer unproved.
- Protected `rawlsing_next/pre553_carrier_execution.py` (blob `ee9b3af02bfca9238eb72ea45d94073d47769a07`) defines `CarrierNeutralResearchExecutor.execute_i03` and `execute_i05`; `rawlsing_next/pre553_issued_workload.py` (blob `28174766f61a15f7296f575d615462d6410cfcb6`) calls `execute_i03` and processes query and discovery Batch units. These are concrete code-level modern callers, not proof of a fully selected original35 live occupation or historical parity.
- C4R1's seven canonical handoff loss categories remain a scoped source-report finding. V552J's published structural candidate list also omits identities of nonselected competitors; canonical V553 compatibility alias is selected-only. This is a specific provenance reduction, not demonstrated wrong-science. The separate modern M1 J mechanism cannot be ruled absent merely from V552J carrier reduction.
- Temporal V553's latest-root precedence and separate fact selection require frozen-source contract comparison; no mixed-run execution demonstrated.

## Source recovery and unresolved estate

**Exactly six inherited noninverse IDs** are recovered as uniquely matched rows in `R1_CANDIDATE_FATES.tsv` (blob `5e3ed9d2ac3677b88ce77da60869f0578263ea77`, commit `5827cdb74f6820c338b79db0c423e9e0dc88a992`): T1-ZL03-ZL03-T11, T1-ZL07-TR-041, T1-ZL03-UNTRACED-ZL03-F16, T1-ZL05-ZL05-OP-003, T1-ZL08-ZL08-T-CODE-LMX-016, T1-ZL02-ZL02-T-F09_ROUTING. Their archived categories include source-grain operation, documentary/negative specification, and untraced semantic candidate, which are not interchangeable. No verified same-grain modern inverse is granted by the row's existence.

The originally absent literal `F09_ROUTING` code-index symbol was searched repository-wide. Related C11 logic **was found** in `rawlsing_next/pre553_c11_ingest.py::validate_c11_source_release` (L743) and `pre553_route_b_production.py::execute_route_b_production` (L495), but exact F09 routing selection equivalence and real original first reader remain **UNPROVED**. The J-role and CarrierNeutral class code-index searches produced **false negatives** corrected by protected Git tree plus direct file inspection. Treat code-index misses as locator uncertainty, not proof that a function is absent.

## Deliverable navigation (provisional; no official schema invented)

- `ZAK02_RECON_PROVISIONAL_MECHANISM_CASES.jsonl` — 26 case-level source/input/mechanism/output/current mapping records retaining original IDs.
- `ZAK02_RECON_PROVISIONAL_MECHANISM_LINKS.tsv` — row per currently described historical submechanism; explicit unproved differences where only a related modern function was found.
- `ZAK02_RECON_PROVISIONAL_TxDOMAIN_COVERAGE_MATRIX.tsv` — whole 26-case × nine-domain matrix, including nonrelevant rows and held same-grain/reader grades; **not exhaustive function discovery**.
- `ZAK02_RECON_PROVISIONAL_MODERN_OUTPUT_REVERSE_LEDGER.jsonl` — reader-to-upstream reverse navigation for both legacy and present outputs.
- `ZAK02_RECON_LOCATOR_SEARCH_RECEIPTS.jsonl` — new repository-wide locator rule receipts; search terms, expected path, recovered identity or surrounding clues/creation window.
- `ZAK02_RECON_PROVISIONAL_HUMAN_READABLE.md` — detailed 26-case readable inventory retained untouched.
- `ZAK02_RECON_PROVISIONAL_SCOPE_AND_PROVENANCE.json` — original scoped metadata, preserved untouched.

## Five distinct completion judgements

| Distinct judgment | Present best grade |
|---|---|
| Specific original tranche and nine inherited obligation identities stated | BOUNDED__SOURCE_GROUNDED |
| Original 19 case identities preserved and extra discovered mechanisms individually logged | DOCUMENTARY__YES |
| Complete enumeration of **every** historically operative submechanism in commissioned territory | **NOT_PROVED** |
| Modern implementation and named code-level readers identified | MULTIPLE POSITIVE S1 CALLSITES; **NOT EVERY SUCCESSION** |
| Complete same-grain functional conservation, real native production, independent receiving | **NOT_PROVED / NOT_EXECUTED HERE** |

## Decisions properly reserved for later

1. First read and apply the **actual R1 shared template** if it can be recovered/attached; transform these provisional records without changing source identities, and preserve every unresolved row.
2. Competent owners determine which of the seven canonical omissions or rival structural-fact identity list are actual present consumer requirements and whether accepted M1 J code already supplies them by a different route.
3. Source issuer and scientific owner decide same-grain function and selected-current-rule authority, particularly F03/F08, original35 J evidence, V552 score/coverage and V552J tie uniqueness.
4. Only by separate future commission could qualified host execution of original six families, original35 live first readers, or bounded source bug repair be authorized.

**No repository changes, new CI, tests, agent launches, implementation, source edits or protected integration were performed in this documentary pass.**
