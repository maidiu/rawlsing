# ZAK-02 — Read-only working reconstruction (NOT R1-standard conformant)

> **Notice:** This is provisional documentary evidence. The mandatory Unified Functional Reconnaissance Logging Standard R1 attachment was not accessible, and its required shared schema/filenames cannot be reconstructed responsibly. Do not merge, commit or treat these files as official common registers.

## Scope and proof

- Historical scope: original ZAK-02 **defined tranche**, not all historical functions. V549b, V550 F03/F08, V550J registry/pattern/risk set, V551/J, V552/J, and six fixed inherited noninverse candidates. ZAK-02S narrowed executable selection but did not erase the inherited historical duties.
- Modern scope: historical retained V550–V553 carrier/compilers **plus** corresponding current source-qualified C11/I03/I05, M1 J role/certification, and structural admission where relevant; not all PYAT/SOROK.
- Source grade: S1 source reading / older documentary reports. The existing tests/CI were inspected, not rerun. No native-original, first-reader production, scientific or authority certificate created.
- Protected source SHA: `6a5c12f04323d74001f9632063ec907f4fc4468e`; historical source pin: `9253064bc9423a0f0ccda4fbdea43c2f54f800c6`; original commission corrected blob `00402697f68d4c1364d59bcb059f9134b5d0c74a`; prior ZAK-02 operation ledger blob `f5cf47797597b1f905f20725b183f341b11aaf9d`.
- Bounded code-search: protected tree enumerated and exact module bodies inspected. GitHub code-search queries for V549b output filenames return the builder as sole match, but search-index nonappearance is not proof no live consumer; modern J implementation `pre553_j_role_certification.py` and existing tests directly inspected.

## Mechanism register

### `549B-COMP` — V549b anchor associations

**Inputs:** Respondent-level wide response matrix, respondent metadata, candidate item rows, question/structure registry, V548 branch trees; source/wave/country.

**Historical mechanisms:** single_answer: count threshold MIN_ANCHOR_N=50; top response codes; per-anchor 2-way response association Cramér V, inferred direction/confidence; answer_presence/absence: 0/1 presence masks, source-scoped candidate overlap and minimum valid N=50; branch_node: build V548 conditional masks, require MIN_BRANCH_N=25, then compare candidate responses; deduplicate/rank strongest 10 candidate rows per anchor;

**Historical outputs/purpose:** Question-response attitude-cloud summary and anchor Parquet, DuckDB tables and YAML report; experimental association/stratification proxy, not actor psychology.

**Refusal/falsifier:** Insufficient anchor/candidate N and metadata/stems excluded; reporter-enabled 50th path has distinct source bug (549B-PROGRESS-50).

**Modern mechanism:** V550 ddm_v550_clouds builds respondent-key pair clouds using alternate statistic max(NMI,Cramér V) and role/use guards; current I03 queries sealed C11 source facts with explicit universe/risk/authority; I05 composes governed conditional/joint results. No exact V549b branch/anchor input-output or current recipient equivalence established.

**Mechanism comparison:** respondent-key association = ANALOGOUS_NOT_EQUIVALENT (V550 and I03 can compute related respondent facts but input, authority, output and score contracts differ); V548 branch-node masks = UNPROVED_MODERN_SAME_GRAIN (I05 recursive/discovery paths exist but no old-to-current mask parity); output writer = SOURCE_RETAINED (Legacy writer still present; published current runs and first reader not shown)

**Reader boundary:** V549b main() writes Parquet/DuckDB after all anchor builders; downstream non-test reader unknown; I03 first reader is distinct current PYAT path.

**Unresolved:** Exact selected status of V549b builder, emitted source-native rows, and modern same-grain recipient unverified.

**Future reuse:** Retain old code as historical source/test oracle; do not duplicate a current empirical engine merely because output filenames differ.

**Source pins:** [data/ddm_build_copy/build_question_response_attitude_cloud_summary_v549b.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/build_question_response_attitude_cloud_summary_v549b.py#L421) / `bf874a95ea5172817b0d1bdf21b43600aac5cbfe`; [data/ddm_build_copy/ddm_v550_clouds.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v550_clouds.py) / `dfc878e87d984a1a3d7000a0c726bdc444f9945f`; [rawlsing_next/pre553_empirical_query.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_empirical_query.py) / `b72b469e6646b88e4e2ed4dbbf0f3c209557fd69`; [rawlsing_next/pre553_analytical_composition.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_analytical_composition.py) / `8d5d9dddbb5283b58a39b83a1d6f94d691a633f1`

---

### `549B-PROGRESS-50` — V549b progress instrumentation

**Inputs:** ProgressReporter, per-candidate enumeration, presence/branch/single-answer loops; PROGRESS_ITEM_STEP=50.

**Historical mechanisms:** Presence nested loop refers to never-defined answer_type on 50th item: source-level NameError if reached. Single-answer and branch reporters refer to cand_item_id before updating current loop value, potentially reporting the prior candidate. Outer presence reporter uses item_id/answer_code from earlier iterations or can encounter unbound state.

**Historical outputs/purpose:** Progress messages; on failing path no complete end-of-run summary/writer result.

**Refusal/falsifier:** A happy-path comparator without an enabled reporter does not disprove reporter failure; stale log identity is not proof associations are wrong.

**Modern mechanism:** Current I03/I05 do not use this reporter; old V550 cloud uses separate internal operations. Exact live producer selection remains unverified.

**Mechanism comparison:** reporting 50th candidate = HISTORICAL_SOURCE_DEFECT (unbound answer_type in presence path; stale item identifiers in other reporters); association statistics = NOT_DISPROVED (reporter exception does not establish incorrect statistical transformation in unaffected paths)

**Reader boundary:** V549b main() invokes reporter-enabled builders; no authenticated production failure/log or reader trace.

**Unresolved:** No actual run, no known frequency of conditions, no authorized repair or proof that this remains selected producer.

**Future reuse:** Narrow future owner decision: establish live relevance before authorizing maintenance; preserve scientific and output contract.

**Source pins:** [data/ddm_build_copy/build_question_response_attitude_cloud_summary_v549b.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/build_question_response_attitude_cloud_summary_v549b.py#L476) / `bf874a95ea5172817b0d1bdf21b43600aac5cbfe`; [data/ddm_build_copy/ddm_v550_clouds.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v550_clouds.py) / `dfc878e87d984a1a3d7000a0c726bdc444f9945f`

---

### `F03-QUC-PRESERVE` — V550 QRA authority

**Inputs:** One V550 bridge row with source, wave, country, question, var_code and incoming six structural coordinates; active question-relation authority index.

**Historical mechanisms:** Resolve exact selected question-relation authority. If no registry row, retain inbound six coordinates only when CERTIFIED role, RELATION_EVIDENCE, directional atom eligible, allowed_as_v551_relation_evidence and mapping COMPLETE (five conjuncts). On qualified no-match, mark QUC_AUTHORITY_PRESERVED_ACTIVE_REGISTRY_NO_MATCH and registry_match=False; do not treat that as independent issuer certification.

**Historical outputs/purpose:** Typed bridge dictionary with structural coordinates retained, coverage/pressure eligibility and authority-resolution statuses.

**Refusal/falsifier:** No registry row plus any failed predicate clears coordinates and eligibility, flags review; cannot carry stale structural state.

**Modern mechanism:** Current PYAT C11 and I03 require explicit source/universe/target-use authorities and typed negative responses; these are semantically related guards, not a proven direct inverse of QUC five-conjunct rule.

**Mechanism comparison:** five-conjunct inbound exception = RETAINED_HISTORIC_SOURCE (same blob at protected cut); current exact authority = MODERN_TYPED_ANALOGUE_NOT_PARITY (I03 release/query object semantics differ from V550 bridge)

**Reader boundary:** ddm_v550_bridge.py:1008 calls apply_question_relation_authority; present source first reader not authenticated.

**Unresolved:** Original issuer competence and actual applied V550 production output; present exact selected inverse absent.

**Future reuse:** Preserve admitted ZAK-01 F03 sourcefree witness; do not rerun 58 resources.

**Source pins:** [data/ddm_build_copy/ddm_v550_question_relation_authority.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v550_question_relation_authority.py#L727) / `62084cbed10a5975f79bd504bf4fb99025e4e64e`; [rawlsing_next/pre553_empirical_query.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_empirical_query.py) / `b72b469e6646b88e4e2ed4dbbf0f3c209557fd69`; [rawlsing_next/pre553_c11_repository.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_c11_repository.py) / `c0cd4e835ceb8fe6c6025ebeb89e32223427f955`

---

### `F03-DENY-ALLOW` — V550 QRA negative

**Inputs:** Same QRA no-match V550 row, allowed_as_v551_relation_evidence=False or structural_mapping_status=PARTIAL.

**Historical mechanisms:** Fail closed; clear six structure fields and source/relational polarities, set review and eligibility False. Restore only after all five inputs qualify; negative cannot preserve a false authoritative direction.

**Historical outputs/purpose:** Blocked V550 bridge row and manual-review metadata.

**Refusal/falsifier:** A certified label alone is insufficient; one denied permission is decisive.

**Modern mechanism:** Modern I03 negative fact distinguishes lawful nonpositive authority/release/target states but not a proven byte-semantic same input.

**Mechanism comparison:** deny missing authority = HISTORIC_SOURCE_RETAINED; current typed refusal = ANALOGOUS_UNPROVEN_EQUIVALENCE

**Reader boundary:** ddm_v550_bridge.py source caller; actual non-test first output unproved.

**Unresolved:** Independent issuer, historic execution and current same-grain effect.

**Future reuse:** Do not erase this negative when selecting modern carrier.

**Source pins:** [data/ddm_build_copy/ddm_v550_question_relation_authority.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v550_question_relation_authority.py#L751) / `62084cbed10a5975f79bd504bf4fb99025e4e64e`; [rawlsing_next/pre553_empirical_query.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_empirical_query.py) / `b72b469e6646b88e4e2ed4dbbf0f3c209557fd69`

---

### `F08-OVERRIDE-CONFLICT` — V550 manual override

**Inputs:** Question-use record and override table keyed by source, wave/canonical wave, variable and question identities; permitted use/role fields.

**Historical mechanisms:** _select_override tests multiple matching bases; refuses duplicate same-basis or distinct identity collisions. _apply_manual_override merges semantic-role hint, never promotes hard administrative design to relation evidence, and gates five high-risk uses. _apply_manual_designation_gate demands explicit high-risk allow where itinerary requires designation.

**Historical outputs/purpose:** Question-use contract row with role/use flags, basis, override lineage and refusal reason; bridge later reads.

**Refusal/falsifier:** Wrong wave, conflicting override identities, hard administrative design or missing manual designation must not grant relation evidence.

**Modern mechanism:** Modern C11/I03 have explicit source/target permissions, but no established same-grain manual-override selection inverse.

**Mechanism comparison:** override selection = RETAINED_HISTORICAL_SOURCE_NO_MODERN_PARITY; high-risk role guard = SIMILAR_AUTHORITY_IDEA_NOT_PROVED_EQUIVALENT

**Reader boundary:** _apply_manual_override is internal caller; V550 question-use builder consumes it, non-test production instance unknown.

**Unresolved:** Actual selected override table/source-wave and downstream applied consumer receipt.

**Future reuse:** Keep historical authority selection and denial; do not silently convert a current rule into a legacy override.

**Source pins:** [data/ddm_build_copy/ddm_v550_question_use.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v550_question_use.py#L1106) / `8d90a5116fd05b5db17e9b4645638a3aa6fc1131`; [rawlsing_next/pre553_empirical_query.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_empirical_query.py) / `b72b469e6646b88e4e2ed4dbbf0f3c209557fd69`; [rawlsing_next/pre553_c11_repository.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_c11_repository.py) / `c0cd4e835ceb8fe6c6025ebeb89e32223427f955`

---

### `J-PATTERN-MEMBERSHIP` — V550J registry & respondent patterns

**Inputs:** Governed family YAML/registry with P2/P3/source-lineage releases plus respondent-by-variable family_frame and question metadata.

**Historical mechanisms:** Validate bounded registry authority, reject discovery-only portability and duplicate configuration identities. Summarize each respondent only for actually answered applicable family items; compute ordered raw/semantic signatures and hashed pattern_id. Emit family boundary, item, position, relation, respondent membership, association, review and audit tables. Suppress associations when outside-family context unavailable or not authorized.

**Historical outputs/purpose:** 11 named V550J tables including joint_response_pattern_index, item_index, respondent_membership, signatures, association candidate/review/index and meaning summary.

**Refusal/falsifier:** P2 discovery alone cannot grant release; position/metadata rows cannot silently become association or relation evidence.

**Modern mechanism:** Modern pre553 J role vector requires exact per-component role authority and ordered IDs; I05 joint queries use exact universe/release/target topology. Historical family signatures/topology are not proven equivalent to M1 current representation.

**Mechanism comparison:** family authority registry = PRESERVED_HISTORIC_RULE_MODERN_DISTINCT_AUTHORITY; ordered respondent configuration = CURRENT_J_COMPONENT_IDENTITY_POSSIBLE_PARTIAL; same-family output table topology = NOT_PROVED_OR_REQUIRED_MODERN

**Reader boundary:** compile_v550j_joint_response_patterns.py invokes compile_v550j_family_tables; V551J compiler reads named pattern/index artifacts; real non-test current producer-reader success unproved.

**Unresolved:** Live governed family admissions, real respondent outputs and modern full input→output equivalence.

**Future reuse:** Retain role and component semantics; no reason to rebuild old full table topology.

**Source pins:** [data/ddm_build_copy/ddm_v550j_registry_contract.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v550j_registry_contract.py#L4925) / `c173b5cde96a912320540ed5b623c1242b30f671`; [data/ddm_build_copy/compile_v550j_joint_response_patterns.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/compile_v550j_joint_response_patterns.py) / `b42b00cadca6284ff99889116e8aebbc109e940e`; [data/ddm_build_copy/ddm_v550j_joint_patterns.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v550j_joint_patterns.py) / `644aab23675b26134040d1df5cc25538b613e163`; [rawlsing_next/pre553_j_role_certification.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_j_role_certification.py) / `d96e0b1230b38c59ba4fa7716d6dfd3b9fdbe889`; [rawlsing_next/pre553_analytical_composition.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_analytical_composition.py) / `8d5d9dddbb5283b58a39b83a1d6f94d691a633f1`

---

### `J-RISK-DENOMINATOR` — V550J same-person associations

**Inputs:** Respondent-ID membership matrix of patterns plus outside-family eligible context responses, weights and source/wave scoped variable IDs.

**Historical mechanisms:** Join on respondent_id_norm BEFORE grouping; separate true same-respondent overlap from merely co-present marginals. Separate baseline answered-variable denominator from in-pattern answered-variable risk set and weighted/unweighted counts. Apply support/authority/publication lanes and retain candidate/review diagnostic states.

**Historical outputs/purpose:** Association trace/index with numerator, risk/denominator basis, weighted counts, support and publication status; scientific claim is conditional respondent co-occurrence not causal disposition.

**Refusal/falsifier:** A false cross-person pairing is not a joint; all sampled respondents cannot replace target-variable answered risk set.

**Modern mechanism:** Modern I03 exact C11 query and I05 governed multibinding joint geometry are implemented; test/sourcefree scope documented in S04. No original35 data or exact old J denominator semantics parity demonstrated.

**Mechanism comparison:** same-person join = MODERN_ANALOGUE_SOURCEFREE_PRESENT_NOT_FULL_PARITY; answered-variable denominator = MODERN_RISK_SET_AVAILABLE_EXACT_COMPARISON_UNPROVED; weighted real-source = NATIVE_HOLD

**Reader boundary:** V551J compiler reads V550J artifacts; current I05 uses I03 empirical fact and exact conditioner query, no verified production first read.

**Unresolved:** Source-native all35 weight design, strict modern parity of risk/zero support and admitted consumer.

**Future reuse:** Do not commission a second generic J engine for an unproved gap.

**Source pins:** [data/ddm_build_copy/ddm_v550j_joint_patterns.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v550j_joint_patterns.py#L3426) / `644aab23675b26134040d1df5cc25538b613e163`; [rawlsing_next/pre553_empirical_query.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_empirical_query.py) / `b72b469e6646b88e4e2ed4dbbf0f3c209557fd69`; [rawlsing_next/pre553_analytical_composition.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_analytical_composition.py) / `8d5d9dddbb5283b58a39b83a1d6f94d691a633f1`

---

### `J551-COMPONENT-GATE` — V551J component packet

**Inputs:** V550J pattern/index and ordered item rows + V551 directional atoms + governed release/measurement contracts and target structure.

**Historical mechanisms:** Match V551 atom by exact component identifier; preserve ordered item rows and per-component vector, distribution/measurement hashes and denominator separation. _v2_packet_status requires >=2 relation components, refuses ambiguity, cross-contract conflicts and underqualified authority/measurement. Compiler certifies finalized packets with certify_v551j_v2_2_3 after candidate construction and writes certified/rejection/review artifacts.

**Historical outputs/purpose:** V551J candidate and component indexes, certified packet index, review/rejection audit, readiness report and packet contract hash.

**Refusal/falsifier:** Unresolved, blocked, cross-contract conflicting, or one-relation-component packet cannot become certified joint relation simply by scalar total.

**Modern mechanism:** Modern pre553_j_role_certification builds authority-bound role vector with exact ordered IDs and M1 named prerequisite, then six-state certification validator; historical packet executor topology intentionally sublated at documentary authority level (HQD122).

**Mechanism comparison:** role vocabulary = DOCUMENTARY_ADOPTED_AND_MODERN_CODE_IMPLEMENTED; ordered component contribution = MODERN_CODE_PRESENT; old packet physical topology = SUPERSEDED_AS_CONTRACT_NOT_PROVEN_FULL_BEHAVIORAL_PARITY; current first-reader production = UNPROVED

**Reader boundary:** Legacy compile_v551j_joint_evidence_packets.py certifies candidate; modern j_component_certification_validator plugs into M1 validator registry; actual selected non-test current invocation unknown.

**Unresolved:** Protect original component/denominator semantic grain, independent execution/real current authority load, and caller receipt.

**Future reuse:** Do not equate C4R1 canonical V553 carrier loss with absence of M1 J-role mechanism.

**Source pins:** [data/ddm_build_copy/ddm_v551j_packets.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v551j_packets.py#L1289) / `740bae4cfd4da7ed8aa2c9a2321c47f26ba7c7e8`; [data/ddm_build_copy/ddm_v551j_certification.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v551j_certification.py) / `21791659d4446b4c61097fdf6786f1bdae2aeeae`; [data/ddm_build_copy/compile_v551j_joint_evidence_packets.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/compile_v551j_joint_evidence_packets.py) / `2df97875172778c3f4616c0799c08667b57db407`; [rawlsing_next/pre553_j_role_certification.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_j_role_certification.py) / `d96e0b1230b38c59ba4fa7716d6dfd3b9fdbe889`; [rawlsing_next/tests/test_pre553_j_role_certification.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/tests/test_pre553_j_role_certification.py) / `23155e35acf2ec160054fe0899a349fc4d617f58`; [PYAT_CONTROL_ROOM/21_HQD122_J_ROLE_CERTIFICATION_SUCCESSION_ADOPTION.md](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/PYAT_CONTROL_ROOM/21_HQD122_J_ROLE_CERTIFICATION_SUCCESSION_ADOPTION.md) / `4ab47740740abf7dbc8a97f2a985cffab74f05ff`

---

### `V551-DIRECTIONAL` — V551 signed projection

**Inputs:** V550 V551 bridge distribution rows with source row hash, question-use authority and response semantic contract, raw direction/intensity and approved scale registry.

**Historical mechanisms:** _signed_projection interprets DIRECTIONAL_MAGNITUDE or ORDINAL_COORDINATE under exact authority geometry. Certify candidates only if semantic role, relation evidence, scale/direction and source/use permissions all pass. Produce signed relation atoms and nonpromotable audit; distribution coverage conserves promotable + rejected response mass.

**Historical outputs/purpose:** V551 directional candidate adjudication, signed atom index, coverage distribution and manifest; scientific purpose is qualified sign/intensity of relation responses.

**Refusal/falsifier:** Missing scale registry or invalid geometry blocks; unresolved direction/permission must not become signed pressure.

**Modern mechanism:** Modern I03 facts and I05 composed evidence do not automatically inherit historical signed projection. Modern M1 J premisses can reference qualified response semantics but direct same-grain scale authority comparison absent.

**Mechanism comparison:** scale-to-signed geometry = LEGACY_PRESENT_MODERN_EXACT_SUCCESSOR_UNRESOLVED; typed nonpromotion = MODERN_TYPED_ADMISSION_ANALOGUE_ONLY

**Reader boundary:** compile_v551_relation_evidence_atoms.py verifies bridge, runs adjudication and writes canonical artifacts; V552 compiler consumes V551 manifest. No non-test production read witnessed.

**Unresolved:** Source-native scale authority, all selected waves and cross-owner signed conversion equivalence.

**Future reuse:** Reuse historic measurement geometry as oracle only, no assumption sourcefree generalization is native.

**Source pins:** [data/ddm_build_copy/ddm_v551_atoms.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v551_atoms.py#L89) / `d07e9a0c8f552b9a53bb1e775281fdf9a68e29e0`; [data/ddm_build_copy/compile_v551_relation_evidence_atoms.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/compile_v551_relation_evidence_atoms.py) / `a054247590932e7ac02d0d08485e7c294b618d24`; [rawlsing_next/pre553_empirical_query.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_empirical_query.py) / `b72b469e6646b88e4e2ed4dbbf0f3c209557fd69`; [rawlsing_next/pre553_analytical_composition.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_analytical_composition.py) / `8d5d9dddbb5283b58a39b83a1d6f94d691a633f1`; [rawlsing_next/pre553_j_role_certification.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_j_role_certification.py) / `d96e0b1230b38c59ba4fa7716d6dfd3b9fdbe889`

---

### `V551-CONDITIONAL` — V551 conditional determinicity

**Inputs:** V551 bridge rows with conditional_determinicity_eligible and state/weighted support; optional V552 conditional table.

**Historical mechanisms:** Filter ineligible bridge candidates; construct conditional determinicity and exclusion audit with explicit reasons. At historic V552 build_v552_structural_outputs, optional conditional_determinicity is accepted but does not populate the corresponding status audit: that table is emitted empty.

**Historical outputs/purpose:** Conditional determinicity index and exclusion audit historically exist; V552 output audits include an empty conditional-determinicity status table.

**Refusal/falsifier:** Empty output must not be interpreted as proven absence of conditional structure or as zero contradiction.

**Modern mechanism:** Modern I03 conditional query and I05 composition have materially different query/risk-set machinery; no exact historical determinicity inverse.

**Mechanism comparison:** conditional typed eligibility = PRESENT_LEGACY_SOURCE; V552 downstream consumption = NO_EFFECT_SHOWN_IN_SELECTED_BUILDER; I03 conditional science = DIFFERENT_OPERATION_NOT_EQUAL

**Reader boundary:** V552 compiler optional conditional input; actual effect through source build not established.

**Unresolved:** Whether an alternative legitimate modern owner consumes equivalent conditional signal.

**Future reuse:** Do not build old empty-audit filler as causal evidence.

**Source pins:** [data/ddm_build_copy/ddm_v551_conditional.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v551_conditional.py#L157) / `359665297677553a33556ce65c2e3d76b60b2cc1`; [data/ddm_build_copy/ddm_v552_structural.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v552_structural.py) / `0df56d70cb3880dee723df00aea2207acd525260`; [rawlsing_next/pre553_empirical_query.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_empirical_query.py) / `b72b469e6646b88e4e2ed4dbbf0f3c209557fd69`; [rawlsing_next/pre553_analytical_composition.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_analytical_composition.py) / `8d5d9dddbb5283b58a39b83a1d6f94d691a633f1`

---

### `V552-COVERAGE-COMPLETE` — V552 coverage and signed pressure

**Inputs:** V551 certified directional atoms, coverage/adjudication frames, optional conditional determinicity and signed response components.

**Historical mechanisms:** _surface computes selected response-category total versus denominator; classifies COMPLETE/PARTIAL/OVERRUN independently. Observation index resolves signed component values and computes weighted score with direction and eligibility; OBSERVED_ZERO and OBSERVED_NONZERO distinct. Compiler verifies V551 manifest, validates V552 outputs, writes pressure facts, component/observation indexes and handoff.

**Historical outputs/purpose:** V552 pressure observation and fact indexes, structural channel/axis/target/facet summaries, temporal-key candidate and readiness; contradiction tensor exists but empty by construction.

**Refusal/falsifier:** Selected counts [2,2] over denominator 2 block coverage even though signed score may separately be OBSERVED/ALLOW; V552 source label ALLOW not automatically accepted downstream.

**Modern mechanism:** Modern structural admission in pre553_structural_admission.py qualifies source-typed empirical facts for structural effects, not a proven numerical inverse of legacy V552 score. Modern PYAT FF has independent issuer.

**Mechanism comparison:** coverage overrun diagnostic = LEGACY_RETAINED_AND_MODERN_UNPROVED_PARITY; signed weighted pressure score = HISTORICAL_RETAINED_SCIENCE_OWNER_REQUIRED; contradiction tensor = EMPTY_LEGACY_SCHEMA_NOT_COMPUTED_FUNCTION

**Reader boundary:** compile_v552_structural_ddm.py verifies and publishes V552; compile_v552j_structural_handoff.py is named first code reader, not authenticated runtime.

**Unresolved:** Real V551 data/permission, exact modern structural measure, valid downstream first read.

**Future reuse:** Do not infer empty tensor means zero contradiction or restart old scalar structure without scientific owner.

**Source pins:** [data/ddm_build_copy/ddm_v552_structural.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v552_structural.py#L130) / `0df56d70cb3880dee723df00aea2207acd525260`; [data/ddm_build_copy/compile_v552_structural_ddm.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/compile_v552_structural_ddm.py) / `0f9a28749ed5858a4814ec8e8fa6b53000f343de`; [rawlsing_next/pre553_structural_admission.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_structural_admission.py) / `fe8f706afbb5739d026846952681081b2937e9a8`; [rawlsing_next/pre553_empirical_query.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_empirical_query.py) / `b72b469e6646b88e4e2ed4dbbf0f3c209557fd69`

---

### `V552J-EQUAL-12-TIE` — V552J exact structural handoff

**Inputs:** V551J certified/review packets and V552 structural facts/temporal candidates with source/wave/country/shard and relation axis, target, facet, question attributes.

**Historical mechanisms:** _packet_structural_dimension_resolution filters exact scope, scores axis+target+facet+question as 4+3+3+2, sorts descending score then ascending fact ID, selects first. build_v552j_join checks producer/certified/observation permission; may issue probe-only ALLOW, while temporal-field remains false. Join row publishes selected fact and matched_fact_count; full candidate diagnostic set is omitted from canonical JOIN_COLUMNS, and V553 compatibility diagnostic alias is made from selected-only IDs.

**Historical outputs/purpose:** V552J structural join, join audit and V553 probe/handoff indexes, with permission and provenance reduced to chosen structural fact.

**Refusal/falsifier:** Two equally scoring same-scope facts can yield deterministic winner without semantic tie veto; selected-only diagnostic cannot reconstruct the rival identity.

**Modern mechanism:** V553 canonical validator checks frames/hashes/readiness; temporal module loads handoff and V552 fact index via a separate source selection. Modern M1 J may separately reconstruct component authority. No exact end-to-end successful real read authenticated.

**Mechanism comparison:** exact structural fact matching = HISTORIC_SOURCE_RETAINED; top-score tie semantics = DETERMINISTIC_NOT_SEMANTIC_UNIQUE; full candidate set diagnostic = CANONICAL_REDUCED_CARRIER_LOSES_IDS; downstream V553 temporal authority = PROBE_ONLY_NOT_AUTOMATIC_TEMPORAL

**Reader boundary:** compile_v552j_structural_handoff.py invokes join; ddm_v553_canonical_harmonization.py and ddm_v553_temporal_pressure.py named source-level readers (distinct paths), no production specific read.

**Unresolved:** Real equal-score occurrence, scientific uniqueness rule, and selected same-run V553 reader evidence.

**Future reuse:** Evaluate direct upstream reuse or narrow carrier supplement only after consumer requirement/authority proven.

**Source pins:** [data/ddm_build_copy/ddm_v552j_handoff.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v552j_handoff.py#L58) / `476e617370e8947ee1f38b0718243ecfc5ba9e5c`; [data/ddm_build_copy/compile_v552j_structural_handoff.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/compile_v552j_structural_handoff.py) / `a3e6bf17386b58beb0c14b2d79d9e4a9e405c300`; [data/ddm_build_copy/ddm_v553_canonical_harmonization.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v553_canonical_harmonization.py) / `1951ada5cb7453108939eae9af91fcbfc90ad517`; [data/ddm_build_copy/ddm_v553_temporal_pressure.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v553_temporal_pressure.py) / `5304b70f9f6522c5ae3893eff215c1d445681983`; [rawlsing_next/pre553_j_role_certification.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_j_role_certification.py) / `d96e0b1230b38c59ba4fa7716d6dfd3b9fdbe889`

---

### `V553-CONSUMER-BOUNDARY` — V552J→V553 differentiated consumer

**Inputs:** Published V552J join/input/handoff frames, manifests, structural facts; source/wave/country and selected run paths.

**Historical mechanisms:** Canonical V553 inspect validates declared artifacts, hashes, scope, input-handoff identity and row counts; it does not reload V551J component table. Temporal _wave_v552j_context can prefer discovered latest root over explicitly supplied existing root; can resolve additional artifact paths. Temporal key builder directly invokes V552J structural resolver and uses handoff and V552 structural fact files.

**Historical outputs/purpose:** Validated compatibility context and temporal keys, block lists, probe/temporal eligibility, harmonization artefacts.

**Refusal/falsifier:** Hash validation does not prove full scientific meaning; discovered-latest precedence may mix selection contexts but no observed misbinding shown.

**Modern mechanism:** Modern V553 these *are* reader implementations for the historical V552J carrier; they are not proof of an actual frozen production first read.

**Mechanism comparison:** canonical V553 reader = IMPLEMENTED_CODE; temporal source select = IMPLEMENTED_SOURCE_ORDER_WITH_UNTESTED_CONSEQUENCE; component envelope conserved = NOT_IN_CANONICAL_PATH_PER_C4R1

**Reader boundary:** V553 canonical harmonizer and temporal-pressure compiler functions; specific non-test executed artifact not established.

**Unresolved:** Exact read of contemporary selected runs, coherence of roots/manifests and scientific owner required.

**Future reuse:** Keep reader paths separate in source→consumer ledger.

**Source pins:** [data/ddm_build_copy/ddm_v552j_handoff.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v552j_handoff.py#L131) / `476e617370e8947ee1f38b0718243ecfc5ba9e5c`; [data/ddm_build_copy/ddm_v553_canonical_harmonization.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v553_canonical_harmonization.py) / `1951ada5cb7453108939eae9af91fcbfc90ad517`; [data/ddm_build_copy/ddm_v553_temporal_pressure.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v553_temporal_pressure.py) / `5304b70f9f6522c5ae3893eff215c1d445681983`

---

### `F03-DENY-PARTIAL` — V550 QRA partial-mapping denial

**Inputs:** V550 bridge record with no matching active QRA row and structural_mapping_status=PARTIAL even if other labels appear certified.

**Historical mechanisms:** Five-conjunct no-match preservation test fails on PARTIAL; _clear_structural_coordinates strips stale six IDs and directional/polarity state.

**Historical outputs/purpose:** Blocked/manual-review V550 bridge row; no current pressure eligibility.

**Refusal/falsifier:** PARTIAL never satisfies COMPLETE; retaining coordinates would be a false positive.

**Modern mechanism:** Modern I03 typed refusal exists but is not an exact same-grain partial-mapping replacement proof.

**Mechanism comparison:** partial mapping hard denial = RETAINED_HISTORICAL_SOURCE; modern denial correspondence = UNPROVED

**Reader boundary:** ddm_v550_bridge.py code caller; actual production non-test reader unproved.

**Unresolved:** Native original effect/reader, specific current rule required by selected authority.

**Future reuse:** Preserve this independent negative identity, distinct from the allowed_use=false case.

**Source pins:** [data/ddm_build_copy/ddm_v550_question_relation_authority.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v550_question_relation_authority.py#L751) / `62084cbed10a5975f79bd504bf4fb99025e4e64e`; [rawlsing_next/pre553_empirical_query.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_empirical_query.py) / `b72b469e6646b88e4e2ed4dbbf0f3c209557fd69`

---

### `V552-COVERAGE-BLOCKED` — V552 category overcount refusal

**Inputs:** Selected response-category counts [2,2] and denominator 2; V551 signed components and coverage/adjudication.

**Historical mechanisms:** _surface sums selected categories to 4/2 and flags BLOCKED_RESPONSE_CATEGORY_COUNT_EXCEEDS_DENOMINATOR with coverage 2.

**Historical outputs/purpose:** Coverage status and associated measurement audit; not a proven current signed score refusal.

**Refusal/falsifier:** Never collapse blocked response coverage into COMPLETE or infer zero contradiction.

**Modern mechanism:** Modern structural admission has separate empirical typed validity; exact overcount check correspondence unproved.

**Mechanism comparison:** category overcount diagnostic = SOURCE_RETAINED; modern overcount refusal = UNPROVED

**Reader boundary:** V552 compiler and V552J bridge code callsites exist; no specific real full publisher acceptance witness.

**Unresolved:** Actual producer validation and modern scientific rule/consumer.

**Future reuse:** Separate this coverage negative from score permission, as the old source does.

**Source pins:** [data/ddm_build_copy/ddm_v552_structural.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v552_structural.py#L130) / `0df56d70cb3880dee723df00aea2207acd525260`; [rawlsing_next/pre553_structural_admission.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_structural_admission.py) / `fe8f706afbb5739d026846952681081b2937e9a8`

---

### `V552-SCORE-ALLOW-SEPARATE` — V552 independent signed score permission

**Inputs:** Signed V551 atom distribution with approved components, possibly overcounted category-surface diagnostic.

**Historical mechanisms:** _surface coverage flag is computed separately from build_v552_pressure_observation_index scoring; source code may mark OBSERVED_ZERO/NONZERO and score ALLOW on a numerical observation. Compiler independently applies downstream permission and validation before writing a publishable artifact.

**Historical outputs/purpose:** Signed weighted score, observation status, pressure permission, separately typed coverage debt and publication state.

**Refusal/falsifier:** Score ALLOW is not automatic proof of downstream acceptance or scientifically valid overcount; diagnostic BLOCKED is not automatic score DENY.

**Modern mechanism:** Current structural admission evaluates different exact empirical/authority contracts and may refuse; no direct old permission-to-current parity.

**Mechanism comparison:** score-vs-coverage separation = LEGACY_PRESENT; present downstream permission = UNPROVED_SAME_GRAIN

**Reader boundary:** V552 compiler validates and V552J requires producer ALLOW; observed native release first read unproved.

**Unresolved:** Need actual selected producer rule/science and non-test consumer receipt.

**Future reuse:** Preserve independent score permission identity without promoting the historical score.

**Source pins:** [data/ddm_build_copy/ddm_v552_structural.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v552_structural.py#L159) / `0df56d70cb3880dee723df00aea2207acd525260`; [data/ddm_build_copy/compile_v552_structural_ddm.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/compile_v552_structural_ddm.py) / `0f9a28749ed5858a4814ec8e8fa6b53000f343de`; [rawlsing_next/pre553_structural_admission.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_structural_admission.py) / `fe8f706afbb5739d026846952681081b2937e9a8`

---

### `ZAK02-ADDENDUM-V550J-LANE-REGISTRY` — V550J association lane registry

**Inputs:** Association-lane registry YAML: source/wave/country and exact or pattern var_code rules with authority/publishability.

**Historical mechanisms:** AssociationLaneRegistry loads and validates nonempty rule IDs/lanes/publishability. classify selects a source/wave/country/var-specific lane, with typed registry missing/invalid/ambiguous states. V550J compiler enforces governed association publication constraints; discovery alone does not authorize response portability.

**Historical outputs/purpose:** Classified association lane and publication/authority basis; controls candidate association output, independent of respondent arithmetic.

**Refusal/falsifier:** Wrong rule, absent registry, incompatible source/wave, non-direct evidence must fail closed or remain diagnostic.

**Modern mechanism:** Modern I03 and M1 component role authority both use exact authority objects; not proof they reproduce lane-classifier semantics.

**Mechanism comparison:** selected source/wave lane = HISTORICAL_RETAINED_NO_EXACT_CURRENT_INVERSE; current role/use permission = ANALOGOUS_NOT_EQUIVALENT

**Reader boundary:** V550J compiler calls governed lane controls; non-test current producer authority and reader unverified.

**Unresolved:** Exact selected lane rule, current scope and competent source authority; possible bounded successor needed.

**Future reuse:** Historical authority selection must be inventoried separately from respondent counts.

**Source pins:** [data/ddm_build_copy/ddm_v550j_registry_classifier.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v550j_registry_classifier.py#L63) / `e90470f12dc6fb98d874af989854b83e8bc61067`; [data/ddm_build_copy/compile_v550j_joint_response_patterns.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/compile_v550j_joint_response_patterns.py) / `b42b00cadca6284ff99889116e8aebbc109e940e`; [rawlsing_next/pre553_empirical_query.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_empirical_query.py) / `b72b469e6646b88e4e2ed4dbbf0f3c209557fd69`; [rawlsing_next/pre553_j_role_certification.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_j_role_certification.py) / `d96e0b1230b38c59ba4fa7716d6dfd3b9fdbe889`

---

### `ZAK02-ADDENDUM-V551-DIRECTIONAL-STAMP` — V551 directionality stamp coverage

**Inputs:** Bridge rows expected to have certified directional applicability, direct relation response, substantive/nonmissing/non-special source.

**Historical mechanisms:** Derive expected rows; compare response_option_map_matched, certified response_direction and required intensity. Emit STAMPED versus MISSING_OR_INCOMPLETE_STAMP audit and per-run expected/stamped/missing counts.

**Historical outputs/purpose:** V551 stamp audit, coverage summary and provenance; ensures source-eligible directional response rows are represented.

**Refusal/falsifier:** Missing semantic direction or required intensity must not be reported as complete stamp coverage.

**Modern mechanism:** Modern I03 typed query/fact authority is different; no exact directional-stamp completeness successor traced.

**Mechanism comparison:** expected/stamped completeness = SOURCE_RETAINED; modern completeness inverse = UNPROVED

**Reader boundary:** V551 compiler writes stamp coverage to manifest; V552 reads admitted atoms, not necessarily stamp audit as a separate consumer.

**Unresolved:** Current actual first reader/complete native source coverage.

**Future reuse:** Preserve native eligible-vs-observed distinction without mandating historical physical audit format.

**Source pins:** [data/ddm_build_copy/ddm_v551_directionality_expectation.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v551_directionality_expectation.py#L27) / `5afad1f18c83f983e27ab73ca18b2a864b30a47d`; [data/ddm_build_copy/compile_v551_relation_evidence_atoms.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/compile_v551_relation_evidence_atoms.py) / `a054247590932e7ac02d0d08485e7c294b618d24`; [rawlsing_next/pre553_empirical_query.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_empirical_query.py) / `b72b469e6646b88e4e2ed4dbbf0f3c209557fd69`

---

### `ZAK02-ADDENDUM-V551J-REVIEW-SHADOW` — V551J weak-evidence review shadow

**Inputs:** V551J candidate trace and review surface, support/confidence/authority/directionality, optional V552 context frames.

**Historical mechanisms:** Join V552 context where keyed and construct review reasons/exclusion audit. build_v551j_reviewable_evidence_sidecar retains nonzero/evidence-backed non-certified packets without granting runtime rights. Excludes zero-support/diagnostic/blocked rows, preserves reason codes and review-only permissions.

**Historical outputs/purpose:** Review-only V551J evidence sidecar; avoids losing weak legitimate observations while refusing certification.

**Refusal/falsifier:** A reviewable shadow cannot be copied into certified/runtime-safe packet or interpreted as zero/complete scientific proof.

**Modern mechanism:** Modern M1 J validator returns BLOCKED/UNRESOLVED and negative basis, but a persisted weak-evidence sidecar same-grain first consumer is not established.

**Mechanism comparison:** typed weak evidence preservation = HISTORICAL_RETAINED_MODERN_PARTIAL_OR_UNKNOWN; no runtime promotion = MODERN_M1_TYPED_REFUSAL_PRESENT

**Reader boundary:** V551J review builder and sidecar source exists; canonical compiler may produce candidate/review indexes but exact sidecar reader is NOT_PROVED.

**Unresolved:** Source-owner-selected research consumer of the shadow and whether modern M1 determinant covers its scientific value.

**Future reuse:** Do not call absence of a sidecar function loss without a required first reader.

**Source pins:** [data/ddm_build_copy/ddm_v551j_review.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v551j_review.py#L429) / `ef06476f0fbb183ad665be21c664e2c49998fb94`; [data/ddm_build_copy/ddm_v551j_certification.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v551j_certification.py) / `21791659d4446b4c61097fdf6786f1bdae2aeeae`; [rawlsing_next/pre553_j_role_certification.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_j_role_certification.py) / `d96e0b1230b38c59ba4fa7716d6dfd3b9fdbe889`

---

### `ZAK02-ADDENDUM-V552-DISTRIBUTION-RECOMPUTE` — V552 independent measurement recomputation

**Inputs:** V551 input atom distribution plus V552 component group with signed direction/intensity, counts, weights and distribution IDs.

**Historical mechanisms:** recompute_v552_distribution_contract selects authorized weight basis (weighted/unweighted/numerator), normalizes response mass, recomputes signed aggregate. Independently classifies complete/partial/overcount surface and OBSERVED_ZERO/NONZERO. Returns pressure, polarization/entropy/dominance and measurement status, with typed not-computable cases.

**Historical outputs/purpose:** V552DistributionContractRecomputation evidence object, for independent measurement/coverage contract verification.

**Refusal/falsifier:** Missing authority geometry, invalid weight state, contradictory denominators or overcount must not silently certify original science.

**Modern mechanism:** Modern PYAT structural admission checks qualified facts/authority and is not an identical recomputation of V552 pressure values.

**Mechanism comparison:** measurement recomputation = HISTORICAL_RETAINED; same-quantity modern recomputation = UNKNOWN; downstream source evidence = NO_NEW_EXECUTION

**Reader boundary:** V552 v2.1.4 contract/validation machinery identified; specific actual compiler invocation and accepted production run require independent receipt.

**Unresolved:** No current same-grain independently qualified structural-pressure reader established.

**Future reuse:** Do not conflate initial observation score, contract recomputation and modern admission rights.

**Source pins:** [data/ddm_build_copy/ddm_v552_contract.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/ddm_v552_contract.py#L500) / `86463a840e46eae96276582a3d32f180fc680e30`; [data/ddm_build_copy/compile_v552_structural_ddm.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/data/ddm_build_copy/compile_v552_structural_ddm.py) / `0f9a28749ed5858a4814ec8e8fa6b53000f343de`; [rawlsing_next/pre553_structural_admission.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_structural_admission.py) / `fe8f706afbb5739d026846952681081b2937e9a8`; [rawlsing_next/pre553_empirical_query.py](https://github.com/maidiu/rawlsing/blob/6a5c12f04323d74001f9632063ec907f4fc4468e/rawlsing_next/pre553_empirical_query.py) / `b72b469e6646b88e4e2ed4dbbf0f3c209557fd69`

---

## Six inherited noninverse identities (no lost-function verdict)

| ID | Inherited claim | Present fate |
|---|---|---|
| `T1-ZL03-ZL03-T11` | V551 signed pressure→V552 structural/temporal candidate; empty contradiction tensor and conditional audit not zero observations | V552J→V553 not verified — **UNRESOLVED** |
| `T1-ZL07-TR-041` | D13 minimum-info routing/risk-set incidence and NOT lawful denominator | C11 current inverse unverified — **UNRESOLVED** |
| `T1-ZL03-UNTRACED-ZL03-F16` | B07 scalar only compatible complete unanimous nonempty vector; semantic DAG lineage | M1 component vector current possible, exact inverse unverified — **UNRESOLVED** |
| `T1-ZL05-ZL05-OP-003` | Dva V553 governed temporal delta intended architecture | V553 code exists, intended same-grain lineage unverified — **UNRESOLVED** |
| `T1-ZL08-ZL08-T-CODE-LMX-016` | validate_c11_source_release source/universe/routing/replay requirements | C11 current exact implementation/read unverified — **UNRESOLVED** |
| `T1-ZL02-ZL02-T-F09_ROUTING` | F09 source module/form/filter applicability and person risk-set | modern C11 routing selection unresolved — **UNRESOLVED** |

## Material proof gaps and bounded next decisions

1. Obtain the actual Unified Functional Reconnaissance Logging Standard R1 text and validate the mandatory shared schemas, identifier namespaces, and coverage-matrix requirements before converting these provisional records.
2. Qualify whether the retained V549b operation is still a selected producer; current I03/I05 is not presumed a true same-grain inverse.
3. Verify modern source-rights, wave/routing/risk and respondent-identity authority before calling modern joint and signed products the old functions’ exact successors.
4. Identify selected current M1 J role/certification producer and **non-test first reader**. Modern source code and static test cases are present; original35 native execution remains unproved.
5. Reconcile seven C4R1 V551J→V552J→V553 canonical-carrier reductions with the separately implemented M1 J role vector; avoid inferring universal loss or universal restoration.
6. For V552J, decide scientifically whether tied facts need uniqueness and diagnose how candidate identities are lost in canonical compatibility alias. Do not patch selector without owner ruling.
7. Check V553 canonical versus temporal reader run-root selection, selected source scope and actual non-test consumer receipts.
8. Resolve six inherited noninverse source-version/consumer identities individually with relevant owners; inherited candidate status is not absence of current capability.

## Activity declaration

Read-only source inspection only. No code or historical runtime execution, test harness build, branch, commit, PR, CI invocation, delegated agent or repository modification was performed for this report. Local outputs are documentary working copies, not project-adopted files.
