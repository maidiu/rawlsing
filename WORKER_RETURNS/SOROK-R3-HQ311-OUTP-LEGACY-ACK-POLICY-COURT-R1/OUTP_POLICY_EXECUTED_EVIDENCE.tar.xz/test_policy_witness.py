"""Policy non-entailment witnesses; tests apply only to these authored models."""
import pytest
from policy_witness import FixtureAdmission, DeliveryPolicy

@pytest.mark.parametrize('compat',[True,False])
def test_owner_shape_omitted_denied(compat):
    f=FixtureAdmission(compat)
    assert f.submit({'payload':'hi','worldOwner':'N'})=='DENY_ISSUER_SHAPED'
    assert f.v3_events==[]

@pytest.mark.parametrize('compat',[True,False])
def test_nested_owner_directive_denied(compat):
    f=FixtureAdmission(compat)
    assert f.submit({'payload':{'Memory_Delta':{'trust':7}}})=='DENY_ISSUER_SHAPED'

@pytest.mark.parametrize('compat',[True,False])
def test_unknown_mode_denied(compat):
    assert FixtureAdmission(compat).submit({'envelope_mode':'STRICT_TYPO','payload':'hello'})=='DENY_UNKNOWN_MODE'

def test_omission_compatible_vs_explicit_required_both_without_v3_event():
    a,b=FixtureAdmission(True),FixtureAdmission(False)
    assert a.submit({'payload':'hi'})=='FIXTURE_ONLY'
    assert b.submit({'payload':'hi'})=='DENY_EXPLICIT_MODE_REQUIRED'
    assert not a.v3_events and not b.v3_events

def test_explicit_legacy_fixture_cannot_become_v3():
    f=FixtureAdmission(False)
    assert f.submit({'envelope_mode':'SOURCEFREE_LEGACY_FIXTURE','payload':'hi'})=='FIXTURE_ONLY'
    assert not f.v3_events

@pytest.mark.parametrize('compat',[True,False])
def test_strict_adp019_not_mock_issued(compat):
    f=FixtureAdmission(compat)
    assert f.submit({'envelope_mode':'STRICT','payload':'hi'})=='HOLD_NO_ADP019_ISSUER'
    assert not f.v3_events

@pytest.mark.parametrize('need',[True,False])
def test_ack_before_admit_denied(need):
    assert not DeliveryPolicy(need).ack()

@pytest.mark.parametrize('need',[True,False])
def test_ack_after_admit_before_delivery_denied(need):
    d=DeliveryPolicy(need);d.admit()
    assert not d.ack()
    assert d.causal_events==1

@pytest.mark.parametrize('need',[True,False])
def test_authorized_offer_delivery_ack_never_claims_human_perception(need):
    d=DeliveryPolicy(need);d.admit()
    assert d.offer() and d.deliver() and d.ack()
    assert d.acked and not d.perceived and d.causal_events==1

@pytest.mark.parametrize('need',[True,False])
def test_revocation_blocks_ack(need):
    d=DeliveryPolicy(need);d.admit();d.offer();d.deliver()
    d.authorized=False
    assert not d.ack() and not d.perceived

def test_discriminating_delivery_without_offer():
    transport,opportunity=DeliveryPolicy(False),DeliveryPolicy(True)
    for d in (transport,opportunity):
        d.admit()
        assert d.deliver() and not d.offered
    assert transport.ack()
    assert not opportunity.ack()
    assert not transport.perceived and not opportunity.perceived

@pytest.mark.parametrize('need',[True,False])
def test_ack_retry_no_duplicate_event(need):
    d=DeliveryPolicy(need);d.admit();d.offer();d.deliver();d.ack();d.ack()
    assert d.causal_events==1
