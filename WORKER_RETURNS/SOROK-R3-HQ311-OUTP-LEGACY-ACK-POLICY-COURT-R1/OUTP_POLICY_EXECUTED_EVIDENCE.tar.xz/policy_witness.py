"""Synthetic policy countermodels, NOT pinned OUT4 implementation or adopted law."""
from dataclasses import dataclass, field

OWNER_KEYS = {'world_owner','memory_delta','client_perceived','admitted_event_id','cursor_after','admit','issuer','issuer_signature'}
def norm(x): return ''.join(c.lower() for c in str(x) if c.isalnum())
def directive(v):
    if isinstance(v, dict):
        return any(norm(k) in {norm(x) for x in OWNER_KEYS} or directive(x) for k,x in v.items())
    if isinstance(v, (tuple, list)): return any(directive(x) for x in v)
    return False

@dataclass
class FixtureAdmission:
    implicit_legacy: bool
    v3_events: list = field(default_factory=list)
    def submit(self, proposal):
        mode = proposal.get('envelope_mode','OMITTED')
        if directive(proposal): return 'DENY_ISSUER_SHAPED'
        if mode=='OMITTED': return 'FIXTURE_ONLY' if self.implicit_legacy else 'DENY_EXPLICIT_MODE_REQUIRED'
        if mode=='SOURCEFREE_LEGACY_FIXTURE': return 'FIXTURE_ONLY'
        if mode=='STRICT': return 'HOLD_NO_ADP019_ISSUER'
        return 'DENY_UNKNOWN_MODE'

@dataclass
class DeliveryPolicy:
    requires_opportunity: bool
    admitted: bool=False
    authorized: bool=True
    delivered: bool=False
    offered: bool=False
    acked: bool=False
    perceived: bool=False
    causal_events: int=0
    def admit(self):
        self.admitted=True
        self.causal_events+=1
    def offer(self):
        if not self.admitted or not self.authorized: return False
        self.offered=True
        return True
    def deliver(self):
        if not self.admitted or not self.authorized: return False
        self.delivered=True
        return True
    def ack(self):
        if not self.admitted or not self.authorized or not self.delivered: return False
        if self.requires_opportunity and not self.offered: return False
        self.acked=True
        return True
