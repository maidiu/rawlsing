"""R31 WP1 - source-free, actor-independent historical-world possibility consumer.

Purpose: a bounded transport/integration experiment, not an empirical estimator,
installed N9/N10E/N10W, Field Forge, a source/measurement grant or actor model.
The source-local conditional material is calculated in a lab adapter; a future
C1/N10E owner can replace that port only with independently accepted receipts.
No cross-family probabilistic join is defined or permitted.
"""
from __future__ import annotations
from copy import deepcopy
from datetime import date
from fractions import Fraction
from hashlib import sha256
import json
from typing import Any, Mapping

SCHEMA = 'PYAT_R31_WP1_SOURCEFREE_WORLD_CONSUMER@1'
FIXTURE_CEILING = 'TEST_ONLY__NO_EXTERNAL_SOURCE_OR_EMPIRICAL_MODEL_AUTHORITY'
FAMILIES = ('LAB_SOURCE_ALPHA', 'LAB_SOURCE_BETA')
CONDITION = 'X_ELIGIBLE_SERVICE'
OUTCOME = 'Y_REALIZED_POSSIBILITY'
MIN_SUPPORT = 8

class Refusal(ValueError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code

def freeze_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)

def digest(value: Any) -> str:
    return sha256(freeze_json(value).encode('utf-8')).hexdigest()

def reference(kind: str, material: Any) -> str:
    return 'WP1_TESTONLY_' + kind + ':' + digest(material)

def frac(f: Fraction) -> list[int]:
    return [f.numerator, f.denominator]

def fraction_pair(pair: list[int]) -> Fraction:
    if not isinstance(pair,list) or len(pair)!=2 or not all(type(x) is int for x in pair) or pair[1]<=0:
        raise Refusal('INVALID_EXACT_FRACTION')
    return Fraction(*pair)

def strict_date(value: Any) -> date:
    if not isinstance(value,str):
        raise Refusal('INVALID_CLOCK')
    try:
        parsed = date.fromisoformat(value)
        if value!=parsed.isoformat(): raise ValueError('noncanonical')
        return parsed
    except ValueError:
        raise Refusal('INVALID_CLOCK') from None

def _assert(condition: bool, code: str):
    if not condition:
        raise Refusal(code)


def sourcefree_inputs() -> list[dict]:
    """Entirely invented cells; no original survey microdata or national estimate."""
    shared = {'fixture_only':True, 'issued':False, 'source_grant':None,
              'issuer_signature':None, 'raw_source_sha256':None,
              'permission':FIXTURE_CEILING, 'population_overlap_claim':False,
              'observation_type':'INDEPENDENT_SOURCELOCAL_CROSS_SECTION'}
    return [
        {**shared,'family':'LAB_SOURCE_ALPHA','edition':'ALPHA_WAVE_TEST@1',
         'population':'ALPHA_SOURCE_ELIGIBLE_TEST_UNIVERSE','release':'2024-03-01',
         'observed':'2023-10','native_unit':'TEST_SURVEY_RECORD','native_denominator':'eligible_weight',
         'cells':{'X1Y1':36,'X1Y0':9,'X0Y1':12,'X0Y0':23},
         'specials':{'DK':9,'REFUSED':5,'NOT_ASKED':6,'SUPPRESSED':0},
         'eligible_weight':100,'tested_minority':'X0Y1'},
        {**shared,'family':'LAB_SOURCE_BETA','edition':'BETA_WAVE_TEST@3',
         'population':'BETA_DISTINCT_TEST_UNIVERSE','release':'2024-06-01',
         'observed':'2024-Q1','native_unit':'TEST_SURVEY_RECORD','native_denominator':'eligible_weight',
         'cells':{'X1Y1':20,'X1Y0':10,'X0Y1':5,'X0Y0':15},
         'specials':{'DK':6,'REFUSED':2,'NOT_ASKED':9,'SUPPRESSED':3},
         'eligible_weight':70,'tested_minority':'X0Y1'},
    ]

def _check_source(s: Mapping[str,Any]) -> None:
    _assert(isinstance(s,Mapping), 'INVALID_SOURCE_SHAPE')
    _assert(s.get('fixture_only') is True and s.get('issued') is False,'FORGED_ISSUANCE')
    _assert(all(s.get(x) is None for x in ('source_grant','issuer_signature','raw_source_sha256')),'FORGED_EXTERNAL_ISSUER_OR_BINARY')
    _assert(s.get('permission')==FIXTURE_CEILING,'PERMISSION_WIDENING')
    _assert(s.get('population_overlap_claim') is False and s.get('observation_type')=='INDEPENDENT_SOURCELOCAL_CROSS_SECTION', 'FORBIDDEN_SOURCE_POPULATION_JOIN')
    fam=s.get('family')
    _assert(fam in FAMILIES,'UNKNOWN_SOURCE_FAMILY')
    expected={'LAB_SOURCE_ALPHA':('ALPHA_WAVE_TEST@1','ALPHA_SOURCE_ELIGIBLE_TEST_UNIVERSE','2024-03-01','2023-10'),
              'LAB_SOURCE_BETA':('BETA_WAVE_TEST@3','BETA_DISTINCT_TEST_UNIVERSE','2024-06-01','2024-Q1')}[fam]
    _assert((s.get('edition'),s.get('population'),s.get('release'),s.get('observed'))==expected,'SOURCE_RELEASE_POPULATION_OR_CLOCK_SUBSTITUTION')
    strict_date(s['release'])
    _assert(s.get('native_unit')=='TEST_SURVEY_RECORD' and s.get('native_denominator')=='eligible_weight','NATIVE_UNIT_DENOMINATOR_MISMATCH')
    cells=s.get('cells');specials=s.get('specials')
    _assert(isinstance(cells,dict) and set(cells)=={'X1Y1','X1Y0','X0Y1','X0Y0'},'NATIVE_2X2_SHAPE')
    _assert(isinstance(specials,dict) and set(specials)=={'DK','REFUSED','NOT_ASKED','SUPPRESSED'},'NATIVE_SPECIAL_STATES_LOST')
    _assert(all(type(v) is int and v>=0 for v in list(cells.values())+list(specials.values())),'INVALID_COUNTS_OR_WEIGHTS')
    e=s.get('eligible_weight')
    _assert(type(e) is int and e>=0 and sum(cells.values())+sum(specials.values())==e,'ELIGIBLE_DENOMINATOR_MISMATCH')
    _assert(s.get('tested_minority')=='X0Y1','MINORITY_CELL_ERASED')

def _conditional(a:int,b:int,m:int) -> dict:
    """Within-source two-variable pair: observed fraction and ignorance bounds.

    For unobserved mass m, extremal assignments can change both conditional
    numerator and its conditioning risk set. This is a deliberately conservative
    partial-identification envelope, NOT sampling uncertainty or a causal effect.
    """
    if a+b == 0:
        return {'state':'VALID_EMPTY' if m==0 else 'UNKNOWN',
                'observed':None,'observed_denominator':0,'bound':[[0,1],[1,1]] if m else None,
                'missing_mass':m}
    lo=Fraction(a,a+b+m)
    hi=Fraction(a+m,a+b+m)
    return {'state':'PARTIAL_IDENTIFICATION_ONLY' if m else 'SUPPORTED',
            'observed':frac(Fraction(a,a+b)),
            'observed_denominator':a+b,'bound':[frac(lo),frac(hi)],
            'missing_mass':m,'support_state':'LOW_SUPPORT' if a+b<MIN_SUPPORT else 'SUPPORTED',
            'observed_zero':a==0}

def produce_field(raw: Mapping[str,Any]) -> dict:
    """Test-only C1/N10E input geometry; NOT an adopted C1/N10E producer."""
    s=deepcopy(dict(raw));_check_source(s)
    c=s['cells'];miss=sum(s['specials'].values())
    forward=_conditional(c['X1Y1'],c['X1Y0'],miss)
    reverse=_conditional(c['X1Y1'],c['X0Y1'],miss)
    field={'schema':'WP1_SOURCELOCAL_CONDITIONAL_FIELD_TEST@1','grade':FIXTURE_CEILING,
           'source_ref':reference('SOURCE',s),'source_record':s,
           'source_family':s['family'],'release':s['release'],'observed':s['observed'],
           'population':s['population'],'eligible_weight':s['eligible_weight'],
           'valid_weight':sum(c.values()),'native_cells':deepcopy(c),
           'specials':deepcopy(s['specials']),
           'x_to_y':forward, 'y_to_x':reverse,
           'minority':{'cell':'X0Y1','weight':c['X0Y1'],'state':'SUPPORTED' if c['X0Y1'] else 'OBSERVED_ZERO'},
           'cross_family_joint':'NOT_IDENTIFIED__NO_SHARED_RESPONDENT'}
    field['field_ref']=reference('FIELD',{k:v for k,v in field.items() if k!='field_ref'})
    return field

class TestOnlyRegistry:
    __test__ = False
    def __init__(self, sources: list[dict]):
        _assert(len(sources)==2, 'TWO_DISTINCT_SOURCES_REQUIRED')
        fields=[produce_field(x) for x in sources]
        _assert(set(x['source_family'] for x in fields)==set(FAMILIES),'TWO_DISTINCT_FAMILIES_REQUIRED')
        self._records={x['field_ref']:deepcopy(x) for x in fields}
        self._roles={x['source_family']:x['field_ref'] for x in fields}
        self._revoked=set()
    def refs(self)->dict:
        return deepcopy(self._roles)
    def revoke(self,ref:str):
        _assert(ref in self._records, 'UNKNOWN_FIELD_REF');self._revoked.add(ref)
    def dereference(self,ref:str,asof:str)->dict:
        ts=strict_date(asof)
        _assert(ref in self._records,'UNKNOWN_FIELD_REF')
        _assert(ref not in self._revoked,'SOURCE_REVOKED')
        doc=deepcopy(self._records[ref])
        _assert(reference('FIELD',{k:v for k,v in doc.items() if k!='field_ref'})==ref,'FIELD_CONTENT_REF_MISMATCH')
        _assert(doc['field_ref']==ref,'FIELD_REF_SUBSTITUTION')
        _check_source(doc['source_record'])
        _assert(doc['source_ref']==reference('SOURCE',doc['source_record']),'SOURCE_REF_MISMATCH')
        _assert(ts>=strict_date(doc['release']),'NOT_YET_PUBLISHED_AT_ASOF')
        _assert(doc['grade']==FIXTURE_CEILING,'ISSUANCE_OR_PERMISSION_LAUNDERING')
        _assert(doc['x_to_y']==_conditional(doc['native_cells']['X1Y1'],doc['native_cells']['X1Y0'],sum(doc['specials'].values())),'FORWARD_CALCULATION_MISMATCH')
        _assert(doc['y_to_x']==_conditional(doc['native_cells']['X1Y1'],doc['native_cells']['X0Y1'],sum(doc['specials'].values())),'REVERSE_CALCULATION_MISMATCH')
        return doc

# Frozen test-only structural/world rule semantics. Not Field Forge or N10W issuance.
RULES={
    'WORLD_A':{'world':'WORLD_A','effective':'2025-01-01','asof':'2025-04-01',
               'multipliers':{'LAB_SOURCE_ALPHA':[1,1],'LAB_SOURCE_BETA':[1,1]},
               'structural_circumstance':'LAB_ABSENCE_OF_SHIFT_AND_TRANSIT_RESTRICTIONS'},
    'WORLD_B':{'world':'WORLD_B','effective':'2025-07-01','asof':'2025-08-01',
               'multipliers':{'LAB_SOURCE_ALPHA':[1,2],'LAB_SOURCE_BETA':[3,4]},
               'structural_circumstance':'LAB_SHIFT_LIMIT_AND_TRANSIT_RESTRICTION'},
    'WORLD_B_INCOMPLETE':{'world':'WORLD_B_INCOMPLETE','effective':'2025-07-01','asof':'2025-08-01',
               'multipliers':{'LAB_SOURCE_ALPHA':[1,2]},
               'structural_circumstance':'LAB_MISSING_TRANSIT_RULE'},
}

def model_rule(name:str)->dict:
    _assert(name in RULES,'UNSUPPORTED_WORLD_RULE')
    r=deepcopy(RULES[name]);r['grade']='SOURCEFREE_TEST_ONLY_NON_EMPIRICAL_MODEL_RULE'
    r['allowed_claim']='CONTEXTUAL_OPPORTUNITY_BOUNDS_NOT_PERSONAL_PROBABILITY'
    r['rule_ref']=reference('RULE',{k:v for k,v in r.items() if k!='rule_ref'})
    return r

class HistoricalWorldPossibilityConsumer:
    """Named numerical consumer of *producer-owned* exact field refs.

    Not an N9 installed selector: externally selected exact refs, scoped dates
    and frozen test-only rule are required. Binds the same field refs it reads.
    """
    def __init__(self, registry: TestOnlyRegistry):self.registry=registry
    def consume(self,selected_refs:Mapping[str,str],world_name:str, *,
                asof:str|None=None,claimed_issuer:Any=None,join_requested:bool=False,
                personal_inference:bool=False,requested_complete:bool=False) -> dict:
        _assert(claimed_issuer is None,'FORGED_WORLD_OR_FIELD_ISSUER')
        _assert(not join_requested and not personal_inference,'CROSS_FAMILY_OR_PERSON_INFERENCE_FORBIDDEN')
        _assert(set(selected_refs)==set(FAMILIES) and len(set(selected_refs.values()))==2,'REQUIRED_EXACT_SOURCE_REFS')
        rule=model_rule(world_name)
        clock=rule['asof'] if asof is None else asof
        _assert(clock==rule['asof'],'WORLD_ASOF_SUBSTITUTION')
        _assert(strict_date(clock)>=strict_date(rule['effective']),'WORLD_EFFECTIVITY_VIOLATION')
        _assert(set(rule['multipliers'])==set(FAMILIES),'STRUCTURAL_RULE_INCOMPLETE_HOLD')
        _assert(not requested_complete,'CROSS_FAMILY_COMPLETENESS_FORBIDDEN')
        items=[]
        for fam in FAMILIES:
            fld=self.registry.dereference(selected_refs[fam],clock)
            _assert(fld['source_family']==fam,'SOURCE_ROLE_REF_SUBSTITUTION')
            rel=fld['x_to_y']
            _assert(rel['state'] in {'SUPPORTED','PARTIAL_IDENTIFICATION_ONLY'},'INSUFFICIENT_CONDITIONAL_SUPPORT')
            multiplier=fraction_pair(rule['multipliers'][fam]);_assert(0<=multiplier<=1,'INVALID_RULE_MULTIPLIER')
            observed=fraction_pair(rel['observed'])
            lower,upper=(fraction_pair(x) for x in rel['bound'])
            x={'family':fam,'exact_field_ref':fld['field_ref'],'source_ref':fld['source_ref'],
               'source_release':fld['release'],'source_observed':fld['observed'],
               'population':fld['population'],'native_eligible_weight':fld['eligible_weight'],
               'native_valid_weight':fld['valid_weight'],'native_specials':fld['specials'],
               'x_to_y':rel,'y_to_x':fld['y_to_x'],'minority':fld['minority'],
               'model_multiplier':frac(multiplier),'world_conditioned_observed':frac(observed*multiplier),
               'world_conditioned_bound':[frac(lower*multiplier),frac(upper*multiplier)],
               'state':'PARTIAL_IDENTIFICATION_ONLY','nonperson_scope':True}
            items.append(x)
        product={'schema':SCHEMA,'grade':FIXTURE_CEILING,
                 'world_rule':rule,'world_name':world_name,'asof':clock,
                 'state':'SOURCEFREE_LAB_POSITIVE__PARTIAL_IDENTIFICATION_ONLY',
                 'consumer':'HistoricalWorldPossibilityConsumer.consume',
                 'dependency_readset':[i['exact_field_ref'] for i in items],
                 'value_bearing_sources':items,
                 'two_source_joint_state':'NONCOMPARABLE__NO_SHARED_POPULATION_OR_RESPONDENT',
                 'pooled_person_probability':None,'world_population_probability':None,
                 'minority_preserved':True,'known_uncovered_mass':True,
                 'permissions':{'N9_OC05':False,'N10E_ACCEPTED_RECEIPT':False,'N10W_RULE':False,
                                'FF':False,'N11':False,'N12':False,'V3':False}}
        product['product_ref']=reference('PRODUCT',{k:v for k,v in product.items() if k!='product_ref'})
        return product

def compare(world_a:dict,world_b:dict)->dict:
    _assert(world_a['world_name']=='WORLD_A' and world_b['world_name']=='WORLD_B','NOT_REGISTERED_COUNTERWORLDS')
    _assert(world_a['dependency_readset']==world_b['dependency_readset'],'SOURCE_PROVENANCE_CHANGED_BETWEEN_WORLDS')
    delta=[]
    for left,right in zip(world_a['value_bearing_sources'],world_b['value_bearing_sources']):
        _assert(left['exact_field_ref']==right['exact_field_ref'],'SOURCE_MUTATION_MASQUERADING_AS_WORLD_EFFECT')
        a=fraction_pair(left['world_conditioned_observed']);b=fraction_pair(right['world_conditioned_observed'])
        a_low,a_hi=(fraction_pair(v) for v in left['world_conditioned_bound'])
        b_low,b_hi=(fraction_pair(v) for v in right['world_conditioned_bound'])
        # Same source-local latent parameter in both worlds; difference uses
        # registered coefficient difference, NOT independent bound subtraction.
        mult_diff=fraction_pair(left['model_multiplier'])-fraction_pair(right['model_multiplier'])
        srclo,srchi=(fraction_pair(v) for v in left['x_to_y']['bound'])
        delta.append({'family':left['family'],'field_ref':left['exact_field_ref'],
                      'world_A_minus_B_observed':frac(a-b),
                      'world_A_minus_B_bound':[frac(srclo*mult_diff),frac(srchi*mult_diff)],
                      'paired_same_source_latent':True,
                      'effect_type':'EXPLIBIF':'EXr)ect_type':'EXPLIORLDS')FACORTUNSTERHCOUODEL_RU_tyIMATE    retuobja':'WP1_SOURCELOINCTNSUMER@1__NOISONde':FIXTURE_CEILING,
           'sourc_minus_B_t['ex'value_beref']=referenpopulatiB_t['ex'valuebberef']=referenp
 'dependencynd(opy(snd(_observedent bound s_est_erson_known_unate':'(snd(                 'ounrobabilype':'world_porobabilgenerld['pop       retuobj['world_iabilference('PRODUCT'@1__NOISON',objturn r

classobjmpare(buiatioef']=rs)==2, 'T:t]):
     ne,claimedt:
        _assed =Registry):self.r(ee_inputs() -> list[ifree_inps else asof
   ==2, 'TW _assedfsy
  .f)->d);':'Histo=alWorldPossibilityConsumer.consumesergW _assa=cconsume',
     (oped ' and wortioncconsume',
     (oped ' and wB'turn {'state':'minus_B':apopulatiB':b,'world_iabi
  orld_a:a,b)}

i__(s'WOR___B'_ruein__' not coa256
imysa+b == 0mys.argv[1:]self._re([],['--oef']=r    fusal(SyoefmExit('uncover(wormd_b'turn {prcet(ps(value, sbuiatioef']=rs)),s=True, separatiund s=2,scii=False, a