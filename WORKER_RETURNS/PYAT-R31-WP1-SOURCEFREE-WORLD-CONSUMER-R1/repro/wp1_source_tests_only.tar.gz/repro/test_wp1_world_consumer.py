"""WP1 adversarial, independent-value and protocol tests; no respondent rows."""
import copy, json, os, subprocess, sys
from fractions import Fraction as F
from pathlib import Path
import pytest
from wp1_world_consumer import (Refusal,FAMILIES,sourcefree_inputs,produce_field,
    TestOnlyRegistry,HistoricalWorldPossibilityConsumer,model_rule,build_products,
    compare,_conditional,fraction_pair,reference)

@pytest.fixture
def inputs():return sourcefree_inputs()

def must(code,cb):
    with pytest.raises(Refusal) as e:cb()
    assert e.value.code==code

def test_actual_numeric_two_worlds_are_different_and_independent(inputs):
    p=build_products(inputs);a=p['world_A'];b=p['world_B'];d=p['comparison']
    assert a['world_name']=='WORLD_A' and b['world_name']=='WORLD_B'
    assert len(a['value_bearing_sources'])==len(b['value_bearing_sources'])==2
    assert len(set(a['dependency_readset']))==2
    assert a['dependency_readset']==b['dependency_readset']
    assert a['product_ref']!=b['product_ref']
    assert [fraction_pair(x['world_A_minus_B_observed']) for x in d['deltas']]==[F(2,5),F(1,6)]
    assert [tuple(map(fraction_pair,x['world_A_minus_B_bound'])) for x in d['deltas']]==[(F(18,65),F(28,65)),(F(1,10),F(1,5))]
    assert d['joint_delta'] is None and d['person_generation'] is False

@pytest.mark.parametrize('index,valid,eligible,for_num,for_den,rev_num,rev_den,missing',[
    (0,80,100,36,45,36,48,20),
    (1,50,70,20,30,20,25,20),
])
def test_independently_recomputed_from_source_local_cells(inputs,index,valid,eligible,for_num,for_den,rev_num,rev_den,missing):
    # This calculation intentionally does NOT call the adapter's conditional function.
    raw=inputs[index]; c=raw['cells']
    assert sum(c.values())==valid and sum(raw['specials'].values())==missing
    assert valid+missing==eligible
    product=produce_field(raw)
    assert product['valid_weight']==valid and product['eligible_weight']==eligible
    assert fraction_pair(product['x_to_y']['observed'])==F(for_num,for_den)
    assert fraction_pair(product['y_to_x']['observed'])==F(rev_num,rev_den)
    assert product['x_to_y']['observed_denominator']!=product['y_to_x']['observed_denominator']
    assert tuple(map(fraction_pair,product['x_to_y']['bound']))==(F(for_num,for_den+missing), F(for_num+missing,for_den+missing))
    assert product['minority']['weight']>0
    assert product['cross_family_joint']=='NOT_IDENTIFIED__NO_SHARED_RESPONDENT'

@pytest.mark.parametrize('family,lo,hi,observed',[
    ('LAB_SOURCE_ALPHA',F(36,65),F(56,65),F(4,5)),
    ('LAB_SOURCE_BETA',F(2,5),F(4,5),F(2,3)),
])
def test_bounded_partial_identification_not_complete(inputs,family,lo,hi,observed):
    item={x['family']:x for x in inputs}[family]
    conditional=produce_field(item)['x_to_y']
    assert conditional['state']=='PARTIAL_IDENTIFICATION_ONLY'
    assert fraction_pair(conditional['bound'][0])==lo
    assert fraction_pair(conditional['bound'][1])==hi
    assert fraction_pair(conditional['observed'])==observed

@pytest.mark.parametrize('name,expected',[
    ('WORLD_A',[F(4,5),F(2,3)]),
    ('WORLD_B',[F(2,5),F(1,2)]),
])
def test_named_consumer_really_dereferences_numbers(inputs,name,expected):
    r=TestOnlyRegistry(inputs)
    prod=HistoricalWorldPossibilityConsumer(r).consume(r.refs(),name)
    assert [fraction_pair(x['world_conditioned_observed']) for x in prod['value_bearing_sources']]==expected
    assert prod['dependency_readset']==[x['exact_field_ref'] for x in prod['value_bearing_sources']]
    assert [x['native_specials'] for x in prod['value_bearing_sources']]==[x['specials'] for x in inputs]

@pytest.mark.parametrize('index', [0,1])
def test_one_source_mutation_changes_only_that_source_reference_and_value(inputs,index):
    previous=build_products(inputs);revised=copy.deepcopy(inputs)
    c=revised[index]['cells'];c['X1Y1']+=1;c['X1Y0']-=1
    changed=build_products(revised)
    other=1-index
    for world in ('world_A','world_B'):
        x,y=previous[world]['value_bearing_sources'],changed[world]['value_bearing_sources']
        assert x[index]['exact_field_ref']!=y[index]['exact_field_ref']
        assert x[index]['world_conditioned_observed']!=y[index]['world_conditioned_observed']
        assert x[other]==y[other]
        assert x[other]['exact_field_ref']==y[other]['exact_field_ref']
        assert previous[world]['product_ref']!=changed[world]['product_ref']

def test_stale_ref_fails_against_new_producer_registry(inputs):
    old=TestOnlyRegistry(inputs).refs();changed=copy.deepcopy(inputs)
    changed[0]['cells']['X1Y1']+=1;changed[0]['cells']['X1Y0']-=1
    new=TestOnlyRegistry(changed)
    must('UNKNOWN_FIELD_REF',lambda:new.dereference(old[FAMILIES[0]],'2025-04-01'))
    assert old[FAMILIES[1]]==new.refs()[FAMILIES[1]]

def test_revoked_ref_binds_failed_source_not_other(inputs):
    r=TestOnlyRegistry(inputs);ref=r.refs();r.revoke(ref[FAMILIES[0]])
    must('SOURCE_REVOKED',lambda:HistoricalWorldPossibilityConsumer(r).consume(ref,'WORLD_A'))
    assert r.dereference(ref[FAMILIES[1]],'2025-04-01')['field_ref']==ref[FAMILIES[1]]

@pytest.mark.parametrize('field,val,code',[
    ('issued',True,'FORGED_ISSUANCE'),('source_grant','fake','FORGED_EXTERNAL_ISSUER_OR_BINARY'),
    ('issuer_signature','fake','FORGED_EXTERNAL_ISSUER_OR_BINARY'),
    ('raw_source_sha256','f'*64,'FORGED_EXTERNAL_ISSUER_OR_BINARY'),
    ('permission','GRANTED','PERMISSION_WIDENING'),
    ('population_overlap_claim',True,'FORBIDDEN_SOURCE_POPULATION_JOIN'),
    ('population','BETA_DISTINCT_TEST_UNIVERSE','SOURCE_RELEASE_POPULATION_OR_CLOCK_SUBSTITUTION'),
    ('release','2020-01-01','SOURCE_RELEASE_POPULATION_OR_CLOCK_SUBSTITUTION'),
    ('native_unit','PERSON','NATIVE_UNIT_DENOMINATOR_MISMATCH'),
    ('native_denominator','all_n','NATIVE_UNIT_DENOMINATOR_MISMATCH'),
])
def test_spoofed_source_use_or_native_contract_refused(inputs,field,val,code):
    inputs[0][field]=val
    must(code,lambda:TestOnlyRegistry(inputs))

def test_missingness_cannot_be_silently_dropped(inputs):
    inputs[0]['specials']['REFUSED']=0
    must('ELIGIBLE_DENOMINATOR_MISMATCH',lambda:TestOnlyRegistry(inputs))

def test_minority_is_preserved_across_worlds(inputs):
    p=build_products(inputs)
    for world in ('world_A','world_B'):
        assert [v['minority']['weight'] for v in p[world]['value_bearing_sources']]==[12,5]
        assert [v['native_eligible_weight'] for v in p[world]['value_bearing_sources']]==[100,70]
        assert p[world]['pooled_person_probability'] is None

def test_valid_empty_low_support_zero_unknown_states():
    assert _conditional(0,0,0)['state']=='VALID_EMPTY'
    assert _conditional(0,0,9)['state']=='UNKNOWN'
    assert _conditional(0,3,0)['observed_zero'] is True
    assert _conditional(0,3,0)['state']=='SUPPORTED'
    assert _conditional(1,2,0)['support_state']=='LOW_SUPPORT'
    assert _conditional(0,9,0)['observed']==[0,1]

def test_world_B_incomplete_is_typed_hold(inputs):
    r=TestOnlyRegistry(inputs)
    must('STRUCTURAL_RULE_INCOMPLETE_HOLD',lambda:HistoricalWorldPossibilityConsumer(r).consume(r.refs(),'WORLD_B_INCOMPLETE'))

def test_world_time_cannot_backdate_and_publication_clock_binding(inputs):
    r=TestOnlyRegistry(inputs);consumer=HistoricalWorldPossibilityConsumer(r)
    must('WORLD_ASOF_SUBSTITUTION',lambda:consumer.consume(r.refs(),'WORLD_A',asof='2024-01-01'))
    must('NOT_YET_PUBLISHED_AT_ASOF',lambda:r.dereference(r.refs()[FAMILIES[1]],'2024-05-31'))
    assert r.dereference(r.refs()[FAMILIES[1]],'2024-06-01')['release']=='2024-06-01'

def test_no_implicit_structural_or_actor_authority(inputs):
    r=TestOnlyRegistry(inputs);c=HistoricalWorldPossibilityConsumer(r)
    must('FORGED_WORLD_OR_FIELD_ISSUER',lambda:c.consume(r.refs(),'WORLD_A',claimed_issuer={'issuer':'world'}))
    must('CROSS_FAMILY_OR_PERSON_INFERENCE_FORBIDDEN',lambda:c.consume(r.refs(),'WORLD_A',join_requested=True))
    must('CROSS_FAMILY_OR_PERSON_INFERENCE_FORBIDDEN',lambda:c.consume(r.refs(),'WORLD_A',personal_inference=True))
    must('CROSS_FAMILY_COMPLETENESS_FORBIDDEN',lambda:c.consume(r.refs(),'WORLD_A',requested_complete=True))
    must('UNSUPPORTED_WORLD_RULE',lambda:c.consume(r.refs(),'WORLD_C'))
    assert all(v is False for v in c.consume(r.refs(),'WORLD_A')['permissions'].values())

def test_no_fabricated_joint_delta_and_world_effect_not_cohort_trend(inputs):
    p=build_products(inputs)
    assert p['comparison']['joint_delta'] is None
    assert all(x['effect_type']=='EXPLICIT_TESTONLY_RULE_COUNTERFACTUAL_NOT_HISTORICAL_ESTIMATE' for x in p['comparison']['deltas'])
    assert all(x['source_observed'] in ('2023-10','2024-Q1') for x in p['world_A']['value_bearing_sources'])
    assert p['world_A']['asof']=='2025-04-01' and p['world_B']['asof']=='2025-08-01'

def test_exact_product_hash_checked_and_untrusted_mutations_not_consumed(inputs):
    r=TestOnlyRegistry(inputs);ref=r.refs()[FAMILIES[0]]
    a=r.dereference(ref,'2025-04-01');a['x_to_y']['observed']=[999,1]
    # Defensive copy: a changed exported field cannot rewrite the registered source.
    b=r.dereference(ref,'2025-04-01')
    assert b['x_to_y']['observed']==[4,5]
    assert b['field_ref']==ref

def test_invalid_date_and_wrong_ref_fails_closed(inputs):
    r=TestOnlyRegistry(inputs);f=FAMILIES[0]
    must('INVALID_CLOCK',lambda:r.dereference(r.refs()[f],'not-a-date'))
    must('UNKNOWN_FIELD_REF',lambda:r.dereference('WP1_TESTONLY_FIELD:garbage','2025-04-01'))
    wrong=r.refs();wrong[FAMILIES[0]]=wrong[FAMILIES[1]]
    must('REQUIRED_EXACT_SOURCE_REFS',lambda:HistoricalWorldPossibilityConsumer(r).consume(wrong,'WORLD_A'))

def test_cold_process_equivalence_and_import_location(inputs):
    here=Path(__file__).resolve().parent
    cmd=[sys.executable,str(here/'wp1_world_consumer.py'),'--product']
    env={**os.environ,'PYTHONHASHSEED':'791'}
    a=subprocess.run(cmd,capture_output=True,text=True,check=True,env=env)
    b=subprocess.run(cmd,capture_output=True,text=True,check=True,env={**env,'PYTHONHASHSEED':'13'})
    assert json.loads(a.stdout)==json.loads(b.stdout)==build_products(inputs)
    import wp1_world_consumer as m
    assert Path(m.__file__).resolve()==(here/'wp1_world_consumer.py').resolve()
