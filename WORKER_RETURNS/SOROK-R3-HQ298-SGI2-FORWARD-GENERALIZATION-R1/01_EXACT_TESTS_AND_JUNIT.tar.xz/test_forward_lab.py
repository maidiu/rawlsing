"""GI2 independent predeclared held-out families; not S-GI1's 24-case suite."""
import json, pathlib
import pytest
from forward_lab import (run_case,mother_checkpoint,world_snapshot,forward_replay,
                         _father,two_dag_oracle,digest,independent_actions)
FAMILIES=json.loads(pathlib.Path(__file__).with_name('frozen_heldout_families.json').read_text())['families']
GOOD=[c for c in FAMILIES if c['expected']=='COMMITTED']

@pytest.mark.parametrize('case',FAMILIES,ids=lambda x:x['id'])
def test_frozen_family_outcome(case):
    r=run_case(case);assert r['status']==case['expected']
    assert r['mother_checkpoint_hash']==mother_checkpoint(case['mother'])['checkpoint_hash']
    assert r['cost_model_calls']==0 and r['population_posterior']=='NOT_ESTIMABLE'
    assert r['child_generated_events']==0 and r['birth']=='NOT_ISSUED'
    assert r['attempt_count']<=4

@pytest.mark.parametrize('case',FAMILIES,ids=lambda x:x['id'])
def test_future_shadow_byte_irrelevance(case):
    a=run_case(case,{'desired_child_personality':'A','desired_child_adversity':'X'})
    b=run_case(case,{'desired_child_personality':'B','desired_child_adversity':'Y','future_child_education':'OTHER'})
    assert digest(a)==digest(b)

@pytest.mark.parametrize('case',GOOD,ids=lambda x:x['id'])
def test_forward_causal_history_and_independent_life(case):
    r=run_case(case);assert r['selected_replay']['matched']
    assert r['selected_replay']['nonmother_projects']>=1
    assert r['selected_replay']['nonmother_relationships']>=1
    assert r['dag']['passes'] and not r['dag']['construction_leaked_into_causal']
    assert r['independent_actions']['work_collective'].startswith('TAKE')
    assert r['independent_actions']['friend'].startswith('REPAIR')
    assert not r['independent_actions']['mother_child_present_in_probes']
    assert r['relationship']['mother_view']!=r['relationship']['father_view']
    assert not r['relationship']['symmetry_inferred'] and not r['relationship']['parent_profile_average']

@pytest.mark.parametrize('case',GOOD,ids=lambda x:x['id'])
def test_exact_replay_across_fresh_calls(case):
    assert digest(run_case(case))==digest(run_case(case))

@pytest.mark.parametrize('case',FAMILIES,ids=lambda x:x['id'])
def test_no_world_marginal_promotes_to_dyad_posterior(case):
    assert world_snapshot(case['world'])['joint_dyad_evidence'] is False
    assert run_case(case)['population_posterior']=='NOT_ESTIMABLE'

def test_two_distinct_fathers_share_endpoint():
    c=FAMILIES[0];a,b=c['father_seeds']
    ha,hb=_father(a,c['route']),_father(b,c['route'])
    assert digest(ha)!=digest(hb)
    assert forward_replay(ha,c['route'],c['place'])['matched']
    assert forward_replay(hb,c['route'],c['place'])['matched']
    assert ha[3]['facts']['project']!=hb[3]['facts']['project'] or ha[4]['facts']['friend']!=hb[4]['facts']['friend']

def test_older_child_prior_history_survives():
    m=mother_checkpoint('M1');older=[x for x in m['history'] if x['kind'].startswith('OLDER_CHILD')]
    assert len(older)==3 and all(x['day']<m['checkpoint_day'] for x in older)
    assert older[-1]['facts']['hours_per_week']==22 and older[-1]['facts']['prior_link']=='PRIOR_PARTNER'
    assert run_case(FAMILIES[1])['mother_checkpoint_hash']==m['checkpoint_hash']

def test_world_asof_withheld_distinct_from_zero_probability():
    for i in (4,5):
        r=run_case(FAMILIES[i]);assert r['attempt_count']==0
        assert r['status'] in ('WORLD_EVIDENCE_UNKNOWN','WORLD_EVIDENCE_STALE')

def test_four_failed_attempts_recorded_and_no_commit():
    for i in (6,8):
        r=run_case(FAMILIES[i]);assert r['attempt_count']==4
        assert all(x['result']=='FAIL' for x in r['construction_attempts'])
        assert r['selected_history'] is None and r['status']=='HISTORY_SEARCH_EXHAUSTED'

def test_retry_success_after_two_failed_attempts():
    r=run_case(FAMILIES[7]);assert r['attempt_count']==3
    assert [x['result'] for x in r['construction_attempts']]==['FAIL','FAIL','PASS']

def test_endpoint_change_does_not_mutate_mother():
    c=dict(FAMILIES[0]);b=run_case(c)
    c['place']='OTHER_PLACE';c['father_seeds']=['a','b','c','d'];changed=run_case(c)
    assert b['mother_checkpoint_hash']==changed['mother_checkpoint_hash']
    assert changed['status']=='HISTORY_SEARCH_EXHAUSTED'

def test_bad_reverse_edge_detected():
    m=mother_checkpoint('M0')['history'];f=_father('xi','LOCAL')
    good=two_dag_oracle(m,f);assert good['passes']
    forged={**f[0],'parents':[f[-1]['event_id']]}
    bad=two_dag_oracle(m,[forged]+f[1:])
    assert not bad['passes'] and 'BAD_PARENT_ORDER' in bad['causal_inversions']

def test_unissued_conception_and_birth_distinct():
    r=run_case(FAMILIES[0]);assert r['conception']=='PENDING_NOT_ADMITTED_CONCEPTION'
    assert r['birth']=='NOT_ISSUED' and r['child_generated_events']==0

def test_no_read_future_to_satisfy_endpoint():
    x=run_case(FAMILIES[9],{'desired_child_personality':'fix father'})
    assert x['status']=='FUTURE_CHILD_INFORMATION_LEAK' and x['attempt_count']==0
