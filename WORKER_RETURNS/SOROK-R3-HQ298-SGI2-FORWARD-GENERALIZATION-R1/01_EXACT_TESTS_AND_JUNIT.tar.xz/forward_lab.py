"""GI2 independent held-out *source-free* forward-causality laboratory.

No S-GI1 import was recovered; this is a deliberately non-owner-grain surrogate.
No actor, source, biological-event or probability issuance. Provisional only.
"""
from __future__ import annotations
import hashlib
import json
from dataclasses import dataclass
from typing import Any

RULE='GI2_SOURCEFREE_INDEPENDENT_ORACLE@1.0_NOT_ADOPTED'
ROUTE_PLACE={'LOCAL':'WORKSHOP','MOBILITY':'TRANSIT','COMMUNITY':'COMMITTEE'}
FUTURE_KEYS=('desired_child_personality','desired_child_adversity','future_child_education')

def canonical(x:Any)->bytes:
    return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')

def digest(x:Any)->str:
    return hashlib.sha256(canonical(x)).hexdigest()

def event(actor:str,kind:str,day:int,parents:list[str],facts:dict)->dict:
    d={'actor':actor,'kind':kind,'day':day,'parents':parents,'facts':facts}
    return {'event_id':digest(d),'actor':actor,'kind':kind,'day':day,'parents':parents,'facts':facts}

def mother_checkpoint(variant:str)->dict:
    if variant not in ('M0','M1'):raise ValueError('unknown mother')
    actor='MOTHER_'+variant
    history=[]
    def add(kind,day,facts,parents=None):
        p=parents if parents is not None else ([history[-1]['event_id']] if history else [])
        history.append(event(actor,kind,day,p,facts))
    add('ROOT',0,{'region':'RIVERSIDE','family':'siblings'})
    add('WORK',10,{'place':'WORKSHOP','work_obligation':'craft_mentoring'})
    add('PROJECT',25,{'project':'apprentice_training','independent':True})
    if variant=='M1':
        add('OLDER_CHILD_CONCEPTION',30,{'child_id':'OLDER_01','relation':'PRIOR_PARTNER','boundary':'laboratory_only'})
        add('OLDER_CHILD_BIRTH',40,{'child_id':'OLDER_01','fact':'preexisting_synthetic_older_child'})
        add('OLDER_CHILD_CARE',49,{'child_id':'OLDER_01','hours_per_week':22,'obligation':'durable','prior_link':'PRIOR_PARTNER'})
    add('CHECKPOINT',50,{'immutable':True,'asof':50,'current_work':'WORKSHOP','older_child_count':int(variant=='M1')})
    return {'variant':variant,'history':history,'checkpoint_hash':digest(history),'checkpoint_day':50,'older_child':variant=='M1'}

def world_snapshot(name:str)->dict:
    if name not in ('W_LOCAL','W_OPEN','W_CLOSED','W_N9_MISSING','W_N9_STALE','W_NO_JOINT'):raise ValueError('unknown world')
    return {'world_id':name,'asof':35 if name=='W_N9_STALE' else 50,
            'evidence':'MISSING' if name=='W_N9_MISSING' else 'SYNTHETIC_DECLARED',
            'routes': [] if name=='W_CLOSED' else (['LOCAL','MOBILITY','COMMUNITY'] if name=='W_OPEN' else ['LOCAL']),
            'joint_dyad_evidence':False,'source_permission':'NONE','population_weight_permission':'NONE'}

def _father(seed:str,route:str,actor='FATHER_SYNTH')->list[dict]:
    # Independent history generated before route-specific meeting, in increasing time.
    events=[]
    def add(k,day,facts,parents=None):
        p=parents if parents is not None else ([events[-1]['event_id']] if events else [])
        events.append(event(actor,k,day,p,facts))
    alt=int(digest(seed)[:6],16)%3
    add('ROOT',1,{'place':['HILLS','PLAINS','VALLEY'][alt],'root_justified':True})
    add('SCHOOL',8,{'site':'COMMUNITY_TECHNICAL_SCHOOL'})
    add('WORK',15,{'occupation':['MECHANIC','MAKER','REPAIRER'][alt],'independent_of_mother':True})
    add('PROJECT',20,{'project':['PUMP','BRIDGE','TOOL_COOP'][alt],'beneficiary':'WORK_COLLECTIVE','durable_obligation':True})
    add('NONMOTHER_RELATION',24,{'friend':['FRIEND_K','FRIEND_J','FRIEND_L'][alt],'reciprocal_debt':True})
    add('PRACTICE',27,{'practice':'REPAIR_LEDGER','based_on':events[3]['event_id']},[events[3]['event_id']])
    add('ATTITUDE',30,{'attitude':'WORK_RECIPROCITY','based_on':events[4]['event_id']},[events[4]['event_id']])
    add('MEMORY',33,{'trace':'PROJECT_FAILURE_THEN_REPAIR','experienced':events[3]['event_id']},[events[3]['event_id']])
    add('ORGANISMIC',37,{'hand_injury':'recovered'})
    add('STRIVING',41,{'project':'independent_repair_bench','nonmother_goal':True})
    # The endpoint location is computed from a route-causing event, not pasted from the requested endpoint.
    if route=='LOCAL':add('COMMISIONED_REPAIR',47,{'arrives_at':'WORKSHOP','cause':'contract'},[events[2]['event_id']])
    elif route=='MOBILITY':add('TRAVEL',47,{'arrives_at':'TRANSIT','cause':'hired_move'},[events[2]['event_id']])
    elif route=='COMMUNITY':add('CALLOUT',47,{'arrives_at':'COMMITTEE','cause':'collective_project'},[events[3]['event_id']])
    add('STATE_OBSERVATION',48,{'derived_from_route_event':events[-1]['event_id']})
    return events

def forward_replay(history:list[dict],expect_route:str,expect_place:str)->dict:
    seen={};place=None; violations=[]; projects=[];relations=[]; attitudes=[]
    for e in history:  # intentionally input order, no repair sorting
        if e['event_id'] in seen:violations.append('DUPLICATE_EVENT_ID')
        if e['parents'] and any(p not in seen or seen[p]>=e['day'] for p in e['parents']):
            violations.append('ABSENT_OR_FUTURE_CAUSAL_PARENT')
        seen[e['event_id']]=e['day']
        if e['kind'] in ('COMMISIONED_REPAIR','TRAVEL','CALLOUT'):place=e['facts']['arrives_at']
        if e['kind']=='PROJECT':projects.append(e['facts'])
        if e['kind']=='NONMOTHER_RELATION':relations.append(e['facts'])
        if e['kind']=='ATTITUDE':attitudes.append(e['facts'])
        for fld in ('based_on','experienced'):
            if fld in e['facts'] and e['facts'][fld] not in seen:violations.append('PSYCHE_WITHOUT_PAST_EVENT')
    if history and history[-1]['kind']!='STATE_OBSERVATION':violations.append('NO_FORWARD_ENDPOINT_REPLAY')
    match=(place==expect_place==ROUTE_PLACE.get(expect_route))
    return {'status':'ENDPOINT_MATCH' if match and not violations else 'ENDPOINT_INFEASIBLE',
            'place':place,'matched':match and not violations,'violations':violations,
            'events_replayed':len(history),'nonmother_projects':len(projects),
            'nonmother_relationships':len(relations),'attitude_ancestry':len(attitudes)}

def two_dag_oracle(mother:list[dict],father:list[dict])->dict:
    causal=mother+father
    index={x['event_id']:x for x in causal};viol=[]
    for e in causal:
        for p in e['parents']:
            if p not in index or index[p]['day']>=e['day']:viol.append('BAD_PARENT_ORDER')
    construct=[{'from':'E_ENDPOINT','to':'H_HISTORY','type':'RETROSPECTIVE_CONSTRUCTION_DEPENDS_ON','causal_parent':False}]
    bad=[x for x in construct if x['causal_parent']]
    return {'construction_edges':construct,'causal_edges':sum(len(e['parents']) for e in causal),
            'causal_inversions':viol,'construction_leaked_into_causal':bool(bad),
            'passes':not viol and not bad}

def independent_actions(history:list[dict])->dict:
    project=next((e for e in history if e['kind']=='PROJECT'),None)
    rel=next((e for e in history if e['kind']=='NONMOTHER_RELATION'),None)
    return {'work_collective':'TAKE_REPAIR_ROTATION_AND_UPDATE_LEDGER' if project else 'REFUSE_NO_PROJECT',
            'friend':'REPAIR_TOOLS_AND_PARTIAL_DEBT_CREDIT' if rel else 'REFUSE_NO_RELATION',
            'basis':[x['event_id'] for x in (project,rel) if x],
            'mother_child_present_in_probes':False}

def run_case(case:dict,future_shadow:dict|None=None)->dict:
    # The hidden child-future compartment is intentionally not touched in this function.
    _=future_shadow  # not read or serialized; included only for byte-equivalence test
    m=mother_checkpoint(case['mother']);w=world_snapshot(case['world'])
    base={'case_id':case['id'],'rule':RULE,'mother_checkpoint_hash':m['checkpoint_hash'],
          'mother_older_child':m['older_child'],'world_id':w['world_id'],'world_asof':w['asof'],
          'source_permission':w['source_permission'],'population_posterior':'NOT_ESTIMABLE',
          'construction_attempts':[],'selected_history':None,'selected_replay':None,
          'independent_actions':None,'dag':None,'relationship':None,
          'conception':'PENDING_NOT_ADMITTED_CONCEPTION','birth':'NOT_ISSUED',
          'child_generated_events':0,'cost_model_calls':0}
    def terminal(t):base['status']=t;base['attempt_count']=len(base['construction_attempts']);return base
    if case.get('future_required'):return terminal('FUTURE_CHILD_INFORMATION_LEAK')
    if w['evidence']=='MISSING':return terminal('WORLD_EVIDENCE_UNKNOWN')
    if w['asof']<m['checkpoint_day']:return terminal('WORLD_EVIDENCE_STALE')
    if case['route'] not in w['routes']:return terminal('WORLD_ROUTE_UNAVAILABLE')
    # The endpoint constraint can guide a search but cannot rewrite mother/father histories.
    for index,seed in enumerate(case['father_seeds'][:4]):
        history=_father(seed,case['route'])
        replay=forward_replay(history,case['route'],case['place'])
        if index<case.get('fail_first',0):replay={**replay,'matched':False,'status':'ENDPOINT_INFEASIBLE','violations':['INDEPENDENT_HISTORY_PROOF_NOT_SATISFIED']}
        passed=replay['matched'] and replay['nonmother_projects'] and replay['nonmother_relationships']
        base['construction_attempts'].append({'index':index,'seed_label':seed,'history_hash':digest(history),
             'reason':'FORWARD_REPLAY_PASS' if passed else replay['status'],'result':'PASS' if passed else 'FAIL'})
        if passed:
            base['selected_history']=history;base['selected_replay']=replay
            base['independent_actions']=independent_actions(history)
            base['dag']=two_dag_oracle(m['history'],history)
            base['relationship']={'objective_meeting_site':replay['place'],'mother_view':'AFFECTIONATE','father_view':'CAUTIOUS',
                                  'symmetry_inferred':False,'parent_profile_average':False}
            break
    return terminal('COMMITTED' if base['selected_history'] is not None else 'HISTORY_SEARCH_EXHAUSTED')
