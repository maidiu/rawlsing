import copy
import json
from pathlib import Path

import pytest
from reference_oracle import classify, digest, run_reference, validate_native_receipt

HERE = Path(__file__).parent
FROZEN = json.loads((HERE / 'frozen_cases.json').read_text())
CASES = FROZEN['cases']
BY_ID = {x['case_id']: x for x in CASES}

@pytest.mark.parametrize('case', CASES, ids=lambda q:q['case_id'])
def test_independent_gate_and_receipt(case):
    status, reasons = classify(case)
    assert status == case['expected_gate'], (case['case_id'], reasons)
    assert set(case['expected_reasons_subset']).issubset(reasons)
    receipt = run_reference(case)
    assert receipt['status'] == status
    assert not validate_native_receipt(case, receipt)
    assert receipt['world_before'] == receipt['world_after']
    if status != 'COMMITTED':
        assert receipt['actor_state_before'] == receipt['actor_state_after']
        assert receipt['committed_effect_count'] == 0
        assert receipt['selected_action'] is None

@pytest.mark.parametrize('case', CASES, ids=lambda q:q['case_id'])
def test_named_rng_and_source_free_idempotent_reference_replay(case):
    assert run_reference(copy.deepcopy(case)) == run_reference(copy.deepcopy(case))
    altered = copy.deepcopy(case)
    altered['proposal']['rng_stream'] += ':different'
    assert run_reference(altered)['transaction_id'] != run_reference(case)['transaction_id']
    # randomness is receipted; the oracle does not construct a motive from a draw.
    assert classify(altered) == classify(case)

def test_corpus_frozen_coverage_and_reference_status():
    assert FROZEN['frozen_at_seal'] == 'f6e282f6aa1de77725da615e847cedbc15458b98'
    assert len(CASES) >= 16 and len(BY_ID) == len(CASES)
    assert len({c['family'] for c in CASES}) >= 10
    assert {'COMMITTED','DENIED','DEFERRED','VALID_EMPTY'} <= {c['expected_gate'] for c in CASES}
    assert all(c['world']['event']['known_thief'] is None for c in CASES)
    assert all(c['proposal']['probability_grade'] != 'EMPIRICALLY_VALIDATED' for c in CASES)
    assert all('candidate-CAN008-1' in c['rules'] for c in CASES)

def test_parent_history_counterfactual_is_not_one_event_to_psyche_rule():
    a,b=BY_ID['F01'],BY_ID['F02']
    assert a['world'] == b['world']
    assert a['proposal']['recruited_refs'] != b['proposal']['recruited_refs']
    assert a['proposal']['actor_id'] == b['proposal']['actor_id'] == 'caregiver'
    assert classify(a)[0] == classify(b)[0] == 'COMMITTED'

def test_same_parent_utterance_different_child_history_not_synthetic_mood():
    a,b=BY_ID['F03'],BY_ID['F04']
    assert a['world'] == b['world']
    assert a['proposal']['observed_refs'] == b['proposal']['observed_refs']
    assert a['proposal']['recruited_refs'] != b['proposal']['recruited_refs']
    assert a['proposal']['meaning_modes'] == b['proposal']['meaning_modes']
    assert a['proposal']['immediate_response'] == b['proposal']['immediate_response']
    assert run_reference(a)['transaction_id'] != run_reference(b)['transaction_id']

def test_contradictory_modes_not_collapsed_to_single_outcome():
    a,b=BY_ID['F05'],BY_ID['F06']
    assert set(a['proposal']['meaning_modes']) >= {'affect','proposition','practice'}
    assert set(b['proposal']['meaning_modes']) >= {'public','proposition','affect'}
    assert classify(a)[0] == classify(b)[0] == 'COMMITTED'

def test_prejudice_attribution_never_objective_fact():
    a,b=BY_ID['F07'], BY_ID['F09']
    assert 'peer-prejudice' in a['proposal']['claim_refs']
    assert classify(a)[0] == 'COMMITTED'
    assert classify(b)[1] == ['PEER_PREJUDICE_LAUNDERED_AS_FACT']
    assert a['world']['event']['known_thief'] is None

def test_parent_cannot_be_updated_by_child_ownership_shortcut():
    legal, illegal=BY_ID['F11'],BY_ID['F12']
    assert legal['proposal']['actor_id']=='caregiver'
    assert illegal['proposal']['actor_id']=='child'
    assert illegal['proposal']['effects'][0]['actor_id']=='caregiver'
    assert 'CROSS_ACTOR_DIRECT_WRITE' in classify(illegal)[1]

def test_reinterpretation_preserves_inaccessible_trace():
    good,bad=BY_ID['F13'],BY_ID['F14']
    assert 'child-trace' in good['proposal']['recruited_refs']
    assert 'child-trace' not in good['proposal']['observed_refs']
    assert 'INACCESSIBLE_TRACE_AS_CONSCIOUS_OBSERVATION' in classify(bad)[1]

def test_later_trajectory_does_not_force_repair():
    records=[BY_ID[k] for k in ('F15','F16','F17')]
    assert len({c['proposal']['effects'][0]['proposed_value'] if c['proposal']['effects'] else None for c in records})==3
    assert {classify(c)[0] for c in records}=={'COMMITTED','VALID_EMPTY'}
    assert all(c['world']['objective_ledger'][-1]=='encounter-2' for c in records)
    assert all(c['world']['event']['known_thief'] is None for c in records)

def test_other_person_and_user_request_have_no_preference_supremacy():
    other,user=BY_ID['F18'],BY_ID['F19']
    assert other['proposal']['actor_id']=='later_other'
    assert 'music' in next(a for a in other['actors'] if a['id']=='later_other')['projects']
    assert 'school-project' in next(a for a in user['actors'] if a['id']=='child')['projects']
    assert 'user-request' in user['proposal']['observed_refs']
    assert classify(user)[0]=='COMMITTED'
    assert BY_ID['F20']['expected_gate']=='DENIED'

def test_same_age_different_capacity_not_demographic_stereotype():
    a,b=BY_ID['F21'],BY_ID['F22']
    assert a['actors'][0]['age']==b['actors'][0]['age']
    assert 'source_attribution' in a['actors'][0]['capacities']
    assert 'source_attribution' not in b['actors'][0]['capacities']
    assert classify(a)[0]=='COMMITTED'
    assert classify(b)[1]==['CAPACITY_NOT_QUALIFIED']

def test_negative_owner_rollback_all_or_nothing():
    for k in ('F24','F25','F26','F27','F28','F29','F30','F31','F32','F33','F34','F35','F36'):
        c=BY_ID[k];r=run_reference(c)
        assert r['status'] in {'DENIED','DEFERRED'},k
        assert r['world_before']==r['world_after']
        assert r['actor_state_before']==r['actor_state_after']
        assert r['committed_effect_count']==0

def test_native_receipt_tamper_oracle_detects_scoped_corruption():
    c=BY_ID['F24']
    good=run_reference(c)
    for patch, reason in [({'status':'COMMITTED'},'STATUS_MISMATCH'),
                          ({'world_after':'forged'},'OBJECTIVE_LEDGER_REWRITTEN'),
                          ({'actor_state_after':'partial'},'FAILED_ATOMICITY'),
                          ({'committed_effect_count':1},'ILLEGAL_PARTIAL_EFFECT'),
                          ({'reasons':[]},'MISSING_DENIAL_REASON')]:
        bad={**good,**patch}
        assert reason in validate_native_receipt(c,bad)

def test_no_commit_or_denial_alters_objective_event_ledger():
    for c in CASES:
        q=copy.deepcopy(c);original=copy.deepcopy(q['world'])
        run_reference(q)
        assert q['world']==original

def test_mutation_ablation_discriminates_access_and_validity():
    good=copy.deepcopy(BY_ID['F07']);bad=copy.deepcopy(good)
    bad['proposal']['observed_refs'].append('caregiver-private')
    assert classify(good)[0]=='COMMITTED'
    assert 'ACTOR_ACCESS_VIOLATION' in classify(bad)[1]
    bad2=copy.deepcopy(good)
    bad2['proposal']['rule_ref']='unissued'
    assert 'UNREGISTERED_CAN008_RULE' in classify(bad2)[1]

# Native B1/P1 integration is deliberately NOT_RUN. Never skip or fake it as PASS.

@pytest.mark.parametrize('pair', [('F01','F02'),('F03','F04'),('F07','F08')])
def test_contrast_provenance_cannot_be_generic_script(pair):
    left,right=(BY_ID[k] for k in pair)
    a,b=run_reference(left),run_reference(right)
    assert a['transaction_id']!=b['transaction_id']
    assert 'CAUSAL_PROVENANCE_MISMATCH:recruited_source_refs' in validate_native_receipt(left,b) or \
           'STATUS_MISMATCH' in validate_native_receipt(left,b) or \
           'CAUSAL_PROVENANCE_MISMATCH:actor_id' in validate_native_receipt(left,b)

@pytest.mark.parametrize('key', ['actor_id','event_ref','recruited_source_refs','observed_source_refs','rule_ref','rng_stream','calibration'])
def test_provenance_counterfeit_fails(key):
    c=BY_ID['F03'];r=run_reference(c);r[key]='FORGED'
    assert 'CAUSAL_PROVENANCE_MISMATCH:'+key in validate_native_receipt(c,r)

def test_same_history_different_warranted_later_effects_do_not_impose_moral_ending():
    a,b=BY_ID['F15'],BY_ID['F16']
    assert a['proposal']['recruited_refs']==b['proposal']['recruited_refs']
    assert a['proposal']['effects'][0]['proposed_value']!=b['proposal']['effects'][0]['proposed_value']
    assert classify(a)[0]==classify(b)[0]=='COMMITTED'
    assert run_reference(a)['transaction_id']!=run_reference(b)['transaction_id']
