"""F1 frozen *reference* admissibility oracle, not a developmental simulator.

Checks typed causal provenance and owner constraints for proposed B-first receipts.
Never computes psychological choices, response probabilities, or canonical effects.
"""
from __future__ import annotations
import copy
import hashlib
import json
from typing import Any

OWNERS = {"mediator": "CAN011", "tension": "CAN011", "practice": "CAN011",
          "memory": "ADP016", "access": "ADP017", "striving": "CAN010",
          "relationship": "ADP015", "external": "ADP019"}
ALLOWED_OUTCOMES = {"COMMITTED", "VALID_EMPTY", "DENIED", "DEFERRED"}
VALID_GRADES = {"NONE", "UNVALIDATED_TEST_HYPOTHESIS"}


def digest(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def find_actor(case: dict, identity: str) -> dict | None:
    return next((a for a in case["actors"] if a["id"] == identity), None)


def classify(case: dict) -> tuple[str, list[str]]:
    """Return typed gate and all independently checkable rejection reasons.

    Does not select a response, force a distribution, or set a preferred ending.
    """
    reasons = []
    p = case["proposal"]
    event = case["world"]["event"]
    actor = find_actor(case, p["actor_id"])
    if actor is None:
        return "DENIED", ["ACTOR_UNKNOWN"]
    if p["event_ref"] != event["id"] or not event["admitted"]:
        reasons.append("NO_ADMITTED_EVENT")
    if event["time"] > p["clock"]:
        reasons.append("FUTURE_EVENT")
    if p["clock"] < actor["as_of"]:
        reasons.append("STALE_CLOCK")
    if p["prestate_hash"] != digest(actor["state"]):
        reasons.append("STALE_PRESTATE")
    if p["rule_ref"] not in case["rules"]:
        reasons.append("UNREGISTERED_CAN008_RULE")
    elif case["rules"][p["rule_ref"]]["owner"] != "CAN008":
        reasons.append("WRONG_CAN008_OWNER")
    if not case["permission"].get("actor_response", False):
        reasons.append("CAN008_PERMISSION_DENIED")
    missing_caps = set(p["requires_caps"]) - set(actor["capacities"])
    # Missing capacity is not a diagnosis; it makes this candidate inadmissible.
    if missing_caps:
        reasons.append("CAPACITY_NOT_QUALIFIED")
    if p["probability_grade"] not in VALID_GRADES:
        reasons.append("UNISSUED_PROBABILITY_AUTHORITY")
    if p["meaning_modes"] and any(m not in {"proposition", "affect", "practice", "public", "no_effect"} for m in p["meaning_modes"]):
        reasons.append("UNTYPED_INTERPRETATION")
    sources = {x["id"]: x for x in case["sources"]}
    for ref in p["observed_refs"]:
        s = sources.get(ref)
        if not s or (s["time"] > p["clock"]) or (s["visible_to"] not in ("public", p["actor_id"])):
            reasons.append("ACTOR_ACCESS_VIOLATION")
        elif s["kind"] == "trace":
            reasons.append("INACCESSIBLE_TRACE_AS_CONSCIOUS_OBSERVATION")
    for ref in p["recruited_refs"]:
        s = sources.get(ref)
        if not s or s["time"] > p["clock"]:
            reasons.append("INVALID_CAUSAL_SOURCE")
        elif s["visible_to"] not in ("public", p["actor_id"]):
            reasons.append("FOREIGN_PRIVATE_CAUSAL_SOURCE")
    if any(ref not in sources or sources[ref]["kind"] != "claim" for ref in p["claim_refs"]):
        reasons.append("UNATTRIBUTED_CLAIM")
    if any(ref in p["observed_refs"] for ref in p["recruited_refs"] if sources.get(ref, {}).get("kind") == "trace"):
        reasons.append("TRACE_EXPOSED")
    if p.get("objective_thief_group") is not None:
        reasons.append("PEER_PREJUDICE_LAUNDERED_AS_FACT")
    if p.get("scripted_by_age") or p.get("direct_demographic_edge"):
        reasons.append("UNLICENSED_PSYCHOLOGICAL_SHORTCUT")
    if p.get("renderer_writes_cause"):
        reasons.append("RENDERER_CAUSAL_FORGERY")
    for eff in p["effects"]:
        owner = OWNERS.get(eff["domain"])
        if owner != eff["owner"]:
            reasons.append("EFFECT_WRONG_OWNER")
        if eff["actor_id"] != p["actor_id"]:
            reasons.append("CROSS_ACTOR_DIRECT_WRITE")
        if not case["permission"].get(eff["owner"], False):
            reasons.append("FOREIGN_OWNER_PERMISSION_DENIED")
        if eff["rule_ref"] not in case["rules"] or case["rules"][eff["rule_ref"]]["owner"] != eff["owner"]:
            reasons.append("UNREGISTERED_EFFECT_RULE")
        if eff["prestate_hash"] != digest(actor["state"]):
            reasons.append("EFFECT_STALE_PRESTATE")
        if eff["as_of"] != p["clock"]:
            reasons.append("CROSS_OWNER_CLOCK_MISMATCH")
        if not set(eff["cause_refs"]).issubset(set(p["recruited_refs"]) | {event["id"]}):
            reasons.append("EFFECT_CAUSE_NOT_RECRUITED")
    if reasons:
        # Objective admitted event stays intact; receipt must fail closed.
        return "DENIED", sorted(set(reasons))
    if p["requires_owner_rule_missing"]:
        return "DEFERRED", ["OWNER_RULE_NOT_ISSUED"]
    if not p["effects"] and not p["immediate_response"]:
        return "VALID_EMPTY", []
    return "COMMITTED", []


def run_reference(case: dict) -> dict:
    """Simulation only of an atomic receipt gate using synthetic state.

    No actual CAN008/CAN011 runtime or psychology is imported.
    """
    snapshot = copy.deepcopy(case)
    status, reasons = classify(snapshot)
    proposal = snapshot["proposal"]
    actor = find_actor(snapshot, proposal["actor_id"])
    before_world = digest(snapshot["world"])
    before_actors = digest(snapshot["actors"])
    after = copy.deepcopy(snapshot)
    if status == "COMMITTED" and actor is not None:
        target = find_actor(after, actor["id"])
        for eff in proposal["effects"]:
            # This synthetic projection tests only absence of partial writes and scope.
            target["state"][eff["key"]] = eff["proposed_value"]
    receipt = {
        "status": status,
        "reasons": reasons,
        "event_ref": snapshot["world"]["event"]["id"],
        "actor_id": proposal["actor_id"],
        "recruited_source_refs": proposal["recruited_refs"],
        "observed_source_refs": proposal["observed_refs"],
        "rule_ref": proposal["rule_ref"],
        "rng_stream": proposal["rng_stream"],
        "world_before": before_world,
        "world_after": digest(after["world"]),
        "actor_state_before": before_actors,
        "actor_state_after": digest(after["actors"]),
        "selected_action": proposal["immediate_response"] if status == "COMMITTED" else None,
        "committed_effect_count": len(proposal["effects"]) if status == "COMMITTED" else 0,
        "transaction_id": digest({"case": snapshot, "named_rng": proposal["rng_stream"]}),
        "calibration": proposal["probability_grade"],
    }
    return receipt


def validate_native_receipt(case: dict, receipt: dict) -> list[str]:
    """Compare future B1 receipt at contract grain, not exact emotional outputs.

    Integration adapter is deliberately not bundled, so standalone tests never pass
    for native B1 by exercising this reference oracle.
    """
    errors = []
    status, reasons = classify(case)
    if status != receipt.get("status"):
        errors.append("STATUS_MISMATCH")
    if status == "DENIED" and not set(reasons).issubset(set(receipt.get("reasons", []))):
        errors.append("MISSING_DENIAL_REASON")
    # Actor-source and rule provenance must differ with the genuine causal inputs.
    for field, expected in (
        ("actor_id", case["proposal"]["actor_id"]),
        ("event_ref", case["world"]["event"]["id"]),
        ("recruited_source_refs", case["proposal"]["recruited_refs"]),
        ("observed_source_refs", case["proposal"]["observed_refs"]),
        ("rule_ref", case["proposal"]["rule_ref"]),
        ("rng_stream", case["proposal"]["rng_stream"]),
        ("calibration", case["proposal"]["probability_grade"]),
    ):
        if receipt.get(field) != expected:
            errors.append("CAUSAL_PROVENANCE_MISMATCH:" + field)
    if receipt.get("world_before") != receipt.get("world_after"):
        errors.append("OBJECTIVE_LEDGER_REWRITTEN")
    if status != "COMMITTED" and receipt.get("actor_state_before") != receipt.get("actor_state_after"):
        errors.append("FAILED_ATOMICITY")
    if status != "COMMITTED" and receipt.get("committed_effect_count", 0):
        errors.append("ILLEGAL_PARTIAL_EFFECT")
    if status == "COMMITTED" and case["proposal"]["effects"] and receipt.get("committed_effect_count") != len(case["proposal"]["effects"]):
        errors.append("NONATOMIC_OWNER_EFFECT")
    return errors
