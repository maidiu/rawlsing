"""Separate native integration gate. Requires an actual pinned B1 adapter.

Usage: F1_NATIVE_B1_ADAPTER='package.module:callable' python run_native_b1.py
The adapter must import actual B1, not reference_oracle, and return a receipt
with independently measured before/after hashes and provenance.
"""
import importlib
import json
import os
import sys
from pathlib import Path
from reference_oracle import validate_native_receipt

spec=os.environ.get('F1_NATIVE_B1_ADAPTER')
if not spec:
    print(json.dumps({'status':'NOT_RUN_AGAINST_B1','reason':'B1 implementation and pinned native adapter not provided','cases':0}))
    sys.exit(3)
if ':' not in spec:
    print(json.dumps({'status':'HOLD','reason':'Adapter must be module:callable'}))
    sys.exit(2)
modname,callname=spec.split(':',1)
fn=getattr(importlib.import_module(modname),callname)
if getattr(fn,'__module__',None)=='reference_oracle':
    raise RuntimeError('REFERENCE_ORACLE_IS_NOT_NATIVE_B1')
ca=json.loads((Path(__file__).parent/'frozen_cases.json').read_text())['cases']
fail=[]
for c in ca:
    r=fn(c)
    errors=validate_native_receipt(c,r)
    if errors:fail.append({'case_id':c['case_id'],'errors':errors})
result={'status':'RED' if fail else 'CONTRACT_PASS_PENDING_INDEPENDENT_I2', 'cases':len(ca),'failures':fail}
print(json.dumps(result,sort_keys=True))
sys.exit(1 if fail else 0)
