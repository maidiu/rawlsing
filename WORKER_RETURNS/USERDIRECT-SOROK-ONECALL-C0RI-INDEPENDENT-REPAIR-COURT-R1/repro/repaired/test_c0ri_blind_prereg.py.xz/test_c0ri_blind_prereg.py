"""C0RI Phase A independent blind hostiles; created BEFORE reading any C0R source.

These are SOURCEFREE mock boundary requirements, not actor/psychology rules.
Each test calls the exact ORIGINAL C0 public entrypoints to verify sensitivity.
Never depend on C0R author's fixtures or implementation assumptions. Original
failing outcomes are expected until a separately reviewed repair closes them.
"""
from __future__ import annotations
from copy import deepcopy
from pathlib import Path
import os, subprocess, sys
import pytest
import onecall_c0 as c


def single(action='OBSERVED_NEUTRAL', **kw):
    p=c.candidate(2020, 100, 'hostile', action, **kw)
    return p


def parsed_packet(p):
    state=c.initial_state(); inp=c.render_input(state,2020)
    _,packet=c.mocked_artifacts(inp)
    packet['candidates']=[p]
    return c.validate_packet(packet,inp)


def reject_outcome(fn):
    try:
        out=fn()
    except (AssertionError, ValueError, PermissionError, KeyError, RuntimeError, TypeError):
        return True
    if isinstance(out,tuple):
        return not bool(out[1])
    if isinstance(out,dict):
        return ('REFUS' in str(out).upper() or 'DENIED' in str(out).upper()
                or 'UNSUPPORTED' in str(out).upper() or 'DEFER' in str(out).upper())
    return False


def test_H01_source_swap_between_validation_and_append(monkeypatch):
    """Late source replacement must be detected even after packet validation."""
    original=c.apply_admitted
    replaced=[]
    def malicious_interleaving(state,p,year,rules):
        state['world']['source_ref']='UNISSUED_REPLACEMENT_BETWEEN_CHECK_AND_APPEND'
        replaced.append(p['id'])
        return original(state,p,year,rules)
    monkeypatch.setattr(c,'apply_admitted',malicious_interleaving)
    if reject_outcome(lambda:c.run()):
        return
    # Fail closed means no subsequent mock event committed under swapped source.
    out=c.run(); assert not replaced or not out['causal']['final_state']['events']


def test_H02_duplicate_event_restart_new_payload_no_replacement():
    state=c.initial_state()
    state['events'].append(dict(id=c.fact_id(2020,'practice'),year=2020,day=30,action='FORGED_HISTORICAL_ACTION'))
    assert reject_outcome(lambda:c.run(initial=state)) or len({x['id'] for x in c.run(initial=state)['causal']['final_state']['events']})==len(c.run(initial=state)['causal']['final_state']['events'])


def test_H03_unconstructed_independent_person_not_same_as_peer():
    state=c.initial_state();state['counterparts']['peer']['available']=True
    p=single('COUNTERPART_CONTACT',counterpart='ghost_person')
    rules={'licensed_objective_actions':['COUNTERPART_CONTACT']}
    assert c.evaluate(state,p,rules)!='ELIGIBLE_TEST_ONLY'


def test_H04_forged_event_issuer_not_admitted():
    assert reject_outcome(lambda:parsed_packet(single(external_issuer='FORGED_EXTERNAL_NOT_QUALIFIED')))


def test_H05_false_provider_provenance_not_permission():
    s=c.initial_state();inp=c.render_input(s,2020);_,pkt=c.mocked_artifacts(inp)
    pkt['model_version']='REAL_LLM_PROVIDER_CLAIM_NO_AUTHORITY'
    pkt['sampling_metadata']={'probability_grade':'SCIENTIFICALLY_CERTIFIED','random_draws':87}
    assert reject_outcome(lambda:c.validate_packet(pkt,inp))


def test_H06_noncausal_relevance_label_only_not_in_event_hash(monkeypatch):
    old=c.fixed_candidates
    def invoke(label):
        def f(year):
            rows=old(year)
            for r in rows:
                if r['id']=='routine':r['possible_relevance_domains']=[label]
            return rows
        monkeypatch.setattr(c,'fixed_candidates',f)
        return c.run()
    a=invoke('RECOGNIZED_LABEL'); b=invoke('UNRECOGNIZED_LABEL')
    assert a['causal']['final_state']['actor']==b['causal']['final_state']['actor']
    assert a['causal']['final_state']['world']==b['causal']['final_state']['world']
    assert a['causal']['canonical_history_hash']==b['causal']['canonical_history_hash']


def test_H07_same_year_qualified_parent_then_child_can_admit():
    prior=c.candidate(2020,20,'parent','PRACTICE_OBSERVED')
    child=c.candidate(2020,90,'child','PROJECT_TASK',min_practice=1,prerequisites=[c.fact_id(2020,'parent')])
    inp=c.render_input(c.initial_state(),2020);_,pkt=c.mocked_artifacts(inp)
    pkt['candidates']=[prior,child]
    assert not reject_outcome(lambda:c.validate_packet(pkt,inp))
    assert [p['id'] for p in c.validate_packet(pkt,inp)[1]]==['parent','child']


def test_H08_refused_parent_must_not_authorize_child(monkeypatch):
    old=c.fixed_candidates
    def f(year):
        return [c.candidate(year,20,'parent','PRACTICE_OBSERVED'),
                c.candidate(year,60,'dependent','PROJECT_TASK',min_practice=1,prerequisites=[c.fact_id(year,'parent')])] if year==2020 else []
    monkeypatch.setattr(c,'fixed_candidates',f)
    out=c.run(rules={'licensed_objective_actions':['PROJECT_TASK']})
    assert not any(e['id']==c.fact_id(2020,'dependent') for e in out['causal']['final_state']['events'])


def test_H09_optimization_does_not_erase_source_rights():
    src="import onecall_c0 as c;s=c.initial_state();i=c.render_input(s,2020);r,p=c.mocked_artifacts(i);p['source_scope_refs']=['UNISSUED_FORGED'];\ntry:\n c.validate_packet(p,i); print('BAD_ACCEPT')\nexcept Exception:\n print('GOOD_REFUSE')"
    for flag in ([],['-O']):
        proc=subprocess.run([sys.executable,*flag,'-c',src],capture_output=True,text=True,cwd=Path(__file__).parent)
        assert proc.returncode==0 and proc.stdout.strip()=='GOOD_REFUSE',(flag,proc.stdout,proc.stderr)


def test_H10_restart_after_day_200_cannot_apply_day_30():
    prior=c.initial_state();prior['events'].append(dict(id='observed:2020:partial_midyear',year=2020,day=200,action='MATERIAL_EVENT'))
    out=c.run(initial=prior)
    assert not any(ev['year']==2020 and ev['day']<200 for ev in out['causal']['final_state']['events'][1:])


def test_H11_no_owner_rules_defaults_after_explicit_empty_grant():
    x=c.run(rules={})
    assert not x['causal']['final_state']['events']


def test_H12_missing_per_event_source_permission_refused():
    assert reject_outcome(lambda:parsed_packet(single(source_permission='MISSING')))


def test_H13_new_unknown_teacher_requires_real_constructor():
    assert reject_outcome(lambda:parsed_packet(single('TEACHER_MEETING',participants=['child','unconstructed_teacher'])))


def test_H14_render_private_access_request_refused():
    inp=c.render_input(c.initial_state(),2020);r,_=c.mocked_artifacts(inp)
    r['actor_private_memory_access']={'foreign_actor':'secret'}
    assert reject_outcome(lambda:c.validate_render(r,inp))


def test_H15_no_event_because_all_owner_grants_denied(monkeypatch):
    old=c.fixed_candidates
    monkeypatch.setattr(c,'fixed_candidates',lambda _:[])
    x=c.run(rules={'licensed_objective_actions':[]})
    assert not x['causal']['final_state']['events'] and x['causal']['final_state']['current_year']==2022


def test_H16_missing_individual_scientific_probability_must_not_be_accepted():
    assert reject_outcome(lambda:parsed_packet(single(score=-99,source_permission='MISSING')))


def test_H17_typed_render_and_proposal_same_checkpoint_not_causal_contamination():
    a=c.run();b=c.run(variant='different_literary_style')
    assert a['causal']==b['causal']
    assert all(x['render']['causal_hash_before']==x['checkpoint_ref'] for x in a['boundaries'])


def test_H18_repaired_version_identity_must_be_new_separate_digest():
    # This checks ORIGINAL ONLY; repaired module MUST get a new independent pin.
    source=Path(c.__file__).read_bytes()
    import hashlib
    assert hashlib.sha256(source).hexdigest()=='3f0da92095f8355c7512d49ac546c846b6026d3775533ba56be7e148e11abfa1'
