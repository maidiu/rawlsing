"""OCR1 independent hostile execution against UNMODIFIED OC1 public API.

All negative tests call actual candidate entrypoints, never raise the expected
exception themselves. File remains sourcefree; this is NOT real-signature science.
Original 31 OC1 authored tests are retained separately byte-identically.
"""
from dataclasses import replace
import copy
import pytest

from custody_protocol import (
    EscrowState, MockSigner, MockSignature, Person, Role, RoleAssignment,
    RevocationError, IdentityMismatchError, EditAfterFreezeError,
    PurposeViolationError, LedgerRollbackError, BlindIDPairingError,
    SignatureError, ConflictError, LeakageError,
    require_second_signature, verify_blind_pairing,
    detect_leakage, assert_no_leakage, detect_family_clone,
)
from dummy_corpus import (
    build_capsule, build_dummy_corpus, build_model_visible_packet, semantic_digest
)


def setup_escrow(**updates):
    cap = build_capsule("SOURCEFREE_TEST_ONLY", "freeze", build_dummy_corpus())
    cap = replace(cap, **updates)
    e = EscrowState()
    e.commit(cap)
    return e, cap


def setup_signed_capsule():
    e, cap = setup_escrow()
    context, nonce = "ctx-oc1", "fixed-nonce"
    digest = cap.content_digest
    a = MockSigner("custodian-alice", Role.CUSTODIAN).sign(digest, context, nonce)
    b = MockSigner("adjudicator-bob", Role.SEMANTIC_ADJUDICATOR).sign(digest, context, nonce)
    return cap, a, b, digest, context, nonce


# A: The actual escrow entrypoints; no test-side RevocationError.
@pytest.mark.parametrize("mod,identity", [
    ({"revoked": True}, "A01_revoked_unblind"),
    ({"expired": True}, "A02_expired_unblind"),
    ({"purpose": "LIVE_MODEL_REQUEST"}, "A03_illegal_purpose_unblind"),
], ids=lambda x: x if isinstance(x,str) else None)
def test_A_capsule_unblind_permission(mod, identity):
    e, cap = setup_escrow(**mod)
    with pytest.raises((RevocationError, PurposeViolationError, IdentityMismatchError)):
        e.unblind(cap.capsule_id, "custodian-alice")


def test_A04_arbitrary_holder_unblind():
    e, cap = setup_escrow()
    with pytest.raises((IdentityMismatchError, PermissionError)):
        e.unblind(cap.capsule_id, "stranger-unauthorized")


def test_A05_forbidden_role_unblind():
    e, cap = setup_escrow()
    # Supplying a RoleAssignment object cannot register authority; no registry exists.
    declared = RoleAssignment("evil-author", Role.SCENARIO_AUTHOR, "self", 0.0)
    with pytest.raises((IdentityMismatchError, PermissionError, TypeError)):
        e.unblind(cap.capsule_id, declared.person_id)


@pytest.mark.parametrize("mod", [{"revoked": True}, {"expired": True}], ids=["A06_revoked_release","A07_expired_release"])
def test_A_release_after_revocation(mod):
    e, cap = setup_escrow()
    e.unblind(cap.capsule_id, "custodian-alice")
    e.committed[cap.capsule_id] = replace(cap, **mod)
    with pytest.raises((RevocationError, PurposeViolationError, IdentityMismatchError)):
        e.release(cap.capsule_id)


def test_A08_mismatched_holder_unblind():
    e, cap = setup_escrow()
    # A two-party mock signature ceremony has no effect on EscrowState access rights.
    a = MockSigner("custodian-alice", Role.CUSTODIAN).sign(cap.content_digest, "ctx", "nonce")
    b = MockSigner("bob", Role.SEMANTIC_ADJUDICATOR).sign(cap.content_digest, "ctx", "nonce")
    assert require_second_signature(cap, a, b, cap.content_digest, "ctx", "nonce")
    with pytest.raises((IdentityMismatchError, PermissionError)):
        e.unblind(cap.capsule_id, "unrelated-holder")


def test_A09_uncommitted_release():
    with pytest.raises(IdentityMismatchError):
        EscrowState().release("ghost")


def test_A10_duplicate_release():
    e, cap = setup_escrow()
    e.unblind(cap.capsule_id, "holder")
    e.release(cap.capsule_id)
    with pytest.raises(EditAfterFreezeError):
        e.release(cap.capsule_id)


def test_A11_exposure_uncommitted():
    with pytest.raises((IdentityMismatchError, PermissionError)):
        EscrowState().record_exposure("ghost", "outsider", "development")


def test_A12_exposure_illegal_purpose():
    e, cap = setup_escrow()
    with pytest.raises((PurposeViolationError, PermissionError)):
        e.record_exposure(cap.capsule_id, "external", "LIVE_MODEL_REQUEST")


# B: Capsule and signature-binding; callback and signer fixture are actually invoked.

def test_B01_none_capsule():
    cap, a, b, digest, ctx, nonce = setup_signed_capsule()
    with pytest.raises((SignatureError, IdentityMismatchError, ValueError, TypeError)):
        require_second_signature(None, a, b, digest, ctx, nonce)


def test_B02_unrelated_capsule_digest():
    cap, a, b, digest, ctx, nonce = setup_signed_capsule()
    unrelated = replace(cap, content_digest="other-capsule")
    with pytest.raises((SignatureError, IdentityMismatchError, ValueError)):
        require_second_signature(unrelated, a, b, digest, ctx, nonce)


@pytest.mark.parametrize("bad", ["context", "nonce"], ids=["B03_wrong_signature_context", "B04_wrong_signature_nonce"])
def test_B_wrong_context_or_nonce(bad):
    cap, a, b, digest, ctx, nonce = setup_signed_capsule()
    with pytest.raises(SignatureError):
        require_second_signature(cap, a, b, digest, "wrong" if bad=="context" else ctx, "wrong" if bad=="nonce" else nonce)


def test_B05_same_person_signatures():
    cap, a, b, digest, ctx, nonce = setup_signed_capsule()
    with pytest.raises(ConflictError):
        require_second_signature(cap, a, a, digest, ctx, nonce)


def test_B06_conflicting_signatures():
    cap, a, b, digest, ctx, nonce = setup_signed_capsule()
    conflict = MockSigner("runner-eve", Role.EXPERIMENT_RUNNER).sign(digest, ctx, nonce)
    with pytest.raises(ConflictError):
        require_second_signature(cap, a, conflict, digest, ctx, nonce)


def test_B07_inconsistent_signature_digest():
    cap, a, b, digest, ctx, nonce = setup_signed_capsule()
    forged_field = replace(a, content_digest="wrong-metadata-but-hash-same")
    with pytest.raises((SignatureError, IdentityMismatchError)):
        require_second_signature(cap, forged_field, b, digest, ctx, nonce)


def test_B08_mock_role_impersonation():
    cap, a, b, digest, ctx, nonce = setup_signed_capsule()
    # A self-asserted public person ID and role reproduces fixture-derived key.
    forged_role = MockSigner("any-person-not-assigned", Role.CUSTODIAN).sign(digest, ctx, nonce)
    with pytest.raises((SignatureError, PermissionError, IdentityMismatchError)):
        require_second_signature(cap, forged_role, b, digest, ctx, nonce)


# C: Ledger behavior and state/ledger correspondence.

def committed_triplet():
    e, cap = setup_escrow()
    e.unblind(cap.capsule_id, "holder")
    e.release(cap.capsule_id)
    return e, cap


def test_C01_valid_range_rollback_detected():
    e, cap = committed_triplet()
    try:
        e.rollback_ledger(1)
    except LedgerRollbackError:
        return
    assert e.verify_ledger_integrity() is False


def test_C02_ledger_history_deletion_detected():
    e, cap = committed_triplet()
    e.ledger.pop()
    e._ledger_seq -= 1
    assert e.verify_ledger_integrity() is False


def test_C03_ledger_op_tampering_detected():
    e, cap = committed_triplet()
    e.ledger[1]["op"] = "RELEASE"
    assert e.verify_ledger_integrity() is False


def test_C04_ledger_duplicate_event_detected():
    e, cap = committed_triplet()
    e.ledger[1]["op"] = "COMMIT"
    assert e.verify_ledger_integrity() is False


def test_C05_state_ledger_divergence_detected():
    e, cap = committed_triplet()
    e.ledger.clear()
    e._ledger_seq = 0
    assert e.verify_ledger_integrity() is False


def test_C06_ledger_full_normal():
    e, cap = committed_triplet()
    assert e.verify_ledger_integrity() is True
    assert [v["op"] for v in e.ledger] == ["COMMIT", "UNBLIND", "RELEASE"]


# D: Blind pairing exact multiplicity and joins.

def trials(arms, nonce="p"):
    return [{"public_nonce": nonce, "arm": arm} for arm in arms]


@pytest.mark.parametrize("rows", [
    trials("AABC"),
    trials("XYZ"),
    trials("AB"),
    [],
], ids=["D01_duplicate_arm_AABC", "D02_unknown_arms_XYZ", "D06_missing_arm", "D08_empty_input"])
def test_D_invalid_arms(rows):
    with pytest.raises(BlindIDPairingError):
        verify_blind_pairing(rows)


def test_D03_duplicate_trial_id():
    rows = [dict(t, trial_id="same-id") for t in trials("ABC")]
    with pytest.raises(BlindIDPairingError):
        verify_blind_pairing(rows)


def test_D04_mixed_case_join():
    rows = [dict(t, case_id=f"case-{i}") for i,t in enumerate(trials("ABC"))]
    with pytest.raises(BlindIDPairingError):
        verify_blind_pairing(rows)


def test_D05_mixed_family_join():
    rows = [dict(t, family_id=f"family-{i}") for i,t in enumerate(trials("ABC"))]
    with pytest.raises(BlindIDPairingError):
        verify_blind_pairing(rows)


def test_D07_valid_ABC():
    assert verify_blind_pairing(trials("ABC")) is True


# E: Lexical checking is a test-only denylist, not a schema/noninterference proof.

def test_E01_hidden_origin_token():
    with pytest.raises(LeakageError):
        assert_no_leakage({"hidden_origin": "synthetic"})


def test_E02_encoded_key_injection():
    with pytest.raises(LeakageError):
        assert_no_leakage({"answer\u200b_key": "A"})


def test_E03_nested_semantic_answer_leak():
    with pytest.raises(LeakageError):
        assert_no_leakage({"public_projection": {"solution": "OPTION_A", "truth": "A"}})


def test_E04_harmless_arm_substring():
    assert detect_leakage({"note": "The color is charming"}) == []


def test_E05_safe_generated_packet():
    case = build_dummy_corpus()[0]
    assert_no_leakage(build_model_visible_packet(case))


def test_E06_coder_encoded_hint():
    with pytest.raises(LeakageError):
        assert_no_leakage({"response": "A", "hint": {"expe\u200bcted_answer": "A"}})


# F: Freeze and family basic positive + negative checks.

def test_F01_capsule_recommit_edit():
    e, cap = setup_escrow()
    with pytest.raises(EditAfterFreezeError):
        e.commit(replace(cap, lawful_set_digest="changed"))


def test_F02_capsule_undetected_digest_corruption():
    e, cap = setup_escrow()
    e.committed[cap.capsule_id] = replace(cap, content_digest="forged")
    # If the integrity API represents ledger integrity it must bind the committed capsule.
    assert e.verify_ledger_integrity() is False


def test_F03_family_exact_clone():
    d={"facts":"same","temporal_origin":"shared"}
    assert detect_family_clone(d, copy.deepcopy(d), frozenset()) is True


def test_F04_family_semantic_paraphrase_is_not_proof():
    # Explicitly limited: exact digest never establishes *semantic* independence.
    a = {"description": "A obtains water at public source"}
    b = {"description": "Person A gets water from a communal well"}
    assert detect_family_clone(a,b,frozenset()) is False


def test_F05_mock_signature_test_only():
    cap,a,b,digest,ctx,nonce = setup_signed_capsule()
    assert a.test_only and a.verification_root == "TEST_ONLY_EPHEMERAL_ROOT"
    assert MockSigner.verify(a,digest,ctx,nonce) is True
