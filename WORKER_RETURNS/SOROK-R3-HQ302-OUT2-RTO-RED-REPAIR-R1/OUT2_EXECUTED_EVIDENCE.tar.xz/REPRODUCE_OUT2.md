# OUT2 source-free reproduction

From a clean isolated directory, unpack `OUT2_EXECUTED_EVIDENCE.tar.xz` (or use these same files extracted into one directory):

```sh
python -m pytest -q test_sr_28_falsifier_court.py test_rsr_independent.py test_rsr_cold_replay.py test_cold_repair.py test_rto_hostile.py test_out2_cross.py --junitxml=full_out2.xml
```

Expected **exit=1, 135 PASS / 2 FAIL**. Do not xfail or modify original tests. The only REDs are S27 authored conflict and stale dual-writer stress counterexample. Cold subprocess tests use `os._exit(79)` and independent Python process restarts; Python `pytest` in path plus filesystem required. Source is bundled solely as candidate code, not production ADP019.

`baseline113.xml/log` preserve before-repair 83 PASS/30 FAIL, `full_out2.xml/log` preserve repair run. All original four authored/RSR and two RTO files unchanged; compare `01_EXECUTION_MATRIX.json` SHA1.
