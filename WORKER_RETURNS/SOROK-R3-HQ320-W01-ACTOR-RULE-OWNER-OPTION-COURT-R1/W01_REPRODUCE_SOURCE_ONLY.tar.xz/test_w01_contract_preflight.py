"""Precommitted requirements from W01 oracle; tests of prospective structure only.

These tests NEVER call or impersonate an accepted CAN008/V3 actor runtime.
"""
from dataclasses import replace
import pytest
from w01_contract_preflight import REQUIRED, one_event, two_event


def good(eid='EVT1',time='1998-11-20T00:00:00Z',old='H0',new='H1'):
    x={k:'EXACT_PROSPECTIVE_ONLY' for k in REQUIRED}
    x.update(actor_id='SYNTHETIC_UNISSUED_SUBJECT_REF',state_actor_identity='SYNTHETIC_UNISSUED_SUBJECT_REF',
    event_effective_time=time, world_as_of_time='1998-11-01T00:00:00Z',conditioning_as_of_time='1998-11-01T00:00:00Z',
    precipitating_event_id=eid,response_journal_predecessor=old,response_journal_new_head=new,
    source_rights='SOURCEFREE_PROSPECTIVE_ONLY',event_state='EXACT_ADMITTED_PROSPECTIVE',
    rule_status='ISSUANCE_PENDING_COMPETENT_OWNER',permission_status='PROPOSAL_NOT_GRANTED',
    target_state='TARGET_OWNER_PROPOSAL_ONLY',parent_relation='EXACT_PROSPECTIVE_EVENT',
    world_read_mode='FORWARD_AS_OF_NOT_REVERSE_P_A_GIVEN_D',claim_access='NONE',
    action='RESPONSE_HISTORY_APPEND_PROPOSAL',world_choice='PROSPECTIVE_W0',
    grant_revoked=False,external_dyad='NO_DYAD',write_mode='DRY_RUN_PROPOSAL')
    return x


def test_structural_prospective_positive_not_issuance():
    x=one_event(good())
    assert x.eligible and 'OWNER_ISSUANCE_STILL_MISSING' in x.code
    assert 'NEVER_ISSUANCE' in x.grade


def test_forced_authority_claim_rejected_even_with_complete_shape():
    assert one_event(good(), presently_issued=True).code=='UNVERIFIABLE_AUTHORITY_CLAIM'

@pytest.mark.parametrize('field',list(REQUIRED))
def test_required_fields_fail_closed(field):
    x=good();x.pop(field)
    assert not one_event(x).eligible

@pytest.mark.parametrize('field,value,code',[
 ('actor_id','GT0_NO_ACTOR_BOUND','NO_ACTOR_BINDING'),
 ('actor_id','REAL_ACTOR','CANNOT_PROMOTE_PROPOSED_ACTOR'),
 ('source_rights','ORIGINAL_35_WAVE','SOURCE_RIGHTS_UNDECLARED'),
 ('event_state','DRAFT','EVENT_NOT_ADMITTED'),
 ('rule_status','CURRENT_ACCEPTED','RULE_OR_STATUS_IMPROPER'),
 ('permission_status','GRANTED_BY_CALLER','UNPROVED_PERMISSION'),
 ('target_state','WRITTEN','UNPROVED_TARGET_OWNER'),
 ('parent_relation','RAW_STRUCTURAL_PRIOR','RAW_STRUCTURAL_PARENT'),
 ('world_read_mode','P_A_GIVEN_D','REVERSE_OR_UNKNOWN_DIRECTION'),
 ('claim_access','ANALYST_PRIVATE','ACTOR_PRIVATE_LEAK'),
 ('action','MOVE_THIRD_PARTY','UNRECOGNIZED_ACTION'),
 ('world_choice','FUTURE_CHILD_SELECTED_AT_CONCEPTION','HIDDEN_FUTURE_CHILD'),
 ('grant_revoked',True,'UNPROVED_OR_REVOKED_GRANT'),
 ('external_dyad','UNISSUED','UNSUPPORTED_DYAD'),
 ('world_as_of_time','2002-11-01T00:00:00Z','FUTURE_OR_STALE_AS_OF_READ'),
 ('conditioning_as_of_time','2001-11-01T00:00:00Z','FUTURE_OR_STALE_AS_OF_READ'),
 ('write_mode','REAL_COMMIT','UNISSUED_COMMIT')])
def test_named_negative(field,value,code):
    x=good();x[field]=value
    assert one_event(x).code==code


def test_no_premature_third_party_effect_and_no_claim():
    x=good();x['action']='MOVE_THIRD_PARTY';assert not one_event(x).eligible
    y=good();y['claim_access']='ACTOR_PRIVATE';assert not one_event(y).eligible


def test_two_event_structural_positive_still_not_issuance():
    x=good();y=good('EVT2','1999-02-20T00:00:00Z','H1','H2')
    y['e1_commit_receipt']='ISSUANCE_PENDING_COMPETENT_OWNER'
    result=two_event(x,y)
    assert result.eligible and result.code=='TWO_EVENT_STRUCTURAL_PREFLIGHT__NO_EFFECT_EXECUTED'

@pytest.mark.parametrize('change,code',[
 ({'actor_id':'DIFFERENT'},'CROSS_ACTOR_STATE'),
 ({'response_journal_predecessor':'WRONG'},'MISSING_PRIOR_RESPONSE_HISTORY'),
 ({'precipitating_event_id':'EVT1'},'REPLAY_NOT_SECOND_EVENT'),
 ({'e1_commit_receipt':'ABSENT'},'NO_ACTUAL_E1_OWNER_RECEIPT'),
 ({'event_effective_time':'1998-11-10T00:00:00Z'},'INVALID_EVENT_ORDER'),
])
def test_two_event_structural_negative(change,code):
    x=good();y=good('EVT2','1999-02-20T00:00:00Z','H1','H2');y['e1_commit_receipt']='ISSUANCE_PENDING_COMPETENT_OWNER';y.update(change)
    assert two_event(x,y).code==code
