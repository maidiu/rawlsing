"""W01 documentary preflight for hypothetical SOURCEFREE actor-rule issuance.

This has NO authenticated registry, actor, event, owner, model, or V3 writer.
It checks the structural eligibility of an externally supplied evidence envelope.
Structural completeness never equals current authority, an event, or personhood.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Mapping, Any

REQUIRED = (
    'rule_id','rule_version','rule_body_hash','adopting_semantic_owner_ref',
    'actor_registry_ref','actor_id','source_authority_ref',
    'precipitating_event_id','precipitating_event_hash','event_authority_ref',
    'event_effective_time','world_snapshot_id','world_snapshot_hash',
    'world_as_of_time','conditioning_owner_ref','conditioning_actor_id',
    'conditioning_state_hash','conditioning_as_of_time','target_owner_ref',
    'target_operation','target_before_hash','target_after_hash',
    'target_effect_receipt_hash','response_journal_predecessor',
    'response_journal_new_head','actor_access_envelope_ref',
    'claim_access_ceiling','permission_grant_ref'
)

@dataclass(frozen=True)
class Preflight:
    eligible: bool
    code: str
    grade: str = 'DOCUMENTARY_STRUCTURAL_PREFLIGHT__NEVER_ISSUANCE'

def _time(value: Any):
    if not isinstance(value,str):
        return None
    try:
        t=datetime.fromisoformat(value.replace('Z','+00:00'))
        return t if t.tzinfo is not None else None
    except ValueError:
        return None


def one_event(envelope: Mapping[str,Any], *, presently_issued: bool=False) -> Preflight:
    # presently_issued is NOT a caller-issued permission! It is deliberately
    # forbidden here: this preflight has no real issuer validation capability.
    if presently_issued:
        return Preflight(False,'UNVERIFIABLE_AUTHORITY_CLAIM')
    if not isinstance(envelope,dict):
        return Preflight(False,'NOT_AN_ENVELOPE')
    for key in REQUIRED:
        if not isinstance(envelope.get(key),str) or not envelope[key].strip():
            return Preflight(False,'MISSING_OR_INVALID_'+key.upper())
    if envelope['actor_id']=='GT0_NO_ACTOR_BOUND':
        return Preflight(False,'NO_ACTOR_BINDING')
    for forbidden in ('REAL_ACTOR','EXPERIMENTAL_V3_ACTOR','MODEL_GENERATED_ACTOR'):
        if envelope['actor_id']==forbidden:
            return Preflight(False,'CANNOT_PROMOTE_PROPOSED_ACTOR')
    if envelope.get('source_rights')!='SOURCEFREE_PROSPECTIVE_ONLY':
        return Preflight(False,'SOURCE_RIGHTS_UNDECLARED')
    if envelope.get('event_state')!='EXACT_ADMITTED_PROSPECTIVE':
        return Preflight(False,'EVENT_NOT_ADMITTED')
    if envelope.get('rule_status')!='ISSUANCE_PENDING_COMPETENT_OWNER':
        return Preflight(False,'RULE_OR_STATUS_IMPROPER')
    if envelope.get('permission_status')!='PROPOSAL_NOT_GRANTED':
        return Preflight(False,'UNPROVED_PERMISSION')
    if envelope.get('target_state')!='TARGET_OWNER_PROPOSAL_ONLY':
        return Preflight(False,'UNPROVED_TARGET_OWNER')
    if envelope.get('state_actor_identity') != envelope.get('actor_id'):
        return Preflight(False,'CROSS_ACTOR_STATE')
    if envelope.get('parent_relation') not in ('EXACT_PROSPECTIVE_EVENT','CAUSAL_SOURCE_NOT_YET_ADMITTED'):
        return Preflight(False,'RAW_STRUCTURAL_PARENT')
    if envelope.get('world_read_mode')!='FORWARD_AS_OF_NOT_REVERSE_P_A_GIVEN_D':
        return Preflight(False,'REVERSE_OR_UNKNOWN_DIRECTION')
    if envelope.get('claim_access') not in ('NONE','EXACT_ACTOR_SAFE_ONLY'):
        return Preflight(False,'ACTOR_PRIVATE_LEAK')
    if envelope.get('action') not in ('RESPONSE_HISTORY_APPEND_PROPOSAL','TARGET_EFFECT_PROPOSAL'):
        return Preflight(False,'UNRECOGNIZED_ACTION')
    if envelope.get('world_choice')=='FUTURE_CHILD_SELECTED_AT_CONCEPTION':
        return Preflight(False,'HIDDEN_FUTURE_CHILD')
    if envelope.get('grant_revoked') is not False:
        return Preflight(False,'UNPROVED_OR_REVOKED_GRANT')
    if envelope.get('external_dyad')=='UNISSUED':
        return Preflight(False,'UNSUPPORTED_DYAD')
    e,w,c=(_time(envelope[k]) for k in ('event_effective_time','world_as_of_time','conditioning_as_of_time'))
    if None in (e,w,c):
        return Preflight(False,'TIME_NOT_GROUNDED')
    if w>e or c>e:
        return Preflight(False,'FUTURE_OR_STALE_AS_OF_READ')
    if envelope.get('write_mode')!='DRY_RUN_PROPOSAL':
        return Preflight(False,'UNISSUED_COMMIT')
    return Preflight(True,'STRUCTURAL_PREFLIGHT_COMPLETE__OWNER_ISSUANCE_STILL_MISSING')


def two_event(e1: Mapping[str,Any], e2: Mapping[str,Any]) -> Preflight:
    a,b=one_event(e1),one_event(e2)
    if not a.eligible:
        return a
    if not b.eligible:
        return b
    if e1['actor_id']!=e2['actor_id']:
        return Preflight(False,'ACTOR_MISMATCH')
    if e1['response_journal_new_head']!=e2['response_journal_predecessor']:
        return Preflight(False,'MISSING_PRIOR_RESPONSE_HISTORY')
    if not _time(e1['event_effective_time']) < _time(e2['event_effective_time']):
        return Preflight(False,'INVALID_EVENT_ORDER')
    if e1['precipitating_event_id']==e2['precipitating_event_id']:
        return Preflight(False,'REPLAY_NOT_SECOND_EVENT')
    if e2.get('e1_commit_receipt')!='ISSUANCE_PENDING_COMPETENT_OWNER':
        return Preflight(False,'NO_ACTUAL_E1_OWNER_RECEIPT')
    return Preflight(True,'TWO_EVENT_STRUCTURAL_PREFLIGHT__NO_EFFECT_EXECUTED')
