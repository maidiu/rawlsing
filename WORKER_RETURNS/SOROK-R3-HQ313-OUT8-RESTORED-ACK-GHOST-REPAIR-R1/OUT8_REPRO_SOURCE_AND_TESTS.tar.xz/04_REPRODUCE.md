# Reproduction (all commands actually executed)

Archive includes `stage/` Python source, original unchanged tests, `baseline/` exact prior outbox source/test files, and `evidence/` JUnit+stdout.

```
cd stage
python -m pytest -q test_sr_28_falsifier_court.py test_rsr_independent.py test_rsr_cold_replay.py test_cold_repair.py test_rto_hostile.py test_out2_cross.py test_out3_independent_hostile.py test_out4_independent_harness.py test_out6_receipt_repair.py test_out7_independent_hostile.py test_out8_restored_state_repair.py --junitxml=../evidence/review_247.xml
# expected 245 PASS/2 original RED; exit 1

python -m pytest -q test_out7_independent_hostile.py test_out8_restored_state_repair.py
# expected 41/41 PASS
```

Use `baseline/` source for pre-repair 227 combined test command above without `test_out8_restored_state_repair.py`: expected 221P/6RED. The archive preserves the actual before+after JUnit and logs, hashes, and original source bytes; it is `SOURCEFREE_TEST_ONLY` not ADP019 or real perception evidence.
