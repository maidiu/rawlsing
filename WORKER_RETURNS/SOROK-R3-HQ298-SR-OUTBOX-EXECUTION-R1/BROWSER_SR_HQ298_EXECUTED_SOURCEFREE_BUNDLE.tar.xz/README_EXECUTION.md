# Standalone SR HQ298 source-free court

All source files and outputs in this bundle are reviewable; extract the package (no private repository clone or network dependencies).

Commands:

```bash
python -m pytest test_sr_court.py -q --junitxml=junit.xml
python run_court.py
```

`sr_prototype.py` is a tiny deterministic source-free surrogate, **not** accepted V3/V2/PFF code. `test_sr_court.py` contains exact S01–S28 case identifiers from upstream frozen JSON blob `782ba75ee94f24908100b1f3464e7035497d546c`, with one behavioral assertion procedure per case plus three independent replay/access regressions. `run_court.py` writes `28_case_status_matrix.json`.

To preserve portability this bundle includes both the tested source and the **actual** JUnit, matrix, environment passport, chronological runner log and remaining atomicity counterexample. The live Browser epoch is not implied to survive. Git blob identities of uncompressed source/output are recorded in `environment_passport_delta.json`. No secret data or original survey.
