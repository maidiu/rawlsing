# SR HQ298 — deterministic court and remaining real-world atomicity gap

## Actual isolated proof
31 pytest tests passed, comprising S01–S28 and 3 supplemental crash/access regressions. Each S-case produces a before/after SHA256 of the persisted JSON world/ledger/outbox and an assertion trace in `28_case_status_matrix.json`. `test_real_subprocess_exit_then_cold_replay` executes a child Python process which commits then calls `os._exit(79)`, and a new Store instance reopens the committed event/outbox; replay does not create a second event. Sourcefree code, not imported accepted CAN025/ADP019 owners.

## Counterexample: exactly-once human perception is not provable
An admitted event with delivery ID d is emitted and displayed to a mock client, but the server ACK is lost. Server state after recovery sees the same d still needing reconciliation. Retrying d may result in another client display, despite the stable identifier; an idempotent client could avoid duplicate UI effects but cannot prove whether a human previously heard/read the first display. This bounded prototype leaves `human_perceived=UNPROVEN` even after `transport_ack=true`, `client_displayed=true` and access=`POSSIBLE`. Thus single-file event/outbox exactness does NOT imply exactly-once external delivery or perception. No actual external client/delivery was exercised.

## Transaction limits
`Store._write` is an `os.replace` of one local JSON record after `fsync` of its file. It exercises one logical local atomic replacement, not parent-directory fsync, multi-process locks, concurrent append safety, a separate world-object database, an actual V3 ledger, a physically committed gesture/material change, outbox broker or actor-specific memory authority. No crash occurs *during* rename; there is a hard subprocess exit after admit plus simulated before/after-commit exceptions. Accept only F2 logical fixture, not owner-level or F3 renderer/actor proof.

## Explicit owner holds
CAN-022 wording-only means BODY materialization remains held; CAN-025 package READY cannot make an event; ADP-019 must own actual admission. Material world transitions require separate issuer and coordinated transaction. This prototype simulates denied states and does not create such authority. Human experience, two-model-call reliability, source-backed world and measured budgets remain FU.
