"""Generate actual evidence matrix from the same frozen cases used by pytest."""
from pathlib import Path
import datetime
import json
import tempfile
from test_sr_court import IDS, run_case

root = Path(__file__).parent
out = []
for ident in IDS:
    with tempfile.TemporaryDirectory(prefix="sr_case_") as td:
        try:
            result = run_case(ident, td)
        except Exception as exc:
            result = {"id": ident, "status": "FAIL", "error_type": type(exc).__name__, "error": str(exc)}
        out.append(result)
matrix = {"schema": "SR_HQ298_ACTUAL_CASE_MATRIX@1", "grade": "ISOLATED_SOURCEFREE_PROTOTYPE_ONLY",
          "frozen_source_blob": "782ba75ee94f24908100b1f3464e7035497d546c",
          "cases": out, "accounting": {"executed": len(out), "passed": sum(x["status"] == "PASS" for x in out),
          "failed": sum(x["status"] == "FAIL" for x in out), "not_reached": 28-len(out)},
          "unproven": ["real CAN025/ADP019 implementation", "distributed atomicity", "exactly once external transport",
                       "human perception", "real actor/model/renderer", "embodied/materialization owner"]}
(root/"28_case_status_matrix.json").write_text(json.dumps(matrix, indent=2, ensure_ascii=False)+"\n")
print(json.dumps(matrix["accounting"]))
raise SystemExit(0 if matrix["accounting"]["failed"] == 0 and matrix["accounting"]["not_reached"] == 0 else 1)
