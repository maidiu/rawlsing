"""SR source-free deterministic occurrence/outbox prototype. NOT ADP019/CAN025/V2 owner code.

Durability: atomic replace of one local JSON record; no distributed transaction,
model provider, external transport or human perception attestation.
"""
from __future__ import annotations
import copy
import hashlib
import json
import os
from pathlib import Path


def digest(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()


class Denied(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


class SimulatedCrash(Exception):
    pass


class Store:
    def __init__(self, root):
        self.path = Path(root) / "state.json"
        if not self.path.exists():
            self._write({"cursor": 0, "events": [], "outbox": {}, "decisions": {}, "world":
                         {"employment": "fired", "gift_history": "gift_received_2010",
                          "objects": {"obj:mug-1": "locked_cabinet"}},
                         "actor_memory": [], "actor_packets": {}, "noncausal_display": [],
                         "projected_deliveries": {}, "render_requests": {}})

    def read(self):
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, state):
        tmp = self.path.with_name("state.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(json.dumps(state, ensure_ascii=False, sort_keys=True))
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, self.path)
        # Parent directory durability is NOT assumed/proved by this source-free court.

    def snapshot(self):
        return digest(self.read())

    def candidate(self, words="Hello", request="req:1", ordinal=0, atoms=None, prose=None, **extra):
        # Render identity includes request, ordinal and payload, not just visible bytes.
        if atoms is None:
            atoms = [{"kind": "WORDS", "value": words}]
        val = {"request": request, "ordinal": ordinal, "atoms": atoms,
               "prose": words if prose is None else prose, **extra}
        val["artifact_hash"] = digest(val)
        val["artifact_id"] = "artifact:" + val["artifact_hash"][:20]
        return val

    def no_output_retry(self, request_id):
        state = self.read()
        row = state["render_requests"].setdefault(request_id, {"request_id": request_id, "ordinal": 0,
                                                                "output_exists": False})
        if row["output_exists"]:
            raise Denied("RERENDER_REQUIRED_OUTPUT_EXISTS")
        row["ordinal"] += 1
        self._write(state)
        return copy.deepcopy(row)

    def render_plan(self, plan_state):
        if plan_state == "VALID_EMPTY":
            return "RENDER_ADMISSION_VALID_EMPTY"
        if plan_state == "UNAUTHORIZED":
            raise Denied("HOLD_MISSING_PLAN_AUTHORITY")
        return "RENDER_PLAN_READY"

    def submit(self, proposal, *, crash=None):
        """Synthetic ADP019-like gate: same-file admission + outbox, not real V3 code."""
        state = self.read()
        pid = proposal["proposal_id"]
        ph = digest({k: v for k, v in proposal.items() if k != "debug"})
        prior = state["decisions"].get(pid)
        if prior:
            if prior["proposal_hash"] != ph:
                raise Denied("INVALID_PROPOSAL_ID_CONTENT_COLLISION")
            return copy.deepcopy(prior["receipt"])
        def fail(code):
            # Rejection/defer never persist causal effects, even if caller holds a candidate.
            raise Denied(code)
        if proposal.get("package_state") != "READY":
            fail("HOLD_MISSING_PACKAGE")
        if proposal.get("interaction_mode", "IN_WORLD_CAUSAL") != "IN_WORLD_CAUSAL":
            fail("PRESENTATION_NONCAUSAL_NOT_CAUSAL")
        if not proposal.get("causal_time"):
            fail("DEFER_MISSING_CAUSAL_TIME")
        if proposal.get("third_party_ref") is None and "third_party_ref" in proposal:
            fail("HOLD_MISSING_ACTOR_AND_WORLD_EVENT_AUTHORITY")
        cand = proposal["candidate"]
        actual_hash = digest({k: v for k, v in cand.items() if k not in ("artifact_hash", "artifact_id")})
        if actual_hash != cand["artifact_hash"] or cand["artifact_id"] != "artifact:" + actual_hash[:20]:
            fail("INVALID_CANDIDATE_ARTIFACT_IDENTITY")
        atoms = cand["atoms"]
        if not atoms:
            fail("VALID_EMPTY_NO_EVENT")
        for atom in atoms:
            if atom["kind"] == "BODY":
                fail("HOLD_MISSING_EMBODIED_OWNER")
            if atom["kind"] == "MATERIAL":
                if atom.get("object_id") not in state["world"]["objects"]:
                    fail("REJECT_UNBOUND_OBJECT")
                if atom.get("expected_position") != state["world"]["objects"][atom["object_id"]]:
                    fail("REJECT_PHYSICAL_PRECONDITION")
                fail("HOLD_MISSING_MATERIALIZATION_OWNER")
            if atom["kind"] != "WORDS":
                fail("HOLD_UNAUTHORIZED_ATOM_KIND")
        if len(atoms) != 1 or atoms[0]["value"] != cand["prose"]:
            fail("REJECT_SIDE_CAR_MISMATCH")
        if crash == "BEFORE_COMMIT":
            raise SimulatedCrash("BEFORE_COMMIT")
        event_id = "evt:" + digest({"proposal_id": pid, "proposal_hash": ph, "next_cursor": state["cursor"] + 1})[:24]
        delivery_id = "delivery:" + digest({"event_id": event_id, "artifact": cand["artifact_hash"]})[:24]
        event = {"event_id": event_id, "proposal_id": pid, "artifact_id": cand["artifact_id"],
                 "artifact_hash": cand["artifact_hash"], "words": atoms[0]["value"],
                 "causal_time": proposal["causal_time"], "speaker": proposal.get("speaker", "N"),
                 "assertion_kind": "UTTERANCE_OCCURRED_NOT_PROPOSITION_TRUE"}
        record = {"delivery_id": delivery_id, "event_id": event_id, "status": "ADMITTED_UNDELIVERED",
                  "attempts": 0, "transport_ack": False, "client_displayed": False,
                  "opportunity_to_perceive": "UNDETERMINED", "human_perceived": "UNPROVEN"}
        receipt = {"decision": "ADMIT", "event_id": event_id, "delivery_id": delivery_id,
                   "cursor": state["cursor"] + 1, "proposal_hash": ph}
        state["cursor"] += 1
        state["events"].append(event)
        state["outbox"][delivery_id] = record
        state["decisions"][pid] = {"proposal_hash": ph, "receipt": receipt}
        self._write(state)
        if crash == "AFTER_COMMIT":
            raise SimulatedCrash("AFTER_COMMIT")
        return copy.deepcopy(receipt)

    def send(self, delivery_id, *, displayed=False, ack=False, access="UNKNOWN"):
        state = self.read()
        row = state["outbox"][delivery_id]
        row["attempts"] += 1
        row["status"] = "EXTERNAL_EMITTED"
        row["client_displayed"] |= displayed
        row["transport_ack"] |= ack
        row["opportunity_to_perceive"] = "POSSIBLE" if access == "YES" else "NO" if access == "NO" else "UNDETERMINED"
        # Exactly-once human view cannot follow from delivery ID, transport ack, or display flag.
        self._write(state)
        return copy.deepcopy(row)

    def user_projection(self, delivery_id, *, user, hearing=False, vision=False, legible_labels=()):
        state = self.read()
        event = next(e for e in state["events"] if e["event_id"] == state["outbox"][delivery_id]["event_id"])
        projection = {"user": user, "event_id": event["event_id"],
                "heard_words": event["words"] if hearing else None,
                "seen_subject": event["speaker"] if vision else None,
                "recognized_labels": list(legible_labels),
                "user_perceived": "UNPROVEN"}
        lens = {"hearing": hearing, "vision": vision, "labels": list(legible_labels)}
        projection_id = "proj:" + digest({"user": user, "delivery": delivery_id, "lens": lens})[:24]
        state["projected_deliveries"][projection_id] = {"delivery_id": delivery_id, "projection": projection,
                                                     "status": "PREPARED_NOT_CLIENT_DELIVERED"}
        self._write(state)
        return projection

    def actor_encode(self, *, event_id, actor, perceived, rule_authorized):
        state = self.read()
        if event_id not in [x["event_id"] for x in state["events"]]:
            raise Denied("NO_ADMITTED_EVENT")
        if not perceived or not rule_authorized:
            raise Denied("MISSING_ACTOR_PERCEPTUAL_ENCODING_RULE")
        key = [event_id, actor]
        if not any(m["key"] == key for m in state["actor_memory"]):
            state["actor_memory"].append({"key": key, "status": "TEST_ONLY_ENCODED"})
            self._write(state)

    def noncausal(self, text):
        state = self.read()
        state["noncausal_display"].append(text)
        self._write(state)

    def actor_packet(self, actor, refs):
        state = self.read()
        state["actor_packets"][actor] = list(refs)
        self._write(state)


def proposed(store, words="Hello", pid="p1", **kwargs):
    return {"proposal_id": pid, "package_state": "READY", "interaction_mode": "IN_WORLD_CAUSAL",
            "causal_time": "2008-06-01T12:00:00", "candidate": store.candidate(words), **kwargs}
