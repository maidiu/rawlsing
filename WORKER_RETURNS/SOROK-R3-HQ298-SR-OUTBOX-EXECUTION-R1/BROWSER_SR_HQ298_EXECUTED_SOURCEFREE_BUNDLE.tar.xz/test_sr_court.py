"""Frozen SR-03 S01-S28 actual behavioral court, source-free fixture only."""
from __future__ import annotations
import json
from pathlib import Path
import pytest
from sr_prototype import Store, Denied, SimulatedCrash, digest, proposed

IDS = [f"S{i:02d}" for i in range(1, 29)]
SOURCE_CASE_BLOB = "782ba75ee94f24908100b1f3464e7035497d546c"


def run_case(case_id, root):
    s = Store(root)
    before = s.snapshot()
    trace = []
    def check(cond, what):
        assert cond, f"{case_id}: {what}"
        trace.append(what)
    def denied(expected, proposal):
        try:
            s.submit(proposal)
        except Denied as exc:
            check(exc.code == expected, f"expected={expected};actual={exc.code}")
        else:
            raise AssertionError(f"{case_id}: missing denial {expected}")
    base = proposed(s)
    if case_id == "S01":
        c = s.candidate(); check(c["artifact_id"].startswith("artifact:"), "candidate_only")
        check(not s.read()["events"] and s.read()["cursor"] == 0 and not s.read()["actor_memory"], "no_ghost_event_or_knowledge")
    elif case_id == "S02":
        check(base["package_state"] == "READY" and not s.read()["events"] and not s.read()["outbox"], "ready_is_not_admit")
    elif case_id == "S03":
        r = s.submit(base); st = s.read(); check(len(st["events"]) == 1 and st["cursor"] == 1, "single_objective_occurrence")
        check(st["outbox"][r["delivery_id"]]["status"] == "ADMITTED_UNDELIVERED" and st["outbox"][r["delivery_id"]]["human_perceived"] == "UNPROVEN", "outbox_not_perception")
    elif case_id == "S04":
        r = s.submit(base); h = digest(s.read()["events"])
        a = s.user_projection(r["delivery_id"], user="A", hearing=True, vision=True)
        b = s.user_projection(r["delivery_id"], user="B", hearing=False, vision=True)
        check(a["heard_words"] == "Hello" and b["heard_words"] is None and a != b, "two_access_lenses")
        check(digest(s.read()["events"]) == h and len(s.read()["events"]) == 1, "objective_occurrence_invariant")
    elif case_id == "S05":
        p = proposed(s, "neutral"); p["debug"] = "PRIVATE_RED"
        r = s.submit(p); q = s.user_projection(r["delivery_id"], user="A", hearing=True)
        check("PRIVATE_RED" not in str(q) and "PRIVATE_RED" not in str(s.read()["events"]), "hidden_origin_not_output")
        check(q["heard_words"] == "neutral", "no_unlicensed_tell")
    elif case_id == "S06":
        r = s.submit(proposed(s, "I quit."))
        check(s.read()["events"][0]["words"] == "I quit." and s.read()["world"]["employment"] == "fired", "false_testimony_not_factual_promotion")
        check(s.user_projection(r["delivery_id"], user="A", hearing=True)["heard_words"] == "I quit.", "actual_words_only")
    elif case_id == "S07":
        s.submit(proposed(s, "I bought these in 2012")); check(s.read()["world"]["gift_history"] == "gift_received_2010", "historical_truth_unchanged")
    elif case_id == "S08":
        base["candidate"] = s.candidate(atoms=[{"kind": "WORDS", "value": "hi"}, {"kind": "BODY", "value": "shoulder touch"}], prose="hi")
        denied("HOLD_MISSING_EMBODIED_OWNER", base); check(not s.read()["events"], "zero_publication")
    elif case_id == "S09":
        base["candidate"] = s.candidate(atoms=[{"kind": "MATERIAL", "object_id": "obj:mug-999", "expected_position": "counter"}], prose="move mug")
        denied("REJECT_UNBOUND_OBJECT", base); check(s.read()["world"]["objects"] == {"obj:mug-1": "locked_cabinet"}, "scene_unchanged")
    elif case_id == "S10":
        base["candidate"] = s.candidate(atoms=[{"kind": "MATERIAL", "object_id": "obj:mug-1", "expected_position": "elbow"}], prose="catch mug")
        denied("REJECT_PHYSICAL_PRECONDITION", base); check(s.read()["world"]["objects"]["obj:mug-1"] == "locked_cabinet", "no_world_mutation")
    elif case_id == "S11":
        base["candidate"] = s.candidate("Wait", prose="Wait and slams door")
        denied("REJECT_SIDE_CAR_MISMATCH", base); check(not s.read()["events"], "no_ledger_write")
    elif case_id == "S12":
        req = "req:1"; step = s.no_output_retry(req)
        check(step["request_id"] == req and step["ordinal"] == 1, "same_request_incremented_retry")
        check(not s.read()["events"] and not s.read()["decisions"], "retry_no_output_no_event")
    elif case_id == "S13":
        a = s.candidate("INVALID_OUTPUT_EXISTS", request="req:1")
        b = s.candidate("valid", request="req:2")
        check(a["artifact_id"] != b["artifact_id"] and a["request"] != b["request"], "rerender_new_request_and_artifact")
        check(not s.read()["events"], "rejected_candidate_not_admitted")
    elif case_id == "S14":
        a = s.candidate("hello", request="A"); b = s.candidate("hello", request="B")
        check(a["prose"] == b["prose"] and a["artifact_hash"] != b["artifact_hash"], "same_words_different_artifact")
        check(not s.read()["decisions"], "new_receipt_required")
    elif case_id == "S15":
        a = s.submit(base); b = s.submit(base)
        check(a == b and len(s.read()["events"]) == 1 and s.read()["cursor"] == 1, "idempotent_admit_and_cursor")
    elif case_id == "S16":
        s.submit(base); changed = proposed(s, "different", pid="p1")
        denied("INVALID_PROPOSAL_ID_CONTENT_COLLISION", changed)
        check(len(s.read()["events"]) == 1 and s.read()["cursor"] == 1, "collision_cannot_write_event")
    elif case_id == "S17":
        try: s.submit(base, crash="AFTER_COMMIT")
        except SimulatedCrash: trace.append("after_commit_crash_injected")
        s = Store(root)  # actual cold reopen
        r = s.submit(base); o = s.read()["outbox"][r["delivery_id"]]
        check(len(s.read()["events"]) == 1 and o["attempts"] == 0 and o["human_perceived"] == "UNPROVEN", "reopened_one_event_unseen")
        check(s.submit(base)["delivery_id"] == r["delivery_id"], "stable_delivery_id_recovery")
    elif case_id == "S18":
        r = s.submit(base); s.send(r["delivery_id"], displayed=True, ack=False, access="YES")
        s = Store(root); x = s.send(r["delivery_id"], displayed=True, ack=True, access="YES")
        check(x["attempts"] == 2 and x["delivery_id"] == r["delivery_id"], "same_id_retry")
        check(len(s.read()["events"]) == 1 and x["human_perceived"] == "UNPROVEN", "ack_not_human_perception")
    elif case_id == "S19":
        denied("HOLD_MISSING_PACKAGE", {**base, "package_state": "INVALID"})
        r = s.submit(proposed(s, "utterance_B")); s.actor_encode(event_id=r["event_id"], actor="N", perceived=True, rule_authorized=True)
        check(len(s.read()["actor_memory"]) == 1 and s.read()["actor_memory"][0]["key"][0] == r["event_id"], "only_admitted_perceived_event_encoded")
    elif case_id == "S20":
        r = s.submit(proposed(s, "I quit.")); p = s.user_projection(r["delivery_id"], user="A", hearing=False, vision=False)
        check(s.read()["events"][0]["words"] == "I quit." and p["heard_words"] is None, "closed_door_objective_speech_hidden")
    elif case_id == "S21":
        s.noncausal("sample"); check(s.read()["noncausal_display"] == ["sample"] and not s.read()["events"] and not s.read()["actor_memory"], "ui_noncausal_no_history")
    elif case_id == "S22":
        denied("HOLD_MISSING_ACTOR_AND_WORLD_EVENT_AUTHORITY", {**base, "third_party_ref": None})
        check(not s.read()["events"], "third_party_not_created")
    elif case_id == "S23":
        check(s.render_plan("VALID_EMPTY") == "RENDER_ADMISSION_VALID_EMPTY", "valid_empty_without_fallback")
        try: s.render_plan("UNAUTHORIZED")
        except Denied as exc: check(exc.code == "HOLD_MISSING_PLAN_AUTHORITY", "unissued_is_hold")
        else: raise AssertionError("unissued plan was not held")
        check(not s.read()["events"], "no_causal_ghost")
    elif case_id == "S24":
        check(s.user_projection(s.submit(base)["delivery_id"], user="A", vision=True)["recognized_labels"] == [], "no_hidden_vitamix_label")
        check("VITAMIX" not in str(s.read()["world"]), "unknown_not_world_label")
    elif case_id == "S25":
        r = s.submit(base)
        for _ in range(3): s.send(r["delivery_id"], displayed=True)
        check(s.read()["outbox"][r["delivery_id"]]["attempts"] == 3, "three_attempts_one_delivery_identity")
        check(len(s.read()["events"]) == 1 and s.read()["cursor"] == 1, "zero_new_causal_events")
    elif case_id == "S26":
        r = s.submit(base)
        s.actor_packet("N", ["cabinet_sound"]); s.actor_packet("child", ["user_joke"])
        p = s.user_projection(r["delivery_id"], user="player", vision=True)
        check(s.read()["actor_packets"]["N"] != s.read()["actor_packets"]["child"], "separate_actor_packets")
        check("user_joke" not in s.read()["actor_packets"]["N"] and p["seen_subject"] == "N", "no_joined_mind")
    elif case_id == "S27":
        base["candidate"] = s.candidate(atoms=[{"kind": "MATERIAL", "object_id": "obj:mug-1", "expected_position": "locked_cabinet"}], prose="move mug")
        denied("HOLD_MISSING_MATERIALIZATION_OWNER", base)
        check(s.read()["world"]["objects"]["obj:mug-1"] == "locked_cabinet" and not s.read()["outbox"], "no_physical_move_without_owner")
    elif case_id == "S28":
        denied("DEFER_MISSING_CAUSAL_TIME", {**base, "causal_time": None})
        check(not s.read()["events"], "no_wall_clock_fill")
    else:
        raise AssertionError("unexpected case " + case_id)
    after = s.snapshot()
    return {"id": case_id, "status": "PASS", "source_falsifier_blob": SOURCE_CASE_BLOB,
            "before_sha256": before, "after_sha256": after, "observations": trace,
            "event_count": len(s.read()["events"]), "outbox_count": len(s.read()["outbox"]),
            "cursor": s.read()["cursor"]}


@pytest.mark.parametrize("case_id", IDS, ids=IDS)
def test_sr_falsifier(case_id, tmp_path):
    evidence = run_case(case_id, tmp_path)
    assert evidence["status"] == "PASS"


def test_cold_replay_and_precommit_crash(tmp_path):
    s = Store(tmp_path)
    p = proposed(s)
    try:
        s.submit(p, crash="BEFORE_COMMIT")
    except SimulatedCrash:
        pass
    else:
        raise AssertionError("injected precommit crash not raised")
    assert s.read()["cursor"] == 0
    r = Store(tmp_path).submit(p)
    reopened = Store(tmp_path)
    assert reopened.submit(p) == r
    assert len(reopened.read()["events"]) == 1


def test_ack_is_not_human_perception(tmp_path):
    s = Store(tmp_path); r = s.submit(proposed(s))
    rec = s.send(r["delivery_id"], displayed=True, ack=True, access="YES")
    assert rec["client_displayed"] is True
    assert rec["transport_ack"] is True
    assert rec["opportunity_to_perceive"] == "POSSIBLE"
    assert rec["human_perceived"] == "UNPROVEN"


def test_real_subprocess_exit_then_cold_replay(tmp_path):
    import subprocess
    import sys
    code = ("from sr_prototype import Store,proposed; import os,sys; "
            "s=Store(sys.argv[1]); s.submit(proposed(s)); os._exit(79)")
    proc = subprocess.run([sys.executable, "-c", code, str(tmp_path)], cwd=Path(__file__).parent,
                          capture_output=True, text=True)
    assert proc.returncode == 79
    recovered = Store(tmp_path)
    assert len(recovered.read()["events"]) == len(recovered.read()["outbox"]) == 1
    rec = recovered.submit(proposed(recovered))
    assert rec["cursor"] == recovered.read()["cursor"] == 1
