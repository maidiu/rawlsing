# Sorok HQ312 OUT7 — owner actions

1. Commission bounded **OUT8 sourcefree restore-state repair**. Preserve OUT6 candidate and every inherited test byte; repair **strict aggregate ACK/client ACK cross-state congruence** in `validate_state` and require that materialized client deliveries have an actually reachable attempt/state relation (not zero attempts). Preserve legitimate historical receipts after revocation; an unkeyed digest can never attest arbitrary authorization provenance.
2. Separate author from this independent reviewer. Ask another I2 independent court to reproduce all 227 original/new cases plus its own hostiles after repair.
3. Keep S27 physical authority missing; keep stale two-writer overwrite non-goal. Neither historic RED may be laundered or rewritten green.
4. **OUTP**: competent owner must select L1 vs L2 legacy fixture grammar and A1 vs A2 ACK/offer policy prospectively; tests here do **not** decide those. Human perception still cannot be issued.
5. OUT5's original 14 unpublished source tests remain an **exact reproduction evidence HOLD**. Do not identify new 21 tests as replacements or retrospective OUT5 certification.
6. Real qualified ADP019 issuer, external anchor, user-perception witness, production and V3 remain unauthorized.
