# SOROK HQ312 OUT7 — Independent OUT6 source-free acceptance court

**Verdict: `REVIEW_REVISE__TWO_NEW_RESTORE_INVARIANT_DEFECTS__NO_ADOPTION`.**

- Commission startup verified direct remote SHA: `ff1d2240ef43c8de717abc751cd7dee739e26a73`.
- Candidate source from OUT6 author return `673233571b7d899c309dd26f9b9cd2508404c0b6`: native git blob `aa002cb634e81cb980820c14220a1ab55bc5e015` (verified staged file via actual `git hash-object`).
- Original OUT3 binary 22-test archive recovered independently from exact original stored bytes, native git blob `a9c4ee7344526fa335605d76d08def2ac5dcba2a`, SHA256 `fc876b665bd9af6328deec86aa66e93ec0eebf9048ca7a5a0d7d0630cd48bddd` verified; extracted 22 source exactly equals executed staged file.
- Original OUT4 29 source bytes compared against independently preserved OUT4 archive: exact match. Original 137 unchanged. All original source hashes in attached case matrix and identity receipt.
- New independent 21-test source written in fresh isolated stage; frozen expectations saved before first new execution, and separately dated after-failure cold checks explicitly flagged nonblind in supplemental freeze. No code modifications to candidate or inherited tests.
- Executed actual Linux Python 3.13.5, pytest pytest 9.0.2, Git git version 2.47.3, true subprocess `os._exit(79)` and cold `Journal.recover()` in separate interpreter.

## Executed court

| Court | PASS | FAIL | Total |
|---|---:|---:|---:|
| 04_original137 | 135 | 2 | 137 |
| 05_exact_OUT3_22 | 22 | 0 | 22 |
| 06_OUT4_29 | 29 | 0 | 29 |
| 07_OUT6_18 | 18 | 0 | 18 |
| 03_extended21 | 17 | 4 | 21 |
| 09_combined227 | 221 | 6 | 227 |

Inherited exact 137+22+29+18 independently reproduce **204 PASS / two known RED** (206 total, no skips). Full original+new court **221 PASS / six RED** (227 total, no skips).

### Retained historical REDs — exact original assertions unchanged
1. `test_s27_material_move_needs_world_owner` still expects physical mug movement without qualified world-owner authority; the safe source-free candidate refuses.
2. `test_replay_manual_two_writers_can_lose_first_committed_event` expects multiwriter reconciliation; candidate remains explicitly single-writer only. Do not modify/xfail these tests.

### Two NEW independent source-free gaps (4 literal failing tests)

**I08/I13 — forged aggregate ACK:** A STRICT admitted event has a globally queued emission and a real `DELIVERED_UNACKED` client receipt. Mutating only the restored aggregate state to `ACKNOWLEDGED, ack_count=1` is accepted by `OutboxPrototype.restore()` / `validate_state()` despite no client ACK. `Outbox.ack()` itself correctly demands an ACKed client; persisted validator does not enforce the same association. The forgery also passes `Journal.recover()` in an actually new Python process after the file's unkeyed `state_digest` is recomputed. **This is a transport-receipt consistency defect, NOT a decision that ACK requires prior client projection opportunity (OUTP A1/A2 remains HOLD).** A lawful positive client ACK and aggregate ACK still pass.

**I09/I14 — revocation tombstone licenses structurally unreachable client receipt:** Starting from one authorized viewer A, a snapshot is modified to contain a new `revoked_viewers[event]=['B']` and a fake B client delivery `NOT_SENT, attempts=0`. `restore()` accepts it, although the candidate's public `emit_to` always increments a created client delivery to attempts>=1 before it persists. Same forged snapshot passes cold `Journal.recover()` when SHA256 is recomputed. The invariant should refuse an impossible zero-attempt materialized client receipt and require independently checkable history for stronger provenance assertions. **No external immutable journal or cryptographic role issuer is imported; proving arbitrary adversarial full-snapshot history authenticity exceeds this test-only prototype.**

Seventeen other independently written OUT7 hostiles pass, covering client/global terminal ACK, duplicate ACK idempotence, positive failed retry and change of attempt ID, revoked sole-viewer refusal after cold process, lawful continuation with second authorized viewer, never-authorized ghost-viewer refusal, invalid snapshot ACK counters, failed-restore atomicity, false human-perception refusal, rehashed ghost cold rejection, and two real OS `_exit(79)` boundary recoveries. Full per-case evidence, JUnit, raw stdout and scripts are included.

### Scope / outcome

The new failures are reproducible in actual source-free API and disk journal code; therefore the strict pass prerequisite is not met. **`REVIEW_REVISE`**, not `REVIEW_PASS_SCOPED_SOURCEFREE_SINGLE_WRITER` and not semantic rejection of S01–S28.

The original OUT5 **unpublished fourteen test sources were not fetched or rerun**; local-reported counts are not independent evidence here. OUTP owner choices **legacy fixture L1/L2** and **transport ACK A1 / viewer-opportunity ACK A2** remain HOLD. ACK never proves human perception. No ADP019, original survey/model use, external custody, multiwriter durability, protected production change, or V3 operation is claimed.
