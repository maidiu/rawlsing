# OUT7 reproducibility

Pin OUT6 repaired source from `673233571b7d899c309dd26f9b9cd2508404c0b6`; native Git blob `aa002cb634e81cb980820c14220a1ab55bc5e015`. Recover original OUT3 published archive `a9c4ee7344526fa335605d76d08def2ac5dcba2a` with verified SHA256. In an isolated sourcefree stage copy exact source/test `.py` byte preimages recorded in `02_SOURCE_IDENTITIES.json`. Verify imports actually resolve into this isolated directory.

```bash
python -m pytest -q test_sr_28_falsifier_court.py test_rsr_independent.py test_rsr_cold_replay.py test_cold_repair.py test_rto_hostile.py test_out2_cross.py test_out3_independent_hostile.py test_out4_independent_harness.py test_out6_receipt_repair.py --junitxml=inherited206.xml
# 204 pass, 2 historic fail, exit 1
python -m pytest -q test_out7_independent_hostile.py --junitxml=new21.xml
# 17 pass, 4 new fail, exit 1
python -m pytest -q test_sr_28_falsifier_court.py test_rsr_independent.py test_rsr_cold_replay.py test_cold_repair.py test_rto_hostile.py test_out2_cross.py test_out3_independent_hostile.py test_out4_independent_harness.py test_out6_receipt_repair.py test_out7_independent_hostile.py --junitxml=combined227.xml
# 221 pass, 6 fail, exit 1
```

The full local tar archive contains all original staged code, JUnit XML and stdout, case matrix, prerequisite freezes, reviewer docs and a sanitized environment passport. The smaller GitHub core archive retains new test source, full combined + per-suite JUnit/stdout, per-case matrix and exact immutable SHA preimages.
