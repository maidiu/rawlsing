"""Independent OC3 actual-entrypoint hostile court. No test manufactures exceptions.

Published inherited files are unchanged. Every negative invokes the candidate's
public API; expected failures are written around that invocation, not injected.
"""
from __future__ import annotations

from dataclasses import replace
import copy
import pytest
from custody_protocol import (
    EscrowState, CustodyCapsule, Role, MockSigner,
    require_second_signature, verify_blind_pairing,
    detect_leakage, assert_no_leakage, SignatureError, IdentityMismatchError,
    RevocationError, PurposeViolationError, LedgerRollbackError,
    EditAfterFreezeError, BlindIDPairingError, ConflictError, LeakageError,
)
from dummy_corpus import build_dummy_corpus, build_capsule, build_model_visible_packet


def cap():
    return build_capsule("SOURCEFREE_TEST_ONLY", "OC3-frozen-frame", build_dummy_corpus())


def pair(c, ctx="oc3", nonce="n"):
    a = MockSigner("custodian-alice", Role.CUSTODIAN).sign(c.content_digest,ctx,nonce)
    b = MockSigner("adjudicator-bob", Role.SEMANTIC_ADJUDICATOR).sign(c.content_digest,ctx,nonce)
    return a,b


def full():
    e,c=EscrowState(),cap()
    e.commit(c);e.unblind(c.capsule_id,"holder");e.release(c.capsule_id)
    return e,c


def test_A01_unissued_holder_refused():
    e,c=EscrowState(),cap();e.commit(c)
    with pytest.raises(IdentityMismatchError):
        e.unblind(c.capsule_id,"any-person")


def test_A02_forbidden_role_registration_refused():
    e=EscrowState()
    with pytest.raises(ConflictError):
        e.authorize_holder("author",Role.SCENARIO_AUTHOR)


def test_A03_empty_holder_registration_refused():
    with pytest.raises(IdentityMismatchError):
        EscrowState().authorize_holder("   ",Role.CUSTODIAN)


def test_A04_revoked_holder_cannot_release():
    e,c=EscrowState(),cap();e.commit(c);e.authorize_holder("new",Role.CUSTODIAN)
    e.unblind(c.capsule_id,"new")
    del e.holder_roles["new"]
    with pytest.raises(RevocationError):
        e.release(c.capsule_id)


def test_A05_invalid_commits_refuse_at_entrypoint():
    e=EscrowState();c=cap()
    with pytest.raises(RevocationError): e.commit(replace(c,revoked=True))
    with pytest.raises(RevocationError): e.commit(replace(c,expired=True))
    with pytest.raises(PurposeViolationError): e.commit(replace(c,purpose="LIVE_MODEL_REQUEST"))
    assert not e.ledger and not e.committed


def test_A06_postcommit_inactivation_refused_at_unblind_without_ledger_change():
    for change, exc in [({"revoked":True}, RevocationError),({"expired":True},RevocationError),({"purpose":"LIVE_MODEL_REQUEST"},PurposeViolationError)]:
        e,c=EscrowState(),cap();e.commit(c)
        e.committed[c.capsule_id]=replace(c,**change)
        before=copy.deepcopy(e.ledger)
        with pytest.raises(exc): e.unblind(c.capsule_id,"holder")
        assert e.ledger==before and not e.unblinded


def test_B01_valid_countersignatures_bind_content():
    c=cap();a,b=pair(c)
    assert require_second_signature(c,a,b,c.content_digest,"oc3","n") is True


def test_B02_same_digest_distinct_capsule_id_replay():
    c=cap();new=replace(c,capsule_id=c.capsule_id+"-OTHER")
    assert new.content_digest==c.content_digest
    a,b=pair(c)
    with pytest.raises(SignatureError):
        require_second_signature(new,a,b,c.content_digest,"oc3","n")


def test_B03_signature_reuse_after_purpose_change():
    c=cap();a,b=pair(c)
    with pytest.raises(SignatureError):
        require_second_signature(replace(c,purpose="PROSPECTIVE_DESIGN_REVIEW"),a,b,c.content_digest,"oc3","n")


def test_B04_signature_reuse_after_lawful_digest_change():
    c=cap();a,b=pair(c)
    with pytest.raises(SignatureError):
        require_second_signature(replace(c,lawful_set_digest="forged-lawful-set"),a,b,c.content_digest,"oc3","n")


def test_B05_context_nonce_forgery_denied():
    c=cap();a,b=pair(c)
    with pytest.raises(SignatureError):
        require_second_signature(c,a,b,c.content_digest,"wrong-ctx","n")
    with pytest.raises(SignatureError):
        require_second_signature(c,a,b,c.content_digest,"oc3","wrong-nonce")


def test_B06_forged_signature_metadata_denied():
    c=cap();a,b=pair(c)
    with pytest.raises(SignatureError):
        require_second_signature(c,replace(a,content_digest="other"),b,c.content_digest,"oc3","n")


def test_C01_valid_append_only_ledger_coherent():
    e,c=full()
    assert e.verify_ledger_integrity() is True
    assert [v["op"] for v in e.ledger]==["COMMIT","UNBLIND","RELEASE"]


def test_C02_rollback_refused_without_state_damage():
    e,c=full();before=copy.deepcopy(e.ledger)
    with pytest.raises(LedgerRollbackError): e.rollback_ledger(1)
    assert e.ledger==before and e.verify_ledger_integrity()


def test_C03_ledger_mutation_detected():
    e,c=full();e.ledger[1]["holder"]="other"
    assert e.verify_ledger_integrity() is False


def test_C04_released_state_mutation_detected():
    e,c=full();e.released.clear()
    assert e.verify_ledger_integrity() is False


def test_C05_unblind_timestamp_mutation_invisible():
    e,c=full()
    e.unblinded[c.capsule_id]["unblinded_at"]=-999
    assert e.verify_ledger_integrity() is False


def test_C06_unblind_capsule_field_mutation_invisible():
    e,c=full()
    e.unblinded[c.capsule_id]["capsule_id"]="different-capsule"
    assert e.verify_ledger_integrity() is False


def test_D01_exact_ABC_and_coherent_joins():
    rows=[{"arm":arm,"public_nonce":"n","trial_id":f"t{i}","case_id":"case1","family_id":"family1"} for i,arm in enumerate("ABC")]
    assert verify_blind_pairing(rows) is True


def test_D02_duplicate_AABC_refused():
    with pytest.raises(BlindIDPairingError):
        verify_blind_pairing([{"arm":arm,"public_nonce":"n"} for arm in "AABC"])


def test_D03_duplicate_trial_ids_refused():
    with pytest.raises(BlindIDPairingError):
        verify_blind_pairing([{"arm":arm,"public_nonce":"n","trial_id":"same"} for arm in "ABC"])


def test_D04_whitespace_nonce_rejected():
    with pytest.raises(BlindIDPairingError):
        verify_blind_pairing([{"arm":arm,"public_nonce":"   "} for arm in "ABC"])


def test_D05_unhashable_arm_bad_exception():
    with pytest.raises(BlindIDPairingError):
        verify_blind_pairing([{"arm":arm,"public_nonce":"n"} for arm in [[],"B","C"]])


def test_E01_generated_projection_allowed():
    for c in build_dummy_corpus():
        assert detect_leakage(build_model_visible_packet(c))==[]
        assert_no_leakage(build_model_visible_packet(c))


def test_E02_direct_hidden_field_refused():
    with pytest.raises(LeakageError):
        assert_no_leakage({"hidden_origin":"source"})


def test_E03_invisible_format_character_key_refused():
    with pytest.raises(LeakageError):
        assert_no_leakage({"answer\u200b_key":"A"})


def test_E04_benign_word_not_blocked():
    assert detect_leakage({"note":"That charming character"})==[]


def test_E05_menu_wrong_value_type_admitted():
    with pytest.raises(LeakageError):
        assert_no_leakage({"public_projection":{"context":"safe"},"menu":[1,2,3],"request_id":"req"})


def test_E06_context_wrong_value_type_admitted():
    with pytest.raises(LeakageError):
        assert_no_leakage({"public_projection":{"context":["x","y"]},"menu":["OPTION_A"],"request_id":"req"})


def test_E07_U034F_note_alias_bypass():
    with pytest.raises(LeakageError):
        assert_no_leakage({"note":"The answ\u034fer_key is A"})


def test_F01_original_cap_deepcopy_after_commit():
    e,c=EscrowState(),cap();e.commit(c)
    object.__setattr__(c,"content_digest","changed-outside")
    assert e.verify_ledger_integrity() is True
    assert e.committed[c.capsule_id].content_digest!="changed-outside"


def test_F02_internal_frozen_capsule_mutation_detected():
    e,c=EscrowState(),cap();e.commit(c)
    object.__setattr__(e.committed[c.capsule_id],"content_digest","malicious")
    assert e.verify_ledger_integrity() is False


def test_F03_recommit_same_id_rejected():
    e,c=EscrowState(),cap();e.commit(c)
    with pytest.raises(EditAfterFreezeError): e.commit(replace(c,content_digest="other"))

# Honest capability-ceiling witnesses: these POSITIVE outcomes are explicitly
# *not* endorsements of real custody. No external issuer/source is present.
def test_Z01_any_fixture_caller_can_self_grant_custodian():
    e,c=EscrowState(),cap();e.commit(c)
    e.authorize_holder("self-registered",Role.CUSTODIAN)
    assert e.unblind(c.capsule_id,"self-registered")["holder"]=="self-registered"


def test_Z02_unsigned_fixture_capsule_can_be_released():
    e,c=EscrowState(),cap();e.commit(c)
    e.unblind(c.capsule_id,"holder")
    e.release(c.capsule_id)
    assert c.capsule_id in e.released
    # No signature object was created, registered or consulted on this path.


def test_Z03_declared_mock_roster_uses_public_derived_credentials():
    c=cap()
    forged_a=MockSigner("custodian-alice",Role.CUSTODIAN).sign(c.content_digest,"oc3","n")
    forged_b=MockSigner("adjudicator-bob",Role.SEMANTIC_ADJUDICATOR).sign(c.content_digest,"oc3","n")
    assert require_second_signature(c,forged_a,forged_b,c.content_digest,"oc3","n")
    # This witnesses the known explicit TEST_ONLY credential ceiling.
