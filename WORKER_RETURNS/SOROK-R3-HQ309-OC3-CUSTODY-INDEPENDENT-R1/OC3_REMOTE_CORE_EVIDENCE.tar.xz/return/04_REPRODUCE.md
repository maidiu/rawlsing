# SOROK OC3 actual execution and reproduction

Six pinned source files (3 OC1 / OCR1 / OC2 groups) are verified with exact Git-native SHA-1. Copy them and `test_oc3_independent_hostile.py` into an isolated folder with Python 3.13+ and pytest 9+. The tests import `custody_protocol` and `dummy_corpus` from that folder, not production modules. Tests were run by actual `python -m pytest`; expected failures do not originate from unconditional test raises.

```bash
python -m pytest -q test_custody_hostiles.py test_positive_lifecycle.py test_ocr1_independent_hostile.py test_oc2_regressions.py --junitxml=../oc3_inherited_95.xml
python -m pytest -q test_oc3_independent_hostile.py --junitxml=../oc3_new_hostile.xml
python -m pytest -q test_custody_hostiles.py test_positive_lifecycle.py test_ocr1_independent_hostile.py test_oc2_regressions.py test_oc3_independent_hostile.py --junitxml=../oc3_combined.xml
```

All three exit 1 because failures are retained. Counts 89/6, 26/10, 115/16 respectively. No `xfail`/skip or test editing. Reconcile the six old expectation conflicts by code path and exception; retain them in the JUnit instead of overriding historical artifacts. Reviewer-authored expectations were written before the first new pytest run after reading source and OCR1 outcomes—not independently timestamped or blind. `Z01..Z03` are passing demonstrations of intentionally untrusted fixture-only capacity, not trusted grants. The production/source/actor/real-holdout perimeter is excluded.
