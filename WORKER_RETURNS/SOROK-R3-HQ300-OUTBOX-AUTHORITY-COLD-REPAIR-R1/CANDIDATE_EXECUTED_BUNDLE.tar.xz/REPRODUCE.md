# HQ300 OUT — source-free reproduction only

Unpack this archive into a clean directory. Requires Python 3.13+ and pytest 9 (no private originals, LLM requests, source datasets, or imported governed V3 owner code).

```
python -m pytest -q test_sr_28_falsifier_court.py --junitxml=original_28_junit.xml
python -m pytest -q test_rsr_independent.py --junitxml=independent_17_junit.xml
python -m pytest -q test_rsr_cold_replay.py --junitxml=prior_cold_2_junit.xml
python -m pytest -q test_cold_repair.py --junitxml=repair_cold_junit.xml
```

The original authored S01-S28 tests and RSR independent 17 + original RSR two cold-process tests are identical Git blob bytes to the pinned published inputs. The *candidate module* `outbox_prototype.py` differs and is deliberately not an accepted V3 implementation.

Expected observed current candidate: 27/28 (S27 fails because unlicensed `world_owner="NADIA"` is NOT accepted); 17/17; 2/2 original RSR cold harness; 9/9 new candidate including two genuine `os._exit(79)` crash boundaries.

The new candidate's `Journal` owns the fsync/rename operation, unlike the prior RSR harness which manually persisted a snapshot. This is a **single-writer POSIX-like local filesystem** source-free experiment. Filesystem/platform power-loss and cross-process serialization are not asserted.

`python -m pytest` with `--junitxml` generates raw XML; recorded XML from the executed run is in this bundle. The stdout files record exact pytest summaries and failures; exit status for original suite and combined suite is 1, all other suites 0.

Do not infer the occurrence of any physical event, accepted ADP019 event, receipt, human perception, ADP016 actor memory, or exactly-once transport from the source-free fixture.
