"""Candidate source-free occurrence/outbox repair. NOT an ADP019 implementation.

A missing optional field in a legacy S01-S28 fixture receives only a *marked*
source-free compatibility grant. Explicit None/empty authority is refused.
A strict envelope requires an externally supplied capability decision; token-shaped
strings and narrative content never grant world/actor/renderer authority.
"""
from __future__ import annotations
import copy, hashlib, json, os, tempfile
from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

class OccurrenceState(str, Enum):
    CANDIDATE="CANDIDATE"; ADMITTED="ADMITTED"; EMITTED="EMITTED"; DELIVERED="DELIVERED"; PERCEIVED="PERCEIVED"
class DeliveryState(str, Enum):
    NOT_SENT="NOT_SENT"; ADMITTED_UNDELIVERED="ADMITTED_UNDELIVERED"; DELIVERED_UNACKED="DELIVERED_UNACKED"; ACKNOWLEDGED="ACKNOWLEDGED"; FAILED="FAILED"

_MISSING=object()
def _canonical(data):
    return json.dumps(data,sort_keys=True,separators=(',', ':'),ensure_ascii=False,allow_nan=False)
def _hash(data):
    return hashlib.sha256(_canonical(data).encode('utf8')).hexdigest()
def _safe_copy(value):
    try: return json.loads(_canonical(value))
    except (ValueError,TypeError,OverflowError): return None

@dataclass
class OccurrenceLedger:
    _events: list[dict]=field(default_factory=list)
    _by_id: dict[str,dict]=field(default_factory=dict)
    admission_decider: Optional[Callable[[dict],bool]]=None
    last_refusal: Optional[str]=None
    @property
    def events(self): return copy.deepcopy(self._events)
    def count(self): return len(self._events)
    def get(self,occurrence_id):
        return next((copy.deepcopy(e) for e in self._events if e['occurrence_id']==occurrence_id),None)
    def admit(self,candidate):
        self.last_refusal=None
        if not isinstance(candidate,dict) or not isinstance(candidate.get('candidate_id'),str) or not candidate['candidate_id']:
            self.last_refusal='MISSING_CANDIDATE_ID';return None
        if not isinstance(candidate.get('payload',{}),dict):
            self.last_refusal='INVALID_PAYLOAD';return None
        try: immutable=_safe_copy(candidate)
        except Exception: immutable=None
        if immutable is None:
            self.last_refusal='INVALID_CANONICAL_BYTES';return None
        p=immutable.get('payload',{})
        if any(k.startswith('objective_') or k in ('world_owner','material_effect','actor_memory_update','physical_transition') for k in p):
            self.last_refusal='UNLICENSED_EFFECT_SIDECAR';return None
        explicit_source='source_refs' in immutable
        source_refs=immutable.get('source_refs',['SOURCEFREE_FIXTURE_ONLY'])
        if not isinstance(source_refs,list) or not source_refs or not all(isinstance(x,str) and x for x in source_refs):
            self.last_refusal='MISSING_SOURCE_AUTHORITY';return None
        explicit_time='causal_time' in immutable
        causal_time=immutable.get('causal_time','SOURCEFREE_FIXTURE_UNDATED')
        if causal_time is None or causal_time=='' or isinstance(causal_time,(list,dict)):
            self.last_refusal='DEFER_MISSING_CAUSAL_TIME';return None
        # Only a fully bound envelope can invoke an injected adjudicator.
        strict=immutable.get('envelope_mode')=='STRICT'
        if strict:
            try:
                datetime.fromisoformat(causal_time)
            except (ValueError,TypeError):
                self.last_refusal='INVALID_TYPED_CAUSAL_TIME';return None
            for parent_id in immutable.get('parent_refs',[]):
                parent=self.get(parent_id)
                if not parent:
                    self.last_refusal='PARENT_EVENT_NOT_ADMITTED';return None
                try:
                    if datetime.fromisoformat(parent['causal_time'])>datetime.fromisoformat(causal_time):
                        self.last_refusal='CAUSAL_TIME_PRECEDES_PARENT';return None
                except (ValueError,TypeError):
                    self.last_refusal='UNCOMPARABLE_PARENT_CAUSAL_TIME';return None
            required=['artifact_id','artifact_digest','issuer_ref','authority_ref','release_ref','participant_refs','parent_refs','candidate_id','causal_time','source_refs']
            if any(k not in immutable or immutable[k] in (None,'') for k in required):
                self.last_refusal='INCOMPLETE_AUTHORITY_ENVELOPE';return None
            if not explicit_source or not explicit_time or not isinstance(immutable['participant_refs'],list) or not isinstance(immutable['parent_refs'],list):
                self.last_refusal='INCOMPLETE_AUTHORITY_ENVELOPE';return None
            if self.admission_decider is None or not self.admission_decider(copy.deepcopy(immutable)):
                self.last_refusal='NO_COMPETENT_ADMISSION_WITNESS';return None
            grade='SOURCEFREE_BOUND_DECIDER_NOT_OWNER'
        else:
            # Unqualified, source-free compatibility fixtures are NEVER issued as authority.
            grade='SOURCEFREE_LEGACY_FIXTURE_NO_OWNER_AUTHORITY'
            if explicit_source and any(x.strip()=='' for x in source_refs):
                self.last_refusal='INVALID_SOURCE_REF';return None
        identity={k:immutable.get(k) for k in ('candidate_id','artifact_id','artifact_digest','issuer_ref','authority_ref','release_ref','participant_refs','parent_refs','causal_time','source_refs','envelope_mode')}
        identity['payload']=p
        identity['source_refs']=source_refs
        identity['causal_time']=causal_time
        identity['admission_grade']=grade
        digest=_hash(identity)
        existing=self._by_id.get(candidate['candidate_id'])
        if existing:
            if existing['identity_digest']==digest: return copy.deepcopy(existing)
            self.last_refusal='CANDIDATE_IDENTITY_CONFLICT';return None
        event={'occurrence_id':f'OCC-{len(self._events)+1:04d}', 'candidate_id':candidate['candidate_id'],
               'content_hash':_hash(p),'identity_digest':digest,'payload':p,'state':OccurrenceState.ADMITTED.value,
               'source_refs':source_refs,'causal_time':causal_time,'artifact_id':immutable.get('artifact_id'),
               'artifact_digest':immutable.get('artifact_digest'),'issuer_ref':immutable.get('issuer_ref'),
               'authority_ref':immutable.get('authority_ref'),'release_ref':immutable.get('release_ref'),
               'participant_refs':immutable.get('participant_refs',[]),'parent_refs':immutable.get('parent_refs',[]),
               'admission_grade':grade}
        self._events.append(copy.deepcopy(event));self._by_id[event['candidate_id']]=self._events[-1]
        return copy.deepcopy(event)
    def restore_events(self,events):
        self._events=copy.deepcopy(events)
        self._by_id={e['candidate_id']:e for e in self._events}
        if len(self._by_id)!=len(self._events):raise ValueError('DUPLICATED_CANDIDATE_ID')
        for index,e in enumerate(self._events,start=1):
            if e.get('occurrence_id')!=f'OCC-{index:04d}' or e.get('state')!='ADMITTED' or e.get('content_hash')!=_hash(e.get('payload')):
                raise ValueError('CORRUPT_EVENT_INTEGRITY')
            keys=('candidate_id','artifact_id','artifact_digest','issuer_ref','authority_ref','release_ref','participant_refs','parent_refs','causal_time','source_refs')
            identity={k:e.get(k) for k in keys}
            identity['envelope_mode']='STRICT' if e['admission_grade']=='SOURCEFREE_BOUND_DECIDER_NOT_OWNER' else None
            if identity['envelope_mode'] is None:
                for k in ('participant_refs','parent_refs'):
                    if identity[k]==[]:identity[k]=None
            identity['payload']=e['payload'];identity['admission_grade']=e['admission_grade']
            if e.get('identity_digest')!=_hash(identity):raise ValueError('CORRUPT_EVENT_IDENTITY_DIGEST')

@dataclass
class Outbox:
    deliveries: dict[str,dict]=field(default_factory=dict)
    ledger: Optional[OccurrenceLedger]=None
    viewers: dict[str,set[str]]=field(default_factory=dict)
    client_deliveries: dict[str,dict]=field(default_factory=dict)
    def authorize_viewer(self,occurrence_id,viewer_id):
        if not self.ledger or not self.ledger.get(occurrence_id):return False
        self.viewers.setdefault(occurrence_id,set()).add(viewer_id);return True
    def emit_to(self,occurrence_id,viewer_id):
        if not self.ledger or not self.ledger.get(occurrence_id) or viewer_id not in self.viewers.get(occurrence_id,set()):return None
        key=durable_delivery_id(occurrence_id,viewer_id)
        e=self.client_deliveries.setdefault(key,{'event_id':occurrence_id,'viewer_id':viewer_id,'delivery_id':key,'state':DeliveryState.NOT_SENT.value,'attempts':0,'ack_count':0,'last_attempt_id':None})
        if e['state'] in (DeliveryState.NOT_SENT.value,DeliveryState.FAILED.value):
            e['attempts']+=1;e['last_attempt_id']=durable_attempt_id(occurrence_id,viewer_id,e['attempts'])
            e['state']=DeliveryState.ADMITTED_UNDELIVERED.value
        return copy.deepcopy(e)
    def deliver_to(self,occurrence_id,viewer_id):
        e=self.client_deliveries.get(durable_delivery_id(occurrence_id,viewer_id))
        if not e:return None
        if e['state']==DeliveryState.ADMITTED_UNDELIVERED.value:e['state']=DeliveryState.DELIVERED_UNACKED.value
        return copy.deepcopy(e)
    def ack_to(self,occurrence_id,viewer_id):
        e=self.client_deliveries.get(durable_delivery_id(occurrence_id,viewer_id))
        if not e:return None
        if e['state']==DeliveryState.DELIVERED_UNACKED.value:e['state']=DeliveryState.ACKNOWLEDGED.value;e['ack_count']+=1
        return copy.deepcopy(e)
    def fail_to(self,occurrence_id,viewer_id):
        e=self.client_deliveries.get(durable_delivery_id(occurrence_id,viewer_id))
        if not e:return None
        e['state']=DeliveryState.FAILED.value
        return copy.deepcopy(e)
    def emit(self,occurrence_id,viewer_id=None):
        if self.ledger is None or self.ledger.get(occurrence_id) is None:return DeliveryState.NOT_SENT
        admitted=self.ledger.get(occurrence_id)
        if admitted['admission_grade']=='SOURCEFREE_BOUND_DECIDER_NOT_OWNER' and viewer_id is None:return DeliveryState.NOT_SENT
        if viewer_id is not None and viewer_id not in self.viewers.get(occurrence_id,set()):return DeliveryState.NOT_SENT
        entry=self.deliveries.setdefault(occurrence_id,{'state':DeliveryState.NOT_SENT.value,'ack_count':0,'attempts':0})
        if entry['state'] in (DeliveryState.NOT_SENT.value,DeliveryState.FAILED.value):
            entry['state']=DeliveryState.ADMITTED_UNDELIVERED.value;entry['attempts']+=1
        return DeliveryState(entry['state'])
    def deliver(self,occurrence_id):
        e=self.deliveries.get(occurrence_id)
        if e and e['state']==DeliveryState.ADMITTED_UNDELIVERED.value:e['state']=DeliveryState.DELIVERED_UNACKED.value
        return DeliveryState(e['state']) if e else DeliveryState.NOT_SENT
    def ack(self,occurrence_id):
        e=self.deliveries.get(occurrence_id)
        if e and e['state']==DeliveryState.DELIVERED_UNACKED.value:e['state']=DeliveryState.ACKNOWLEDGED.value;e['ack_count']+=1
        return DeliveryState(e['state']) if e else DeliveryState.NOT_SENT
    def fail(self,occurrence_id):
        e=self.deliveries.get(occurrence_id)
        if e:e['state']=DeliveryState.FAILED.value
        return DeliveryState(e['state']) if e else DeliveryState.NOT_SENT
    def retry(self,occurrence_id):
        e=self.deliveries.get(occurrence_id)
        if e and e['state']==DeliveryState.FAILED.value:e['state']=DeliveryState.ADMITTED_UNDELIVERED.value;e['attempts']+=1
        return DeliveryState(e['state']) if e else DeliveryState.NOT_SENT

@dataclass
class UserProjection:
    perceived:dict[str,list[str]]=field(default_factory=dict)
    opportunity:dict[str,list[str]]=field(default_factory=dict)
    ledger:Optional[OccurrenceLedger]=None
    outbox:Optional[Outbox]=None
    perception_decider:Optional[Callable[[str,str,Any],bool]]=None
    def offer(self,user_id,occurrence_id):
        if self.ledger is None or self.ledger.get(occurrence_id) is None:return False
        admitted=self.ledger.get(occurrence_id)
        if admitted['admission_grade']=='SOURCEFREE_BOUND_DECIDER_NOT_OWNER':
            if not self.outbox or user_id not in self.outbox.viewers.get(occurrence_id,set()):return False
            d=self.outbox.client_deliveries.get(durable_delivery_id(occurrence_id,user_id))
            if not d or d['state'] not in (DeliveryState.DELIVERED_UNACKED.value,DeliveryState.ACKNOWLEDGED.value):return False
        # Prototype offer creates prospective availability, not delivery/actual perception.
        self.opportunity.setdefault(user_id,[])
        if occurrence_id in self.opportunity[user_id]:return False
        self.opportunity[user_id].append(occurrence_id)
        return True
    def perceive(self,user_id,occurrence_id,*,perception_witness=None):
        if not self.has_opportunity(user_id,occurrence_id):return False
        if not self.outbox or not self.outbox.deliveries.get(occurrence_id):return False
        if self.outbox.deliveries[occurrence_id]['state'] not in (DeliveryState.DELIVERED_UNACKED.value,DeliveryState.ACKNOWLEDGED.value):return False
        if perception_witness is None or self.perception_decider is None or not self.perception_decider(user_id,occurrence_id,perception_witness):return False  # No owner-validated human perception in this sourcefree test
        self.perceived.setdefault(user_id,[])
        if occurrence_id in self.perceived[user_id]:return False
        self.perceived[user_id].append(occurrence_id);return True
    def has_opportunity(self,user_id,occurrence_id):return occurrence_id in self.opportunity.get(user_id,[])
    def has_perceived(self,user_id,occurrence_id):return occurrence_id in self.perceived.get(user_id,[])

@dataclass
class OutboxPrototype:
    ledger:OccurrenceLedger=field(default_factory=OccurrenceLedger)
    outbox:Outbox=field(default_factory=Outbox)
    projection:UserProjection=field(default_factory=UserProjection)
    world_state:dict=field(default_factory=dict)
    _snapshot:dict=field(default_factory=dict)
    def __post_init__(self):
        self.outbox.ledger=self.ledger;self.projection.ledger=self.ledger;self.projection.outbox=self.outbox
    def snapshot(self):
        self._snapshot=copy.deepcopy({'ledger':self.ledger.events,'outbox':self.outbox.deliveries,
             'viewers':{k:sorted(v) for k,v in self.outbox.viewers.items()},'client_deliveries':self.outbox.client_deliveries,
             'perceived':self.projection.perceived,'opportunity':self.projection.opportunity,'world':self.world_state})
        return copy.deepcopy(self._snapshot)
    def restore(self,snap):
        doc=copy.deepcopy(snap)
        self.ledger.restore_events(doc.get('ledger',[]))
        self.outbox.deliveries=doc.get('outbox',{});self.outbox.viewers={k:set(v) for k,v in doc.get('viewers',{}).items()};self.outbox.client_deliveries=doc.get('client_deliveries',{})
        self.projection.perceived=doc.get('perceived',{});self.projection.opportunity=doc.get('opportunity',{})
        self.world_state=doc.get('world',{})
        self.validate_state()
    def validate_state(self):
        ids={e['occurrence_id'] for e in self.ledger.events}
        if any(eid not in ids for eid in self.outbox.deliveries):raise ValueError('GHOST_OUTBOX_STATE')
        for eid,users in self.outbox.viewers.items():
            if eid not in ids or not all(isinstance(x,str) and x for x in users):raise ValueError('GHOST_VIEWER_AUTHORIZATION')
        for key,d in self.outbox.client_deliveries.items():
            eid=d.get('event_id');viewer=d.get('viewer_id')
            if eid not in ids or viewer not in self.outbox.viewers.get(eid,set()) or key!=durable_delivery_id(eid,viewer):raise ValueError('GHOST_CLIENT_DELIVERY')
            if d.get('delivery_id')!=key or d.get('attempts',-1)<0:raise ValueError('BAD_DELIVERY_IDENTITY')
        for user,eids in {**self.projection.perceived,**self.projection.opportunity}.items():
            if any(eid not in ids for eid in eids):raise ValueError('GHOST_PROJECTION_STATE')
        if self.world_state:
            # Snapshot can carry synthetic world-state for legacy authored S tests,
            # but the durable journal will never persist it as objective truth.
            pass

def make_prototype():return OutboxPrototype()

class Journal:
    """Single-writer source-free durability experiment; no accepted owner/cross-worker law.
    One snapshot includes *both* event and outbox intent; tmp write+fsync,
    atomic same-directory rename and directory fsync. No claim for exotic filesystems.
    """
    def __init__(self,path): self.path=Path(path)
    def recover(self):
        p=make_prototype()
        if self.path.exists():
            d=json.loads(self.path.read_text())
            if d.get('schema')!='OUTBOX_F2_JOURNAL_V1' or _hash(d.get('state'))!=d.get('state_digest'):raise ValueError('BAD_JOURNAL_DIGEST')
            p.restore(d['state'])
        return p
    def commit(self,p,crash_boundary=None):
        if p.world_state:raise ValueError('WORLD_STATE_REQUIRES_EXTERNAL_OWNER')
        p.validate_state()
        state=p.snapshot();receipt={'schema':'OUTBOX_F2_JOURNAL_V1','state':state,'state_digest':_hash(state)}
        self.path.parent.mkdir(parents=True,exist_ok=True)
        fd,temp=tempfile.mkstemp(prefix='.outbox-pending-',dir=str(self.path.parent))
        try:
            with os.fdopen(fd,'w',encoding='utf8') as f:
                f.write(_canonical(receipt));f.flush();os.fsync(f.fileno())
            if crash_boundary=='BEFORE_RENAME':os._exit(79)
            os.replace(temp,self.path)
            dirfd=os.open(str(self.path.parent),os.O_RDONLY)
            try:os.fsync(dirfd)
            finally:os.close(dirfd)
            if crash_boundary=='AFTER_COMMIT':os._exit(79)
        finally:
            if os.path.exists(temp):os.unlink(temp)
    def admit_and_queue(self,candidate,viewer_id=None,crash_boundary=None):
        p=self.recover();event=p.ledger.admit(candidate)
        if event is None:return None,p.ledger.last_refusal
        eid=event['occurrence_id']
        if viewer_id is not None:
            if not p.outbox.authorize_viewer(eid,viewer_id):return None,'VIEWER_NOT_AUTHORIZED'
        state=p.outbox.emit(eid,viewer_id=viewer_id)
        if state==DeliveryState.NOT_SENT:return None,'EMISSION_REFUSED'
        if viewer_id is not None:
            if p.outbox.emit_to(eid,viewer_id) is None:return None,'CLIENT_INTENT_REFUSED'
        self.commit(p,crash_boundary=crash_boundary)
        return event,None

def durable_delivery_id(occurrence_id,viewer_id):
    return 'DEL-'+_hash([occurrence_id,viewer_id])[:20]

def durable_attempt_id(occurrence_id,viewer_id,attempt):
    return 'ATT-'+_hash([occurrence_id,viewer_id,attempt])[:20]
