# GSS 1972 Semantic Authority Review Notes

This note records the question-by-question semantic review of the GSS 1972 codebook.

## Scope

- Codebook rows reviewed: 216
- Semantic overlay rows: 216
- Reviewed overlay file:
  - `gss1972_semantic_authority_overlay.csv`

## Review outcome

The question-by-question pass preserved the existing conservative evidence boundary, but sharpened several rows that were previously sitting in generic buckets.

- Rows tightened from generic buckets into specific semantic subroles: 19

### Revised to more specific semantic subroles

- `comprend` -> `survey_process_quality`
- `courts` -> `justice_policy_orientation`
- `fair` -> `subjective_evaluation`
- `fepres` -> `gender_equality_policy`
- `fund` -> `religious_orientation_coordinate`
- `happy` -> `subjective_wellbeing_coordinate`
- `health` -> `health_state_coordinate`
- `other` -> `religious_affiliation_coordinate`
- `partyid` -> `political_identity_coordinate`
- `pres68` -> `political_choice_coordinate`
- `racinteg` -> `racial_projection_coordinate`
- `racobjct` -> `racial_integration_preference`
- `racpres` -> `racial_representational_policy`
- `racseg` -> `racial_segregation_policy`
- `region_7222` -> `geographic_region_coordinate`
- `size` -> `geographic_place_size_coordinate`
- `spaneng` -> `survey_process_language`
- `spdeg` -> `spouse_social_position_coordinate`
- `speduc` -> `spouse_social_position_coordinate`

## What stayed conservative

- Administrative rows remain administrative metadata.
- Household roster rows remain household context.
- Life-course rows remain unsigned life-course coordinates.
- Status / coding variables remain unsigned status or coding semantics.
- Directionality is still only assigned when the response semantics justify it.

## Practical takeaway

This review makes the 1972 semantic contract more specific without inventing new evidence where the codebook does not support it.
