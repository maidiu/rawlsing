#!/usr/bin/env python3
"""Add v5 structural columns to questions_master_drivers.csv without deleting legacy columns."""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil

import pandas as pd
import yaml


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--drivers", required=True)
    ap.add_argument("--spec", required=True)
    args = ap.parse_args()

    drivers_path = Path(args.drivers)
    spec_path = Path(args.spec)

    spec = yaml.safe_load(spec_path.read_text(encoding="utf-8"))
    required = spec.get("questions_master_drivers_required_new_columns", [])

    if not drivers_path.exists():
        raise FileNotFoundError(drivers_path)

    backup = drivers_path.with_suffix(drivers_path.suffix + ".bak_v5_schema")
    if spec.get("backup_before_writing", True):
        shutil.copy(drivers_path, backup)

    df = pd.read_csv(drivers_path, dtype=str, keep_default_na=False)

    for col in required:
        if col not in df.columns:
            df[col] = ""

    df.to_csv(drivers_path, index=False)
    print(f"Updated {drivers_path}")
    print(f"Backup: {backup}")
    print(f"Added/confirmed columns: {len(required)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
