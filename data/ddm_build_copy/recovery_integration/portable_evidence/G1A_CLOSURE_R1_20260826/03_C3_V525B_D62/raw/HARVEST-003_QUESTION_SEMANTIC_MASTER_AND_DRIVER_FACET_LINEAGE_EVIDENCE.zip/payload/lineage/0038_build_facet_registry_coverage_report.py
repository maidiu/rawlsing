#!/usr/bin/env python3
"""Compare facet registry coverage against the live driver table."""

from __future__ import annotations

import argparse
import csv
from collections import Counter
from pathlib import Path

import pandas as pd
import yaml


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--final-codebooks-dir", required=True)
    ap.add_argument("--reports-dir", required=True)
    args = ap.parse_args()

    final_dir = Path(args.final_codebooks_dir)
    reports_dir = Path(args.reports_dir)
    drivers_path = final_dir / "questions_master_drivers.csv"
    registry_path = final_dir / "structural_registries" / "driver_facet_registry.yaml"

    csv.field_size_limit(2**31 - 1)
    df = pd.read_csv(drivers_path, dtype=str, keep_default_na=False)
    registry = yaml.safe_load(registry_path.read_text(encoding="utf-8"))
    facet_registry = registry.get("driver_facets", {})

    if "driver_id" in df.columns:
        driver_ids = df["driver_id"].astype(str)
    else:
        driver_ids = pd.Series([""] * len(df), index=df.index, dtype=str)
    if "final_driver_id" in df.columns:
        final_driver_ids = df["final_driver_id"].astype(str)
    else:
        final_driver_ids = pd.Series([""] * len(df), index=df.index, dtype=str)
    df["effective_driver_id"] = driver_ids.where(driver_ids.ne(""), final_driver_ids)
    if "driver_facet_id" in df.columns:
        df["driver_facet_id"] = df["driver_facet_id"].astype(str)
    else:
        df["driver_facet_id"] = pd.Series([""] * len(df), index=df.index, dtype=str)

    rows = []
    for driver, spec in facet_registry.items():
        driver_rows = df[df["effective_driver_id"].astype(str).eq(driver)]
        facet_counts = Counter(driver_rows["driver_facet_id"].astype(str))
        blank_facet_rows = int((driver_rows["driver_facet_id"].astype(str).eq("")).sum())
        rows.append(
            {
                "driver": driver,
                "driver_rows": len(driver_rows),
                "blank_facet_rows": blank_facet_rows,
                "distinct_facets_in_data": len([k for k in facet_counts if k]),
                "registry_facet_count": len(spec.get("facets", []) or []),
                "top_facet_1": facet_counts.most_common(1)[0][0] if facet_counts else "",
                "top_facet_1_count": int(facet_counts.most_common(1)[0][1]) if facet_counts else 0,
                "top_facet_2": facet_counts.most_common(2)[1][0] if len(facet_counts.most_common(2)) > 1 else "",
                "top_facet_2_count": int(facet_counts.most_common(2)[1][1]) if len(facet_counts.most_common(2)) > 1 else 0,
            }
        )

    out = pd.DataFrame(rows).sort_values(["blank_facet_rows", "driver_rows"], ascending=[False, False])
    out_csv = reports_dir / "facet_registry_coverage.csv"
    out_md = reports_dir / "facet_registry_coverage.md"
    out.to_csv(out_csv, index=False)

    md_lines = [
        "# Facet Registry Coverage",
        "",
        f"Drivers in registry: {len(facet_registry)}",
        f"Live rows: {len(df)}",
        "",
        "| Driver | Driver rows | Blank facet rows | Distinct facets in data | Registry facet count | Top facet 1 | Top facet 2 |",
        "| --- | ---: | ---: | ---: | ---: | --- | --- |",
    ]
    for row in rows:
        md_lines.append(
            f"| {row['driver']} | {row['driver_rows']} | {row['blank_facet_rows']} | {row['distinct_facets_in_data']} | {row['registry_facet_count']} | "
            f"{row['top_facet_1']} ({row['top_facet_1_count']}) | {row['top_facet_2']} ({row['top_facet_2_count']}) |"
        )
    md_lines.extend([
        "",
        "## Notes",
        "",
        "- Blank facet rows are the remaining broad-layer rows that still need a narrower facet assignment.",
        "- Registry facet count is the number of facet IDs seeded under each driver in `driver_facet_registry.yaml`.",
        "- This report is a working gap map, not a final truth table.",
    ])
    out_md.write_text("\n".join(md_lines), encoding="utf-8")

    print(f"Wrote {out_csv}")
    print(f"Wrote {out_md}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
