#!/usr/bin/env python3
from __future__ import annotations

import csv
import re
import unicodedata
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SEMANTIC_MASTER = ROOT / "data" / "final_codebooks" / "questions_master_semantic.csv"
DRIVER_MASTER = ROOT / "data" / "final_codebooks" / "questions_master_drivers.csv"
DRIVER_INDEX = ROOT / "data" / "final_codebooks" / "driver_index_semantic.csv"


def clean_text(value: str | None) -> str:
    if value is None:
        return ""
    text = unicodedata.normalize("NFKC", str(value)).strip()
    text = text.replace("’", "'").replace("“", '"').replace("”", '"')
    return text


def normalize(value: str | None) -> str:
    text = clean_text(value).lower()
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def slugify(value: str | None) -> str:
    text = clean_text(value).lower()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_")
    return text


def is_metadata_row(row: dict[str, str]) -> bool:
    scope = normalize(row.get("semantic_scope"))
    if scope == "metadata":
        return True
    semantic_id = normalize(row.get("semantic_content_id"))
    if semantic_id.startswith("metadata::"):
        return True
    display = normalize(row.get("display_text"))
    if not display:
        return True
    if display.startswith("country") or display.startswith("wave") or display.startswith("year"):
        return True
    if any(token in display for token in (
        "interviewer",
        "respondent number",
        "reference number",
        "constructed",
        "administrative",
        "sample",
        "weight",
        "stratum",
        "psu",
        "province",
        "district",
        "county",
        "region",
        "case number",
        "gender [interviewer",
    )):
        return True
    return False


def final_driver_for_row(row: dict[str, str]) -> tuple[str, str, str, str]:
    shared = clean_text(row.get("semantic_shared_driver"))
    regional = clean_text(row.get("semantic_regional_driver"))
    semantic_cluster_id = clean_text(row.get("semantic_cluster_id")) or clean_text(row.get("semantic_content_id")) or clean_text(row.get("var_name"))
    semantic_content_id = clean_text(row.get("semantic_content_id"))
    semantic_content_description = clean_text(row.get("semantic_content_description"))
    semantic_scope = normalize(row.get("semantic_scope"))

    if shared:
        return shared, "shared_backbone", shared, "shared_glossary"
    if regional:
        return regional, "regional_subdriver", regional, "regional_glossary"
    if semantic_scope == "metadata" or semantic_content_id.startswith("METADATA::") or is_metadata_row(row):
        driver_id = f"metadata::{slugify(semantic_content_id or semantic_cluster_id or row.get('var_name') or row.get('item_id'))}"
        label = semantic_content_description or clean_text(row.get("display_text")) or clean_text(row.get("var_name")) or driver_id
        return driver_id, "metadata", label, "semantic_master"

    driver_id = f"idio::{slugify(semantic_cluster_id)}"
    label = semantic_content_description or clean_text(row.get("display_text")) or clean_text(row.get("var_name")) or semantic_cluster_id
    return driver_id, "idiosyncratic_cluster", label, "semantic_cluster"


def main() -> None:
    csv.field_size_limit(10_000_000)
    rows: list[dict[str, str]] = []
    with SEMANTIC_MASTER.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    final_rows: list[dict[str, str]] = []
    buckets: dict[str, dict[str, object]] = defaultdict(lambda: {
        "driver_id": "",
        "driver_scope": "",
        "driver_label": "",
        "driver_origin": "",
        "sources": set(),
        "waves": set(),
        "item_ids": [],
        "var_names": [],
        "labels": [],
        "count": 0,
    })

    for row in rows:
        driver_id, driver_scope, driver_label, driver_origin = final_driver_for_row(row)
        out = dict(row)
        out["final_driver_id"] = driver_id
        out["final_driver_scope"] = driver_scope
        out["final_driver_label"] = driver_label
        out["final_driver_origin"] = driver_origin
        final_rows.append(out)

        bucket = buckets[driver_id]
        bucket["driver_id"] = driver_id
        bucket["driver_scope"] = driver_scope
        bucket["driver_label"] = driver_label
        bucket["driver_origin"] = driver_origin
        bucket["sources"].add(clean_text(row.get("source")))
        bucket["waves"].add(f"{clean_text(row.get('source'))}:{clean_text(row.get('wave'))}")
        bucket["item_ids"].append(clean_text(row.get("item_id")))
        bucket["var_names"].append(clean_text(row.get("var_name")))
        bucket["labels"].append(clean_text(row.get("display_text")))
        bucket["count"] += 1

    final_rows.sort(key=lambda r: (r["source"], r["wave"], r["var_name"]))

    with DRIVER_MASTER.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(final_rows[0].keys()))
        writer.writeheader()
        writer.writerows(final_rows)

    index_rows: list[dict[str, str]] = []
    for driver_id, info in sorted(buckets.items(), key=lambda kv: (-int(kv[1]["count"]), kv[0])):
        index_rows.append({
            "driver_id": driver_id,
            "driver_scope": clean_text(info["driver_scope"]),
            "driver_label": clean_text(info["driver_label"]),
            "driver_origin": clean_text(info["driver_origin"]),
            "row_count": str(info["count"]),
            "source_count": str(len(info["sources"])),
            "sources": " | ".join(sorted(info["sources"])),
            "wave_count": str(len(info["waves"])),
            "waves": " | ".join(sorted(info["waves"])),
            "sample_item_ids": " | ".join(info["item_ids"][:12]),
            "sample_var_names": " | ".join(info["var_names"][:12]),
            "sample_labels": " | ".join(info["labels"][:6]),
        })

    with DRIVER_INDEX.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(index_rows[0].keys()))
        writer.writeheader()
        writer.writerows(index_rows)

    print(f"Wrote {DRIVER_MASTER} with {len(final_rows)} rows")
    print(f"Wrote {DRIVER_INDEX} with {len(index_rows)} drivers")


if __name__ == "__main__":
    main()
