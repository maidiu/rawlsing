# HARVEST-003 search receipt

Roots searched: /Users/matthewsmith/Desktop/Rawlsing; /Users/matthewsmith/Desktop/RawlsingsExcess

Exact target identities searched: four named CSV basenames and four supplied SHA-256 identities. Physical target occurrences found: 16 (four occurrences per supplied identity). Missing supplied identities: [].

Narrow linked search covered the explicitly named builders/updaters, driver-facet registry, GSS review/audit artifacts, facet-deepening review CSVs under final_codebooks/onboarding_reports, and small textual files containing an exact supplied SHA-256. Archives were not inspected because direct responsive files were found and no archive inspection was required by the bounded order.

No source files were modified. No builder/updater was executed. No semantic interpretation, recency selection, regeneration, normalization, or supersession conclusion was performed.
