#!/usr/bin/env python3
import argparse,csv,json,hashlib
from pathlib import Path
import pandas as pd

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); a=ap.parse_args(); R=Path(a.root); O=R/'output'
    v=json.load(open(O/'VALIDATION_RETURN.json'))
    assert v['status']=='PASS_AUDIT_COMPLETE_GLOBAL_V550J_AUTHORITY_NOT_CLOSED'
    assert v['scope_wave_count']==35 and v['scope_status']=='CLOSED_35_WAVES'
    assert v['scope_contains_lits_i_ii_iii_iv'] is True and v['scope_excludes_asian_barometer_w6'] is True
    assert v['qrr_rows']==16640 and v['qsm_rows']==18518 and v['manual_directional_rows']==236
    assert v['r14_objects']==730 and v['r14_source_native_relation_multi_objects']==445
    assert v['r14_all_members_qsm_all6_noinfer_objects']==0
    p1=pd.read_csv(O/'P1_RELATION_AUTHORITY_COVERAGE_MATRIX.csv')
    assert len(p1)==16 and p1['requirement_id'].nunique()==16
    prim=pd.read_csv(O/'PRIMITIVE_RELATION_CLASS_RECOMMENDATION.csv')
    assert {'RECIPROCAL_ROLE_REVERSAL','GENERAL_PRINCIPLE_SPECIFIC_APPLICATION','INTERNAL_TENSION_TOPOLOGY'}.issubset(set(prim['relation_or_output']))
    q=pd.read_csv(O/'SEMANTIC_EDGE_ADJUDICATION_QUEUE.csv')
    assert len(q)==445 and (q['authority_status']=='REVIEW_REQUIRED_DISCOVERY_ONLY_NOT_SEMANTIC_AUTHORITY').all()
    c=pd.read_csv(O/'QRA700_DIRECTIONAL_VS_QSM_CONFLICT_SUMMARY.csv')
    assert set(c['coordinate'])=={'driver_id','driver_facet_id','question_block_id','structural_domain_id','relation_axis_id','target_entity_id'}
    print('PASS: semantic authority convergence audit validated; 35-wave scope confirmed; queue remains non-authoritative.')
if __name__=='__main__': main()
