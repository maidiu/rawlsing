#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SNAPSHOT="${RAWLSING_CONVERGENCE_INPUT_SNAPSHOT:-$ROOT/input_snapshot}"
OUT="${RAWLSING_CONVERGENCE_OUTPUT:-$ROOT/output}"
python "$ROOT/code/build_convergence_audit.py" --snapshot "$SNAPSHOT" --output "$OUT"
python "$ROOT/code/validate_audit.py" --root "$ROOT"
