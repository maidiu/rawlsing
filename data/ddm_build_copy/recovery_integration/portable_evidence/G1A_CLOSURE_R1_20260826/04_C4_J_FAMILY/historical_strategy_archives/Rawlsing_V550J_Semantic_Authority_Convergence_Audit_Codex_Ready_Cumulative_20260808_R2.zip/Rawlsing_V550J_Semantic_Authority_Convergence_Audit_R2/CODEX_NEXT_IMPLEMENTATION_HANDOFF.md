# Codex next implementation handoff — after semantic authority convergence audit

## Governing objective

Complete Analytic V550J for the full 35-wave Rawlsing production scope without collapsing proposition authority, source-native respondent structure, or downstream structural-pressure logic into one layer. LiTS I/II/III/IV are in scope; Asian Barometer W6 is excluded.

## Do not redo

- Do not reopen the corrected LiTS I/IV R14 recovery.
- Do not rerun P2/P3/P3C from scratch.
- Do not discard R4's 508 terminal candidates; treat them as an existing checkpoint and source for already-covered exact target/condition/institution/routing relations.
- Do not promote the full QSM or the 16,640-row QRR into joint-family authority.
- Do not authorize from correlation, embedding similarity, common driver/facet, prefix, or co-membership alone.

## Immediate work program

### A. Install no new authority yet; first ingest this audit
Read `AUTHORITY_CONVERGENCE_AUDIT_REPORT.md`, `VALIDATION_RETURN.json`, `P1_RELATION_AUTHORITY_COVERAGE_MATRIX.csv`, `PRIMITIVE_RELATION_CLASS_RECOMMENDATION.csv`, and `INTER_QUESTION_RELATION_AUTHORITY_R1_PROPOSED_SCHEMA.json`.

### B. Preserve authority precedence
Use source questionnaire/codebook + R14/R15 as source-native membership/routing authority. Use later manual QRA as stronger than conflicting inherited QSM coordinates on overlap. Use P2/P3/P3C only as semantic equivalence/boundary/portability constraints. QSM/QRR/semantic indices are candidate recall and lineage unless independently governed.

### C. Build the typed-edge adjudication workbench
Start with `SEMANTIC_EDGE_ADJUDICATION_QUEUE.csv`. It is a bounded source-native queue, not approved authority. Add R4 candidates as already-adjudicated evidence. For each candidate structure, adjudicate whether there is incremental respondent-level information and, if so, assign only a truthful primitive relation/configuration type and ordered member roles.

Priority missing primitives:
1. `GENERAL_PRINCIPLE_SPECIFIC_APPLICATION`
2. `GOAL_MEANS`
3. `COMMITMENT_PERSONAL_COST` with ownership gate
4. `NORM_EXPECTED_CONDUCT` with narrow evidence ceiling
5. `GENERAL_TARGET_SUBTARGET` with explicit target hierarchy
6. `RECIPROCAL_ROLE_REVERSAL`
7. `SOURCE_NATIVE_COMMON_ROLE_SET` / complementary-role convergence
8. explicit cross-item priority/tradeoff only when V551 item topology alone is insufficient

### D. Do not over-model derived outputs
Internal tension topology, boundary location, configuration breadth, and target-condition interaction are downstream derivations from governed relations/roles and observed answers. They are not automatically new source-semantic edge classes.

### E. Schema evolution
The current `V550J_AUTHORITY_SCHEMA_R1` already expresses principle/application and means/end, but not all required primitives truthfully. If approved authority requires extension, create one common versioned R2 extension rather than source-local fields. Preserve R1 compatibility/migration evidence and hashes.

### F. Routing
Compile exact applicability predicates only where R14/R15 source evidence supports them. A source-native object may authorize membership but still remain runtime-blocked if its respondent predicate cannot be serialized exactly. Do not infer routing.

### G. Closure
After typed-edge adjudication, union approved new edges with R4 exact relation authority, freeze a new no-loss denominator, run terminal adjudication, validate mutation/adversarial gates, and only then compile V550J runtime authority. V551J/V552J remain downstream until closure.

## Required outputs

- versioned inter-question relation authority registry
- complete adjudication ledger with terminal row for every candidate
- rejected/wrong-ownership ledger
- blocked-evidence/routing ledger
- target hierarchy / institution-class authority only where actually needed
- schema R2 diff and migration contract if necessary
- denominator revision ledger
- source/hash manifest
- mutation/adversarial validation return
- final V550J closure return

## Acceptance principle

The goal is not maximum family count. The goal is complete bounded coverage of respondent-level joint information that isolated governed atoms cannot preserve, with no semantic or routing inference beyond the source authority chain.
