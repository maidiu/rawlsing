# Rawlsing V550J Authority-Source Fitness and Remediation Ruling — R2

Status: **SOURCE FITNESS REVIEW COMPLETE.**

This ruling distinguishes three questions that must not be collapsed:

1. Is an authority source internally valid for its stated jurisdiction?
2. Is it complete enough to perform that jurisdiction across the intended 35-wave production scope?
3. Is it safe to reuse as governing authority for the new typed inter-question relation layer and later nine-strata pressure pipeline?

## Executive ruling

The current authority stack is not uniformly defective. Several surfaces are fit and should remain immutable. Several are fit but source-incomplete and require bounded recovery/extension. Two inherited ontology surfaces — the full QSM and its thin derived block/axis/target/domain vocabularies — are not fit to act as governing structural-semantic authority for the ultimate full-corpus v5 pipeline without a successor reconciliation/rebuild.

The key implementation law is therefore:

- **do not rewrite good historical authority merely because it is partial by jurisdiction;**
- **do not promote legacy full-coverage mappings merely because they are comprehensive;**
- **repair source evidence gaps and routing representation where they block no-loss joint authority;**
- **create a versioned successor structural ontology rather than mutating QSM in place.**

## Fitness matrix

| Surface | Intended function | Fitness | Material defects / incompleteness | Required action |
|---|---|---|---|---|
| Canonical 35-wave wave authority | production scope identity | FIT | none found; 35 waves, LiTS I/II/III/IV included, ASB W6 excluded | preserve immutable |
| R14/R15 source-native authority | source-native grouping, membership, respondent universe, routing/applicability evidence, completion | FIT BUT SOURCE-INCOMPLETE | 221 ASB active residual variables lack native questionnaire locator/hash; global reconciliation also carries 146 WVS localized blockers, 29 WVS W1 identifier-crosswalk blockers, and 514 Latinobarómetro variables with no authoritative parent/battery mapping; routing is frequently human-readable rather than executable | recover source evidence where possible; retain fail-closed blockers; serialize exact routing predicates in a versioned runtime sidecar/extension |
| LiTS I/IV repaired authority | substantive native structure for missing LiTS waves | FIT | 35 localized non-substantive page-provenance blockers only | preserve; no semantic rebuild |
| P2 global semantic pair authority | cross-source proposition/boundary/portability constraints | FIT WITH TARGETED RESIDUALS | 351/18,831 unresolved fail-closed pairs, commonly missing parent/polarity evidence | do not rebuild globally; resolve only unresolved pairs touched by approved edge candidates when new native evidence exists |
| P3/P3C GSS proposition authority | GSS proposition identity, boundaries, lineage constraints | FIT FOR PAIR/BOUNDARY JURISDICTION | lineage taxonomy is shallow: most lineage rows use fallback `textual_proposition`; not a general typed relation-role ontology | preserve pair/boundary authority; enrich only targeted lineage semantics if a GSS edge requires it |
| 700-row manual QRA | high-precision calibration/control and governed bounded question semantics | FIT BY DESIGN, NOT FULL COVERAGE | only 700 rows / 236 directional rows; 16 directional rows do not match QSM; cannot cover full R14 universe | keep immutable as gold/control authority; optionally create successor expansion only for adjudicated high-value edge members |
| Full QSM (18,518 rows) | full question-to-structural-coordinate mapping | **NOT FIT AS GOVERNING FULL-CORPUS AUTHORITY** | 6,971 inferred axes; 13,489 inferred targets; 0/445 R14 multi-question structures have all six coordinates nonblank and non-inferred; material disagreement with later manual authority on 220 matched directional rows: driver 125, facet 134, block 57, domain 33, axis 149, target 152 | create a versioned QSM successor/reconciliation program; do not mutate old QSM; for V550J use source-first edge adjudication now, then complete broader QSM-v2 before full V552→V556 production relies on it |
| Derived question-block registry | reusable structural battery/block vocabulary | **INSUFFICIENT AS DEEP GOVERNING ONTOLOGY** | 152 IDs, 125 singleton-use; zero explicit definitions, exclusion criteria, or parent-child metadata; descriptions are prettified IDs | replace/extend with versioned definitions + aliases + scope + inclusion/exclusion + hierarchy; prioritize IDs encountered in edge queue, then globalize before final v5 production |
| Derived relation-axis registry | reusable semantic relation-axis vocabulary | **INSUFFICIENT AS DEEP GOVERNING ONTOLOGY** | 146 IDs, 127 singleton-use; zero explicit definitions/exclusions/hierarchy; vocabulary fracture with QSM | versioned axis taxonomy v2 with semantic definitions, exclusions, aliases, and cross-source harmonization |
| Derived target-entity registry | reusable target identity/taxonomy | **INSUFFICIENT FOR SUBTYPE/RECIPROCITY/BOUNDARY FUNCTION** | 154 IDs, 128 singleton-use; zero explicit definitions/exclusions/parent-child metadata; cannot govern general→subtype or reciprocal role structure | target taxonomy v2 is required before JE07/JE09/JE13 can be generalized reliably |
| Structural-domain registry | broad antagonism/pressure domains | PARTIALLY FIT | only 22 IDs and reuse is healthy, but zero explicit definitions/exclusions/hierarchy in derived registry; risk of driver/domain duplication | strengthen definitions and exclusion boundaries; lower urgency than axes/targets/blocks |
| Full QRR (16,640 rows) | broad runtime relation inventory / recall | FIT ONLY AS LEGACY RECALL/PROJECTION | only 10 coarse `question_family` values; all 16,640 polarity values are `mixed`; cannot prove typed inter-question roles | explicitly demote from semantic authority; eventually regenerate as a projection from successor governed authorities rather than hand-repairing 16,640 rows |
| `respondent_wave_semantics_registry.json` / `respondent_wave_source_registry.json` | canonical respondent-field source semantics (e.g. income/education proxies) | FIT FOR THEIR ACTUAL JURISDICTION | only 78 records; these are not item-level routing registries despite suggestive names | leave alone; do not use as V550J routing authority |
| `question_structure_register` / source-structure validation | file/codebook structural inventory | FIT AS INGEST/QA WITH LOCAL PARTIALS | six canonical files remain partial in the older validation report: Afro R1/R9, ASB W1, Latin 1995/2011/2024; Latin has especially large stale/disagreement counts | do not equate this with semantic authority; repair underlying source/codebook discrepancies where they overlap current blockers |
| Current GSS `question_family_registry.yaml` | executable morphology/expression model | FIT AS HISTORICAL EXPRESSION MODEL, NOT CANONICAL UNIVERSE | only three draft GSS families; eligible waves include historical non-production 1982/2004/2014; taxonomy insufficient for newly approved primitive roles | preserve as exemplar; supersede with common V550J R2 projection from typed inter-question authority; never derive production scope from it |
| V550J R1 authority schema | executable joint-configuration contract | FIT BUT ENUM-INCOMPLETE | already supports principle/application and means/end, but cannot truthfully express all anticipated approved primitives such as commitment/cost, norm/conduct, reciprocal-role reversal, complementary-role set | extend once, commonly, to R2 only after semantic adjudication proves needed primitives |
| R4 exact target/condition candidates | bounded exact analytic V550J authority work | FIT | no global semantic-role closure; 508 candidates intentionally bounded | preserve and union into new typed authority; do not rerun from scratch |

## Quantitative grounds for the QSM/registry ruling

### QSM

- 18,518 rows total.
- `relation_axis_id`: 6,971 `infer_*` values.
- `target_entity_id`: 13,489 `infer_*` values.
- R14 multi-question source-native structures: 445.
- All relation members QSM-matched: 358/445.
- All six structural coordinates populated for every member: 56/445.
- All six populated with no `infer_*`: **0/445**.
- Non-inferred axis+target for every member: 20/445.

On 220 manually governed directional questions matched into QSM, disagreements with the later manual ruling are:

- driver: 125
- facet: 134
- block: 57
- domain: 33
- axis: 149
- target: 152

This is a substantive authority divergence, not a cosmetic naming issue.

### Thin derived registries

- question blocks: 152 IDs, 125 singleton-use;
- relation axes: 146 IDs, 127 singleton-use;
- target entities: 154 IDs, 128 singleton-use;
- structural domains: 22 IDs, 1 singleton-use.

Across all four derived registries the audit found **zero explicit definitions, zero exclusion criteria, and zero parent-child metadata** in the registry records. This does not make the 700-row manual rulings wrong; it means the derived registries are not sufficiently specified to act as a reusable ontology for subtype, reciprocity, boundary, or harmonization logic.

## Source-native evidence gaps that can hide legitimate V550J structures

### Asian Barometer

The R14 structural-review closure contains **221 active `SOURCE_EXHAUSTED_EVIDENCE_BLOCKED` residual variables**:

- W1: 40
- W4: 94
- W5: 87

Each is blocked because the authorized inventory contains no native questionnaire/source locator or source hash. These are genuine source-recovery gaps. If native W1/W4/W5 questionnaires/instruments can be obtained and hashed, they should be reopened through a successor authority release. Do not infer their structure from codebook labels.

### WVS

Current global reconciliation preserves:

- 146 localized evidence blockers;
- 29 WVS W1 identifier-crosswalk blockers.

The WVS scope ledger is internally complete and fail-closed; the problem is missing evidence/crosswalk, not ledger logic. Recover native parent wording/crosswalk evidence where possible.

### Latinobarómetro

The terminal reconciliation contains:

- 292 accepted source-native parent/member rows;
- 6 recode aliases;
- **514 `EVIDENCE_BLOCKED_NO_AUTHORITATIVE_PARENT_MAPPING` rows**.

This is the largest remaining potential source-native coverage hole. It should receive a dedicated source-document recovery pass before claiming maximal 35-wave joint-structure coverage. No label-only grouping is permitted.

### LiTS I/IV

The reconstruction is substantively complete. Thirty-five localized blockers concern non-substantive administrative/context provenance and do not justify reopening the substantive LiTS pass.

## Routing ruling

R14 is a good **evidence authority** for routing and respondent universe, but not yet a universal executable routing language. Many objects preserve phrases such as country-specific split instructions, optional/routed applicability, or native routing retained in excerpts. The `respondent_wave_*` registries do not solve this: they are respondent-field source/semantics registries, not question-level route predicates.

Before final V550J runtime closure, create a versioned `QUESTION_APPLICABILITY_PREDICATE_AUTHORITY` (or equivalent common sidecar) that can represent at least:

- always-asked / ask-all;
- country/module applicability;
- split-ballot/form assignment;
- parent-gate conditions;
- asked-if / not-asked-if predicates;
- route-dependent child applicability;
- source-structural nonapplicability;
- optional vs required item semantics;
- unresolved predicate with fail-closed status;
- exact source locator/hash/evidence ceiling.

Do not generate this predicate layer from prose heuristics alone. Source prose is evidence; a normalized predicate becomes authority only after validated serialization.

## P2/P3 ruling

### P2

P2 is structurally sound for its jurisdiction. Its 351 unresolved rows are not a reason for a global P2 rebuild. They are useful explicit uncertainty. However, an approved inter-question edge that depends on one of these unresolved pairs must remain blocked until the missing parent/polarity evidence is recovered or the edge is independently supported without that pair.

### P3/P3C

P3/P3C should not be revamped as though its failure to encode principle/application or reciprocity were a defect. That is outside its jurisdiction. Its pair/boundary authority remains useful. The GSS lineage semantic classification is shallow — most lineage rows fall back to `textual_proposition` — so targeted enrichment may be useful when a new GSS edge needs typed role semantics, but this should be a successor enrichment, not mutation of existing pair authority.

## Recommended remediation order

### Gate A — before semantic-edge closure

1. Preserve immutable 35-wave scope, LiTS I/IV, P2, P3/P3C, R4.
2. Attempt bounded source recovery for the 514 Latin, 221 ASB, and 175 WVS evidence/crosswalk blockers. New evidence opens successor rulings; no evidence leaves them fail-closed.
3. Build the typed inter-question edge/hyperedge authority over existing R14 structures.
4. Build/validate the executable question-applicability predicate authority.
5. Create only the taxonomy-v2 pieces required by accepted edge classes: especially target parent/child, reciprocal roles, institution classes, ordered conditions, and aliases.

### Gate B — before full V552/V553/nine-strata production

6. Launch a versioned **QSM v2 reconciliation/rebuild**, source-first and authority-aware. Do not patch QSM v1 in place.
7. Rebuild the foundational block/axis/target/domain registries as explicit semantic registries with definitions, exclusions, aliases, hierarchy/relations, examples, source coverage, and provenance.
8. Reconcile every active V551/V552 pressure-bearing question against QSM v2; no `infer_*` coordinate may silently become structural pressure authority.
9. Regenerate broad runtime projections such as QRR from the successor authority stack rather than treating old QRR as semantic truth.

### Gate C — before final V556 persona dynamics

10. Verify that all pressure-bearing evidence reaches nine-strata placement through governed `strata_relevance`, `strata_path`, position conditioning, and uncertainty/provenance rules rather than through inherited broad drivers alone.
11. Mutation-test the structural ontology: swapped targets, collapsed parent/subtype, reciprocal-role inversion, driver/domain conflation, inferred-axis promotion, and routing-out respondent contamination must all fail.

## Bottom line

There is **one genuine inherited ontology overhaul** to plan: QSM + its derived structural registries need a versioned successor before they can safely serve the full nine-strata v5 pipeline.

There are **three bounded source-recovery programs** worth pursuing now: Latinobarómetro parent mapping, Asian Barometer native locators, and WVS evidence/crosswalk recovery.

There is **one required runtime representation upgrade** before V550J closure: executable applicability/routing predicates.

P2, P3/P3C, the 700-row QRA, corrected LiTS authority, canonical wave scope, and R4 should **not** be globally rebuilt. Their limitations are mostly jurisdictional or explicitly fail-closed and should be handled through successor extensions only when relevant evidence demands it.
