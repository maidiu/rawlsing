#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, os, re, shutil
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import pandas as pd
import yaml


def norm_text(x: Any) -> str:
    if x is None or (isinstance(x,float) and pd.isna(x)): return ''
    return str(x).strip()

def norm_key(x: Any) -> str:
    s=norm_text(x).lower()
    return re.sub(r'[^a-z0-9]+','',s)

def norm_source(x: Any) -> str:
    k=norm_key(x)
    mp={
      'gss':'GSS','generalsocialsurvey':'GSS',
      'wvs':'WVS','worldvaluessurvey':'WVS',
      'evs':'EVS','europeanvaluessurvey':'EVS',
      'arabbarometer':'Arab Barometer','arabbarometre':'Arab Barometer',
      'afrobarometer':'Afrobarometer',
      'asianbarometer':'Asian Barometer','asb':'Asian Barometer',
      'latinobarometro':'Latinobarómetro','latinobarometer':'Latinobarómetro',
      'lits':'LiTS','lifetransitionsurvey':'LiTS',
      'southasia':'South Asia','southasiabarometer':'South Asia',
    }
    return mp.get(k, norm_text(x))

def norm_wave(src: str, x: Any) -> str:
    s=norm_text(x).upper().replace('WAVE ','W').replace('ROUND ','R')
    # LiTS I is often 2006 in data/registries.
    if norm_source(src)=='LiTS' and s in {'I','1','W1','2006'}: return 'I'
    roman={'1':'I','2':'II','3':'III','4':'IV','5':'V','6':'VI','7':'VII','8':'VIII'}
    if norm_source(src)=='LiTS' and s in roman: return roman[s]
    if norm_source(src)=='Arab Barometer':
        if s.startswith('W') and s[1:].isdigit(): return roman.get(s[1:],s)
        if s.isdigit(): return roman.get(s,s)
    return s

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def is_infer(v: Any) -> bool:
    return norm_text(v).lower().startswith('infer_')

def load_yaml_entries(path: Path, idfield: str):
    y=yaml.safe_load(path.read_text())
    rows=y.get('entries',[]) if isinstance(y,dict) else []
    out=[]
    for e in rows:
        d=dict(e); d['_id']=norm_text(d.get(idfield)); out.append(d)
    return y,out

def pick_members(o: dict) -> list[dict]:
    # R15 LiTS has explicit semantic roles. Older R14 native objects are all source-native
    # structure members; absent a role ledger, treat members as relation-structure candidates,
    # not as accepted analytic V550J relation evidence.
    if o.get('member_evidence'):
        return [m for m in o['member_evidence'] if norm_text(m.get('semantic_role'))=='RELATION_EVIDENCE']
    vals=o.get('members') or o.get('ordered_members') or []
    out=[]
    for m in vals:
        if isinstance(m,dict):
            vid=m.get('codebook_variable_id') or m.get('var_code') or m.get('question_id') or m.get('id')
            role=m.get('semantic_role') or 'UNSPECIFIED_SOURCE_NATIVE_MEMBER'
            if role in {'STRUCTURAL_CONTEXT','POSITION_COORDINATE'}: continue
            out.append({'codebook_variable_id':vid,'semantic_role':role})
        else:
            out.append({'codebook_variable_id':m,'semantic_role':'UNSPECIFIED_SOURCE_NATIVE_MEMBER'})
    return out

def qsm_index(qsm: pd.DataFrame):
    d=defaultdict(list)
    for _,r in qsm.iterrows():
        src=norm_source(r['source']); w=norm_wave(src,r['wave'])
        ids={norm_key(r.get('var_code')),norm_key(r.get('question_id'))}
        for i in ids:
            if i: d[(src,w,i)].append(r)
    return d

def qra_index(qra: pd.DataFrame):
    d=defaultdict(list)
    for _,r in qra.iterrows():
        src=norm_source(r['source_family']); w=norm_wave(src,r['canonical_wave'])
        for i in {norm_key(r.get('var_code')),norm_key(r.get('question_id'))}:
            if i: d[(src,w,i)].append(r)
    return d

def qrr_index(qrr: pd.DataFrame):
    d=defaultdict(list)
    for _,r in qrr.iterrows():
        src=norm_source(r['source_family']); w=norm_wave(src,r['wave']); raw=norm_text(r['item_id']); i=norm_key(raw.split(':')[-1])
        if i: d[(src,w,i)].append(r)
    return d

def guess_discovery_types(text: str) -> list[str]:
    t=text.lower()
    types=[]
    def add(x):
        if x not in types: types.append(x)
    if any(k in t for k in ['confidence','trust in','institutional trust','institutions trust']): add('INSTITUTION_CLASS_DIFFERENTIATION')
    if any(k in t for k in ['condition','circumstance','justifiab','permissib','abortion','reasons for','reason:']): add('SAME_PROPOSITION_DIFFERENT_CONDITION')
    if any(k in t for k in ['willingness to pay','willing to pay','pay more','sacrifice','personal cost','tax sacrifice']): add('COMMITMENT_PERSONAL_COST')
    if any(k in t for k in ['most important','priority','priorit','tradeoff','trade-off','rank the','ranking']): add('EXPLICIT_PRIORITY_TRADEOFF')
    if any(k in t for k in ['if yes','if answered','if selected','only if','ask if','routing','skip if','filter']): add('SOURCE_NATIVE_ROUTED_SEQUENCE')
    if any(k in t for k in ['norm','should ','ought ','duty','expected conduct']): add('NORM_EXPECTED_CONDUCT')
    if any(k in t for k in ['system alternatives','means','method of','way to achieve','best way']): add('GOAL_MEANS')
    if any(k in t for k in ['general vs','specific application','principle','in principle']): add('GENERAL_PRINCIPLE_SPECIFIC_APPLICATION')
    if any(k in t for k in ['reciproc','role reversal','men and women','husband','wife','parents','children']): add('RECIPROCAL_ROLE_REVERSAL')
    if any(k in t for k in ['general target','subtype','sub-category','subcategory']): add('GENERAL_TARGET_SUBTARGET')
    if not types: add('SOURCE_NATIVE_COMMON_ROLE_SET_REVIEW')
    return types

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--snapshot',required=True)
    ap.add_argument('--output',required=True)
    args=ap.parse_args()
    S=Path(args.snapshot); O=Path(args.output); O.mkdir(parents=True,exist_ok=True)

    qrr=pd.read_csv(S/'question_relation_registry.csv',low_memory=False)
    qsm=pd.read_csv(S/'question_structural_mapping_live.csv',low_memory=False)
    qra=pd.read_csv(S/'question_relation_registry_35wave_active_v1.csv',low_memory=False)
    dir236=pd.read_csv(S/'directional_question_relation_authority_236.csv',low_memory=False)
    r4=pd.read_csv(S/'ANALYTIC_V550J_CANDIDATE_UNIVERSE.csv',low_memory=False)
    p1=pd.read_csv(S/'P1_Downstream_Joint_Evidence_Requirements_Map.csv',low_memory=False)
    p2=pd.read_csv(S/'P2_GLOBAL_SEMANTIC_PRIORITY_PAIR_AUTHORITY_18831.csv',low_memory=False)
    p3=pd.read_csv(S/'GSS_FULL_EFFECTIVE_PAIR_AUTHORITY_R1.csv',low_memory=False)
    p3lin=pd.read_csv(S/'GSS_FULL_LINEAGE_SEMANTIC_AUTHORITY_R1.csv',low_memory=False)
    r14=json.loads((S/'R14_SOURCE_NATIVE_AUTHORITY_FINAL.json').read_text())
    schema=json.loads((S/'V550J_AUTHORITY_SCHEMA_R1.json').read_text())
    wave_registry=json.loads((S/'wave_authority_registry_35wave_v1.json').read_text())
    family_registry=yaml.safe_load((S/'question_family_registry.yaml').read_text())

    # ---------- foundational inventory ----------
    inventory=[]
    for fn,kind in [
        ('question_relation_registry.csv','FULL_RUNTIME_RELATION_INVENTORY'),
        ('question_structural_mapping_live.csv','FULL_STRUCTURAL_MAPPING'),
        ('question_relation_registry_35wave_active_v1.csv','BOUNDED_MANUAL_QRA_SELECTION'),
        ('directional_question_relation_authority_236.csv','BOUNDED_MANUAL_DIRECTIONAL_QRA'),
        ('R14_SOURCE_NATIVE_AUTHORITY_FINAL.json','SOURCE_NATIVE_STRUCTURE_AUTHORITY'),
        ('P2_GLOBAL_SEMANTIC_PRIORITY_PAIR_AUTHORITY_18831.csv','CROSS_SOURCE_PROPOSITION_PAIR_AUTHORITY'),
        ('GSS_FULL_EFFECTIVE_PAIR_AUTHORITY_R1.csv','GSS_PROPOSITION_PAIR_BOUNDARY_AUTHORITY'),
        ('GSS_FULL_LINEAGE_SEMANTIC_AUTHORITY_R1.csv','GSS_LINEAGE_SEMANTIC_AUTHORITY'),
        ('ANALYTIC_V550J_CANDIDATE_UNIVERSE.csv','R4_ANALYTIC_V550J_CHECKPOINT'),
        ('V550J_AUTHORITY_SCHEMA_R1.json','RUNTIME_AUTHORITY_SCHEMA'),
        ('wave_authority_registry_35wave_v1.json','CANONICAL_35_WAVE_SCOPE_AUTHORITY'),
        ('question_family_registry.yaml','CURRENT_GSS_V550J_FAMILY_EXPRESSION_MODEL')]:
        p=S/fn
        inventory.append({'artifact':fn,'authority_role':kind,'bytes':p.stat().st_size,'sha256':sha256(p)})
    pd.DataFrame(inventory).to_csv(O/'FOUNDATIONAL_SEMANTIC_REGISTRY_INVENTORY.csv',index=False)

    # canonical scope and current family-expression model
    scope_rows=[]
    for e in wave_registry.get('entries',[]):
        scope_rows.append({'source_family':e.get('source_family'),'canonical_wave':e.get('canonical_wave'),'source_family_key':e.get('source_family_key'),'canonical_wave_key':e.get('canonical_wave_key')})
    pd.DataFrame(scope_rows).to_csv(O/'CANONICAL_35_WAVE_SCOPE.csv',index=False)
    famrows=[]
    production_pairs={(norm_source(e.get('source_family')), norm_wave(e.get('source_family'),e.get('canonical_wave'))) for e in wave_registry.get('entries',[])}
    for f in (family_registry or {}).get('families',[]):
        elig=[norm_text(x) for x in f.get('eligible_waves',[])]
        fsrc=norm_source(family_registry.get('source_family','GSS'))
        prod=[w for w in elig if (fsrc, norm_wave(fsrc,w)) in production_pairs]
        nonprod=[w for w in elig if w not in prod]
        role_groups=f.get('item_role_groups',{}) or {}
        famrows.append({'family_id':f.get('family_id'),'family_type':f.get('family_type'),'family_structure_type':f.get('family_structure_type'),'expected_multi_target':f.get('expected_multi_target'),'minimum_items_answered':f.get('minimum_items_answered'),'declared_eligible_wave_count':len(elig),'production_scope_eligible_waves':' | '.join(prod),'nonproduction_or_historical_declared_waves':' | '.join(nonprod),'item_role_group_count':len(role_groups),'item_count':sum(len(v or []) for v in role_groups.values()),'registry_status':family_registry.get('status')})
    pd.DataFrame(famrows).to_csv(O/'CURRENT_GSS_FAMILY_EXPRESSION_MODEL_AUDIT.csv',index=False)

    # ---------- registry definition audit ----------
    regs=[
      ('question_block_registry_35wave_active_v1.yaml','question_block_id','question_block'),
      ('relation_axis_registry_35wave_active_v1.yaml','relation_axis_id','relation_axis'),
      ('target_entity_registry_35wave_active_v1.yaml','target_entity_id','target_entity'),
      ('structural_domain_registry_35wave_active_v1.yaml','structural_domain_id','structural_domain')]
    defaudit=[]; regsets={}
    for fn,idfield,regname in regs:
        _,rows=load_yaml_entries(S/fn,idfield); ids=set()
        for e in rows:
            rid=e['_id']; ids.add(rid)
            desc=norm_text(e.get('description'))
            prettified=re.sub(r'[_\-]+',' ',rid).strip().lower()
            desc_norm=re.sub(r'\s+',' ',desc).strip().lower()
            source_count=len([x for x in norm_text(e.get('source_families')).split('|') if x])
            used=int(float(e.get('used_by_question_count',0) or 0))
            defaudit.append({
              'registry':regname,'id':rid,'used_by_question_count':used,'source_family_count':source_count,
              'description':desc,'description_is_prettified_id':desc_norm==prettified,
              'has_explicit_definition':bool(e.get('definition')),'has_exclusion_criteria':bool(e.get('exclusion_criteria')),
              'has_parent_child_metadata':bool(e.get('parent_id') or e.get('parent') or e.get('children')),
              'singleton_in_700_derived_registry':used<=1,'authority_status':e.get('authority_status','')})
        regsets[regname]=ids
    defdf=pd.DataFrame(defaudit); defdf.to_csv(O/'FOUNDATIONAL_REGISTRY_DEFINITION_AUDIT.csv',index=False)

    # ---------- QSM quality ----------
    coords=['driver_id','driver_facet_id','question_block_id','structural_domain_id','relation_axis_id','target_entity_id']
    qsmq=qsm.copy()
    for c in coords:
        qsmq[c+'_nonblank']=qsmq[c].map(lambda x:bool(norm_text(x)))
        qsmq[c+'_infer']=qsmq[c].map(is_infer)
    qsmq['core_nonblank_count']=qsmq[[c+'_nonblank' for c in coords]].sum(axis=1)
    qsmq['all_six_nonblank']=qsmq['core_nonblank_count'].eq(6)
    qsmq['any_infer']=qsmq[[c+'_infer' for c in coords]].any(axis=1)
    qsmq['all_six_nonblank_no_infer']=qsmq['all_six_nonblank'] & ~qsmq['any_infer']
    rows=[]
    for st,g in qsmq.groupby('mapping_status',dropna=False):
        row={'mapping_status':st,'row_count':len(g),'all_six_nonblank':int(g.all_six_nonblank.sum()),'all_six_nonblank_no_infer':int(g.all_six_nonblank_no_infer.sum())}
        for c in coords:
            row[c+'_nonblank']=int(g[c+'_nonblank'].sum()); row[c+'_infer']=int(g[c+'_infer'].sum())
        rows.append(row)
    pd.DataFrame(rows).sort_values('row_count',ascending=False).to_csv(O/'QSM_COORDINATE_QUALITY_SUMMARY.csv',index=False)

    # vocab fracture full QSM vs 700-derived registry definitions
    fracture=[]
    for c,regname in [('question_block_id','question_block'),('relation_axis_id','relation_axis'),('target_entity_id','target_entity'),('structural_domain_id','structural_domain')]:
        used=set(norm_text(x) for x in qsm[c] if norm_text(x))
        registered=regsets[regname]
        missing=sorted(used-registered)
        overlap=sorted(used&registered)
        fracture.append({'coordinate':c,'qsm_distinct_ids':len(used),'700_registry_distinct_ids':len(registered),'overlap_count':len(overlap),'qsm_ids_missing_from_700_registry':len(missing),'sample_missing_ids':' | '.join(missing[:20])})
    pd.DataFrame(fracture).to_csv(O/'QSM_VS_700_REGISTRY_VOCABULARY_FRACTURE.csv',index=False)

    # ---------- manual 236 vs QSM conflicts ----------
    qidx=qsm_index(qsm)
    conflict_rows=[]
    stat=Counter()
    for _,r in dir236.iterrows():
        src=norm_source(r['source_family']); w=norm_wave(src,r['canonical_wave']); ident=norm_key(r.get('var_code') or r.get('question_id'))
        matches=qidx.get((src,w,ident),[])
        out={'source_family':src,'wave':w,'var_code':r.get('var_code'),'question_id':r.get('question_id'),'question_text':r.get('question_text'),'qsm_match_count':len(matches)}
        if not matches:
            stat['missing_qsm']+=1
            for c in coords: out[c+'_manual']=r.get(c,''); out[c+'_qsm']=''; out[c+'_comparison']='QSM_MISSING'
        else:
            qr=matches[0]
            stat['matched_qsm']+=1
            for c in coords:
                a=norm_text(r.get(c)); b=norm_text(qr.get(c));
                if not b: comp='QSM_BLANK'; stat[c+'_blank']+=1
                elif norm_key(a)==norm_key(b): comp='EXACT_OR_NORMALIZED_AGREEMENT'; stat[c+'_agree']+=1
                else: comp='DISAGREE'; stat[c+'_disagree']+=1
                out[c+'_manual']=a; out[c+'_qsm']=b; out[c+'_comparison']=comp
        conflict_rows.append(out)
    cdf=pd.DataFrame(conflict_rows); cdf.to_csv(O/'QRA700_DIRECTIONAL_VS_QSM_CONFLICTS.csv',index=False)
    summary_rows=[]
    for c in coords:
        summary_rows.append({'coordinate':c,'manual_directional_rows':len(dir236),'qsm_matched_rows':stat['matched_qsm'],'qsm_missing_rows':stat['missing_qsm'],'agree':stat[c+'_agree'],'qsm_blank':stat[c+'_blank'],'disagree':stat[c+'_disagree']})
    pd.DataFrame(summary_rows).to_csv(O/'QRA700_DIRECTIONAL_VS_QSM_CONFLICT_SUMMARY.csv',index=False)

    # ---------- R14 source-native object coverage ----------
    qraidx=qra_index(qra); qrridx=qrr_index(qrr)
    r14rows=[]; rel_member_total=0
    for o in r14['objects']:
        src=norm_source(o.get('family')); w=norm_wave(src,o.get('wave')); members=pick_members(o)
        if len(members)<2: continue
        rel_member_total += len(members)
        member_metrics=[]
        for m in members:
            vid=m.get('codebook_variable_id') or m.get('var_code') or m.get('question_id') or m.get('id')
            key=(src,w,norm_key(vid)); qm=qidx.get(key,[]); qa=qraidx.get(key,[]); qr=qrridx.get(key,[])
            qrow=qm[0] if qm else None
            full6=bool(qrow is not None and all(norm_text(qrow.get(c)) for c in coords))
            noinfer=bool(full6 and not any(is_infer(qrow.get(c)) for c in coords))
            axis_target_noinfer=bool(qrow is not None and norm_text(qrow.get('relation_axis_id')) and norm_text(qrow.get('target_entity_id')) and not is_infer(qrow.get('relation_axis_id')) and not is_infer(qrow.get('target_entity_id')))
            member_metrics.append((bool(qm),full6,noinfer,axis_target_noinfer,bool(qa),bool(qr),qrow))
        parent=' | '.join(filter(None,[norm_text(o.get('printed_parent_text')),norm_text(o.get('bounded_parent_excerpt')),norm_text(o.get('routing'))]))
        guessed=guess_discovery_types(parent)
        r14rows.append({
          'object_id':o.get('object_id'),'source_family':src,'wave':w,'schema_version':o.get('schema_version',''),
          'parent_id':o.get('printed_parent_id') or o.get('parent_group_id') or '', 'parent_text':o.get('printed_parent_text') or '',
          'relation_member_count':len(members),'all_members_qsm_matched':all(x[0] for x in member_metrics),'all_members_qsm_all6':all(x[1] for x in member_metrics),
          'all_members_qsm_all6_noinfer':all(x[2] for x in member_metrics),'all_members_qsm_axis_target_noinfer':all(x[3] for x in member_metrics),
          'all_members_qra700_matched':all(x[4] for x in member_metrics),'any_member_qra700_matched':any(x[4] for x in member_metrics),
          'all_members_full_qrr_matched':all(x[5] for x in member_metrics),'any_member_full_qrr_matched':any(x[5] for x in member_metrics),
          'routing':o.get('routing',''),'universe':o.get('universe',''),'applicability':o.get('applicability',''),'completion_rule':o.get('completion_rule',''),
          'discovery_only_candidate_types':' | '.join(guessed),'authority_status':'REVIEW_REQUIRED_DISCOVERY_ONLY_NOT_SEMANTIC_AUTHORITY'})
    rdf=pd.DataFrame(r14rows); rdf.to_csv(O/'R14_SOURCE_NATIVE_RELATION_OBJECT_COVERAGE.csv',index=False)
    byfam=rdf.groupby('source_family',dropna=False).agg(
        relation_structure_objects=('object_id','size'), relation_members=('relation_member_count','sum'),
        all_members_qsm_matched=('all_members_qsm_matched','sum'), all_members_qsm_all6=('all_members_qsm_all6','sum'),
        all_members_qsm_all6_noinfer=('all_members_qsm_all6_noinfer','sum'), all_members_qsm_axis_target_noinfer=('all_members_qsm_axis_target_noinfer','sum'),
        any_member_qra700_matched=('any_member_qra700_matched','sum'), all_members_qra700_matched=('all_members_qra700_matched','sum'),
        all_members_full_qrr_matched=('all_members_full_qrr_matched','sum')).reset_index()
    byfam.to_csv(O/'R14_RELATION_OBJECT_COVERAGE_BY_FAMILY.csv',index=False)
    dc=Counter()
    for cell in rdf['discovery_only_candidate_types']:
        for x in norm_text(cell).split(' | '):
            if x: dc[x]+=1
    pd.DataFrame([{'discovery_only_candidate_type':k,'object_count':v} for k,v in dc.most_common()]).to_csv(O/'SEMANTIC_EDGE_DISCOVERY_TYPE_COUNTS.csv',index=False)
    queue=rdf.sort_values(['all_members_qsm_all6_noinfer','any_member_qra700_matched','relation_member_count'],ascending=[True,False,False]).copy()
    queue.to_csv(O/'SEMANTIC_EDGE_ADJUDICATION_QUEUE.csv',index=False)

    # ---------- P2/P3 capability summaries ----------
    cap=[]
    for name,df in [('P2_GLOBAL',p2),('P3_GSS',p3)]:
        counts=df['normalized_authority_class'].fillna('').value_counts().to_dict()
        for cls,n in counts.items(): cap.append({'surface':name,'normalized_authority_class':cls,'row_count':n})
    pd.DataFrame(cap).to_csv(O/'P2_P3_AUTHORITY_CLASS_COUNTS.csv',index=False)
    p3axis=[]
    for c in ['axis','classification_method','semantic_classification','lineage_axis']:
        if c in p3lin.columns:
            for v,n in p3lin[c].fillna('').value_counts().head(30).items(): p3axis.append({'field':c,'value':v,'row_count':n})
    pd.DataFrame(p3axis).to_csv(O/'P3_LINEAGE_SEMANTIC_DISTRIBUTION.csv',index=False)

    # ---------- R4 current template coverage ----------
    tmpl=Counter(); req=Counter(); outcomes=Counter()
    def parse_list_cell(v):
        s=norm_text(v)
        if not s: return []
        if s.startswith('['):
            try:
                x=json.loads(s)
                if isinstance(x,list): return [norm_text(i) for i in x if norm_text(i)]
            except Exception:
                pass
        return [x.strip().strip('\"') for x in re.split(r'[|;,]',s) if x.strip().strip('\"')]
    for _,r in r4.iterrows():
        for x in parse_list_cell(r.get('collision_template_ids')): tmpl[x]+=1
        for x in parse_list_cell(r.get('downstream_requirement_ids')): req[x]+=1
        outcomes[norm_text(r.get('candidate_status'))]+=1
    pd.DataFrame([{'collision_template_id':k,'candidate_rows':v} for k,v in tmpl.items()]).sort_values('candidate_rows',ascending=False).to_csv(O/'R4_COLLISION_TEMPLATE_COVERAGE.csv',index=False)
    pd.DataFrame([{'requirement_id':k,'candidate_rows':v} for k,v in req.items()]).sort_values('candidate_rows',ascending=False).to_csv(O/'R4_DOWNSTREAM_REQUIREMENT_TAG_COVERAGE.csv',index=False)

    # ---------- primitive/derived recommendation ----------
    primitives=[
      ('SAME_PROPOSITION_DIFFERENT_TARGET','PRIMITIVE_EXISTING','V550J','Existing bounded exact generator; retain.'),
      ('SAME_PROPOSITION_DIFFERENT_CONDITION','PRIMITIVE_EXISTING','V550J','Existing bounded exact generator; retain.'),
      ('GENERAL_PRINCIPLE_SPECIFIC_APPLICATION','PRIMITIVE_MISSING_TYPED_EDGE','V550J','Requires explicit semantic role edge; schema already has PRINCIPLE_APPLICATION_PAIR.'),
      ('GOAL_MEANS','PRIMITIVE_MISSING_TYPED_EDGE','V550J','Requires explicit goal/means role edge; schema has MEANS_END_PAIR.'),
      ('COMMITMENT_PERSONAL_COST','PRIMITIVE_MISSING_TYPED_EDGE_WITH_OWNERSHIP_GATE','V550J_OR_V552J','Only V550J when both observations are respondent-level and jointly interpretable; structural/material cost belongs later.'),
      ('NORM_EXPECTED_CONDUCT','PRIMITIVE_MISSING_TYPED_EDGE_NARROW_CEILING','V550J','Mixed normative/context lanes allowed only with explicit evidence ceiling; conduct does not become signed attitude.'),
      ('GENERAL_TARGET_SUBTARGET','PRIMITIVE_MISSING_TARGET_TAXONOMY','V550J','Requires governed parent/child target hierarchy; existing target registry is flat.'),
      ('INSTITUTION_CLASS_DIFFERENTIATION','PRIMITIVE_PARTIAL_EXISTING','V550J','R4 has bounded instances; needs governed institution-class taxonomy/roles.'),
      ('RECIPROCAL_ROLE_REVERSAL','PRIMITIVE_MISSING_DEDICATED_EDGE','V550J','Add dedicated semantic relation instead of treating all target differences as reciprocity.'),
      ('EXPLICIT_PRIORITY_TRADEOFF','PRIMITIVE_CONDITIONAL','V551_OR_V550J','Single forced-tradeoff item is V551 topology; V550J only when linked to separately governed priorities/goals.'),
      ('SOURCE_NATIVE_ROUTED_SEQUENCE','PRIMITIVE_SOURCE_NATIVE_EXISTING_RUNTIME_GAP','V550J','R14 is strong substrate; exact runtime predicate serialization remains.'),
      ('SOURCE_NATIVE_COMMON_ROLE_SET','PRIMITIVE_MISSING_COMPLEMENTARY_ROLE_EDGE','V550J','R14 group membership may be source-native; semantic complementary roles still require adjudication.'),
      ('TARGET_CONDITION_MATRIX','CONFIGURATION_COMPOSITE','V550J','May be compiled from governed target and condition role coordinates; no free-standing semantic claim needed.')]
    derived=[
      ('INTERNAL_TENSION_TOPOLOGY','DERIVED','V551J/V552J','Derive from accepted primitive relations plus observed answer configuration; do not author as source-semantic edge.'),
      ('BOUNDARY_LOCATION','DERIVED','V551J/V552J','Derive once target hierarchy / condition ordering is governed.'),
      ('CONFIGURATION_BREADTH','DERIVED_MECHANICAL','V551J','Membership/completeness property after family authority.'),
      ('TARGET_CONDITION_INTERACTION','DERIVED_FROM_MATRIX','V551J/V552J','Derive from governed target-condition matrix cells and observed answers.')]
    pdf=pd.DataFrame([{'relation_or_output':a,'class':b,'owner':c,'rule':d} for a,b,c,d in primitives+derived])
    pdf.to_csv(O/'PRIMITIVE_RELATION_CLASS_RECOMMENDATION.csv',index=False)

    # ---------- P1 coverage matrix ----------
    coverage_map={
      'JE01':('PARTIAL_EXISTING','SAME_PROPOSITION_DIFFERENT_TARGET; GENERAL_TARGET_SUBTARGET','R4 target generator exists; general/subtarget taxonomy is not globally governed.'),
      'JE02':('PARTIAL_EXISTING','SAME_PROPOSITION_DIFFERENT_CONDITION','R4 exact condition generator exists; source/routing blocks remain.'),
      'JE03':('MISSING_TYPED_EDGE','GENERAL_PRINCIPLE_SPECIFIC_APPLICATION','No global typed role edge. R14/QSM can recall candidates but not authorize the relation.'),
      'JE04':('MISSING_TYPED_EDGE','GOAL_MEANS','No global typed goal/means edge authority.'),
      'JE05':('MISSING_TYPED_EDGE_WITH_OWNERSHIP_GATE','COMMITMENT_PERSONAL_COST','Requires semantic edge plus V550J-vs-V552J ownership ruling.'),
      'JE06':('MISSING_TYPED_EDGE_NARROW_CEILING','NORM_EXPECTED_CONDUCT','Requires explicit role edge; conduct lane must remain contextual unless independently signed.'),
      'JE07':('MISSING_TARGET_TAXONOMY','GENERAL_TARGET_SUBTARGET','Existing target registries do not encode a governed parent/child taxonomy.'),
      'JE08':('PARTIAL_EXISTING','INSTITUTION_CLASS_DIFFERENTIATION','R4 has institution-class candidates; class ontology/role authority incomplete.'),
      'JE09':('MISSING_DEDICATED_RECIPROCITY_EDGE','RECIPROCAL_ROLE_REVERSAL','R4 target-difference tags do not prove reciprocal role symmetry.'),
      'JE10':('PARTLY_ATOM_TOPOLOGY_NOT_J','EXPLICIT_PRIORITY_TRADEOFF','Forced tradeoff is often already V551 topology; joint authority needed only for cross-item priority comparison.'),
      'JE11':('DERIVED_AFTER_BASE_RELATIONS','INTERNAL_TENSION_TOPOLOGY','Do not create a source-semantic tension edge; derive from governed relations and answers.'),
      'JE12':('STRONG_SOURCE_SUBSTRATE_RUNTIME_GAP','SOURCE_NATIVE_ROUTED_SEQUENCE','R14 carries strong native routing; exact predicate serialization remains for runtime.'),
      'JE13':('DERIVED_NEEDS_ORDER_OR_TAXONOMY','BOUNDARY_LOCATION','Target/condition candidates exist, but meaningful boundary location requires governed order/hierarchy.'),
      'JE14':('DERIVED_MECHANICAL','CONFIGURATION_BREADTH','No new semantic authority required after membership/completeness is governed.'),
      'JE15':('DERIVED_MATRIX_ROLE_GAP','TARGET_CONDITION_MATRIX','Needs governed matrix roles; interaction is derived from cell pattern.'),
      'JE16':('MISSING_COMPLEMENTARY_ROLE_EDGE','SOURCE_NATIVE_COMMON_ROLE_SET','R14 can prove co-membership; it generally cannot prove complementary analytic role convergence.')}
    cov=[]
    for _,r in p1.iterrows():
        rid=norm_text(r['requirement_id']).upper(); rid=re.sub(r'[^A-Z0-9]','',rid)
        if rid.startswith('JE'):
            # normalize JE1 -> JE01
            m=re.match(r'JE0*(\d+)',rid); rid='JE'+str(int(m.group(1))).zfill(2) if m else rid
        status,prim,note=coverage_map.get(rid,('REVIEW_REQUIRED','',''))
        cov.append({'requirement_id':rid,'label':r.get('label'),'coverage_status':status,'recommended_primitive_or_derivation':prim,'audit_basis':note,'p1_collision_templates':r.get('collision_templates'),'evidence_ceiling':r.get('evidence_ceiling'),'prohibited_claims':r.get('prohibited_claims')})
    pd.DataFrame(cov).to_csv(O/'P1_RELATION_AUTHORITY_COVERAGE_MATRIX.csv',index=False)

    # ---------- proposed schema ----------
    proposed={
      'schema_version':'INTER_QUESTION_RELATION_AUTHORITY_R1_PROPOSAL',
      'status':'PROPOSED_NOT_INSTALLED_NOT_GOVERNING',
      'purpose':'Typed semantic edge/hyperedge authority over already-governed source-native question implementations. Does not replace P2/P3 proposition authority or R14 respondent/source structure authority.',
      'authority_rank_rules':[
        'Questionnaire/codebook/source-native structure evidence outranks inherited QSM ontology mappings.',
        'Later manually governed QRA rows override conflicting inherited QSM coordinates on overlap.',
        'P2/P3/P3C constrain equivalence, boundaries, and portability but never create respondent membership.',
        'QSM, semantic indices, lexical similarity, embeddings, common drivers/facets are discovery/recall only unless independently adjudicated.',
        'R14 can authorize source-native membership/routing but does not by itself authorize analytic semantic roles.'
      ],
      'fields':{
        'relation_authority_id':'stable immutable ID',
        'source_family':'canonical source family',
        'wave_scope':'explicit governed wave(s)',
        'source_structure_ids':'R14/R15 source-native structure IDs when applicable',
        'member_question_implementation_ids':'ordered member implementation IDs',
        'relation_type':'primitive typed relation/configuration class',
        'member_roles':'ordered semantic role per member',
        'shared_semantic_basis':'what makes joint interpretation legitimate',
        'differentiating_coordinates':'target, condition, role, cost, means, institutional class, etc.',
        'respondent_composability_authority':'separate routing/universe status; never inferred from semantics',
        'response_topology_contract':'member response-topology compatibility/role',
        'source_evidence_links':'questionnaire/codebook/R14 evidence',
        'p2_constraint_links':'P2 proposition/boundary/negative authority links',
        'p3_p3c_constraint_links':'GSS P3/P3C annotation/constraint links',
        'legacy_qsm_discovery_links':'non-authoritative recall/provenance only',
        'incremental_joint_information':'why isolated atoms cannot answer downstream ambiguity',
        'evidence_ceiling':'maximum lawful downstream claim',
        'prohibited_inferences':'explicit forbidden claims',
        'ownership_gate':'V550J, V551 only, V552J/later, or review',
        'adjudication_status':'APPROVED/REJECTED/BLOCKED/REVIEW_REQUIRED',
        'rationale':'two-sided semantic ruling',
        'closure_hash':'canonical row/object hash'
      },
      'primitive_relation_types':[x[0] for x in primitives if not x[1].startswith('CONFIGURATION')],
      'configuration_types':['TARGET_CONDITION_MATRIX'],
      'derived_not_source_semantic_edge_types':[x[0] for x in derived]
    }
    (O/'INTER_QUESTION_RELATION_AUTHORITY_R1_PROPOSED_SCHEMA.json').write_text(json.dumps(proposed,indent=2,ensure_ascii=False)+'\n')

    # ---------- validation ----------
    # Current V550J config enum inspection
    enum=[]
    def walk(obj):
        if isinstance(obj,dict):
            if 'configuration_type' in obj: pass
            for k,v in obj.items():
                if k=='configuration_type' and isinstance(v,dict) and isinstance(v.get('enum'),list): enum.extend(v['enum'])
                walk(v)
        elif isinstance(obj,list):
            for x in obj: walk(x)
    walk(schema)
    # simpler recursive enum scan for property name
    def find_config_enum(obj):
        if isinstance(obj,dict):
            props=obj.get('properties')
            if isinstance(props,dict) and 'configuration_type' in props and isinstance(props['configuration_type'],dict):
                if isinstance(props['configuration_type'].get('enum'),list): return props['configuration_type']['enum']
            for v in obj.values():
                r=find_config_enum(v)
                if r: return r
        elif isinstance(obj,list):
            for v in obj:
                r=find_config_enum(v)
                if r: return r
        return []
    config_enum=find_config_enum(schema)

    validation={
      'status':'PASS_AUDIT_COMPLETE_GLOBAL_V550J_AUTHORITY_NOT_CLOSED',
      'scope_wave_count':int(wave_registry.get('entry_count',len(scope_rows))),
      'scope_status':wave_registry.get('scope_status'),
      'scope_contains_lits_i_ii_iii_iv':all((('LiTS',w) in production_pairs) for w in ['I','II','III','IV']),
      'scope_excludes_asian_barometer_w6':(('Asian Barometer','W6') not in production_pairs),
      'qrr_rows':len(qrr),'qsm_rows':len(qsm),'qra700_rows':len(qra),'manual_directional_rows':len(dir236),
      'r14_objects':len(r14['objects']),'r14_source_native_relation_multi_objects':len(rdf),'r14_relation_members_in_multi_objects':int(rel_member_total),
      'r14_all_members_qsm_matched_objects':int(rdf['all_members_qsm_matched'].sum()),
      'r14_all_members_qsm_all6_objects':int(rdf['all_members_qsm_all6'].sum()),
      'r14_all_members_qsm_all6_noinfer_objects':int(rdf['all_members_qsm_all6_noinfer'].sum()),
      'r14_all_members_qsm_axis_target_noinfer_objects':int(rdf['all_members_qsm_axis_target_noinfer'].sum()),
      'r14_all_members_qra700_matched_objects':int(rdf['all_members_qra700_matched'].sum()),
      'r14_any_member_qra700_matched_objects':int(rdf['any_member_qra700_matched'].sum()),
      'r14_all_members_full_qrr_matched_objects':int(rdf['all_members_full_qrr_matched'].sum()),
      'qra_directional_qsm_matched':int(stat['matched_qsm']),'qra_directional_qsm_missing':int(stat['missing_qsm']),
      'p2_pair_rows':len(p2),'p3_pair_rows':len(p3),'r4_candidate_rows':len(r4),
      'v550j_r1_configuration_type_enum':config_enum,
      'core_conclusions':[
        'R14 supplies a strong source-native candidate-membership/routing substrate.',
        'Full QSM is discovery/lineage material, not promotable semantic authority: it is inference-heavy and conflicts materially with later manual QRA on overlap.',
        'The 700-row manual QRA is a precision control/calibration surface, not sufficient coverage for the full R14 relation-object universe.',
        'P2/P3 provide proposition/boundary constraints, not within-source respondent-level semantic role membership.',
        'A new typed inter-question edge/hyperedge adjudication layer is genuinely required, but it can operate over bounded source-native candidates rather than all-pairs or re-reading the entire corpus.',
        'Several P1 requirements are derived outputs rather than primitive source-semantic relation types.'
      ],
      'forbidden_next_moves':[
        'Do not promote QSM infer_* coordinates to governing relation authority.',
        'Do not treat QRR question_family/driver coincidence as joint-family authority.',
        'Do not use P2/P3 pair relation as respondent membership.',
        'Do not run all-pairs, correlation, or embedding authorization.',
        'Do not run V551J/V552J production until typed relation authority and routing predicates are closed.'
      ]
    }
    (O/'VALIDATION_RETURN.json').write_text(json.dumps(validation,indent=2)+'\n')

    # ---------- report ----------
    qsm_status=qsm['mapping_status'].fillna('').value_counts().to_dict()
    infer_counts={c:int(qsm[c].map(is_infer).sum()) for c in coords}
    reg_singletons=defdf.groupby('registry')['singleton_in_700_derived_registry'].sum().to_dict()
    reg_counts=defdf.groupby('registry').size().to_dict()
    p2cls=p2['normalized_authority_class'].fillna('').value_counts().to_dict()
    p3cls=p3['normalized_authority_class'].fillna('').value_counts().to_dict()
    report=f'''# Rawlsing V550J Semantic Authority Convergence Audit — R1\n\nStatus: **AUDIT COMPLETE; GLOBAL ANALYTIC V550J AUTHORITY NOT YET CLOSED.**\n\n## Executive conclusion\n\nThe repository does not need a new semantic ontology from zero. It already contains the major substrates required for Analytic V550J: a 35-wave full runtime relation inventory, a full structural mapping, a high-precision manually governed question-relation subset, source-native R14/R15 structures with respondent/routing evidence, P2/P3 proposition and boundary authority, and an executable GSS family model. However, these surfaces do **not** compose automatically into a governing within-source inter-question semantic-relation authority. The missing layer is real but narrower than a corpus-wide reinterpretation: a typed edge/hyperedge adjudication layer over bounded source-native candidate structures.\n\n## Evidence-stack ruling\n\n1. **R14/R15 owns source-native structure, membership, routing, universe, applicability, and completion evidence.** It is the primary bounded candidate substrate.\n2. **P2/P3/P3C own proposition relation/boundary/portability constraints.** They may approve, constrain, redirect, or block semantic equivalence; they do not create respondent-level family membership.\n3. **The July-29 manual 700-row QRA is a precision calibration/control surface.** Its 236 directional rows are stronger than conflicting inherited QSM mappings on overlap, but it is not full-corpus coverage.\n4. **The 18,518-row QSM is discovery/lineage, not final authority.** Its mixed ancestry, inference placeholders, and material disagreement with later manual authority prevent wholesale promotion.\n5. **The 16,640-row QRR is a broad runtime inventory/recall surface.** Its coarse question-family and driver labels are useful for discovery but cannot prove the required semantic roles.\n\n## Foundational-registry quality findings\n\nThe full QSM has {len(qsm):,} rows. Mapping status is {qsm_status}. `relation_axis_id` contains {infer_counts['relation_axis_id']:,} `infer_*` values and `target_entity_id` contains {infer_counts['target_entity_id']:,}; only a minority of source-native relation objects can be fully typed from non-inferred coordinates.\n\nThe July-29 derived registries are also thin taxonomies rather than deep ontologies: question-block registry {reg_counts.get('question_block',0)} IDs ({reg_singletons.get('question_block',0)} singleton-use); relation-axis {reg_counts.get('relation_axis',0)} ({reg_singletons.get('relation_axis',0)} singleton-use); target-entity {reg_counts.get('target_entity',0)} ({reg_singletons.get('target_entity',0)} singleton-use); structural-domain {reg_counts.get('structural_domain',0)}. Their entries generally provide labels/usage/examples but not explicit exclusion criteria or parent-child semantics. This matters especially for `GENERAL_TARGET_SUBTARGET`, institution classes, reciprocity, and boundary-location derivation.\n\nThe full-QSM vocabulary and the later 700-row registry vocabulary are fractured. See `QSM_VS_700_REGISTRY_VOCABULARY_FRACTURE.csv`; this is not merely a naming issue because the 236 manually governed directional rows materially disagree with QSM on multiple coordinates. See `QRA700_DIRECTIONAL_VS_QSM_CONFLICTS.csv`.\n\nThe current `question_family_registry.yaml` is useful as an **executable expression model**, not as the conceptual universe. It contains three draft GSS families with explicit item-role groups, target-resolution rules, boundary rules, and response-role contracts. Its declared eligible-wave lists also contain historical/non-production GSS waves, so production scope must continue to come from the canonical 35-wave registry rather than from family-registry eligibility. See `CURRENT_GSS_FAMILY_EXPRESSION_MODEL_AUDIT.csv`.\n\n## Source-native candidate substrate\n\nThe corrected R14/R15 authority contains {len(r14['objects']):,} source-native objects. Under the conservative relation-member extraction used here, {len(rdf):,} objects contain at least two relation-structure members, totaling {rel_member_total:,} members. Of those objects, {int(rdf['all_members_qsm_matched'].sum()):,} have every relation member matched to QSM, but only {int(rdf['all_members_qsm_all6'].sum()):,} have all six QSM structural coordinates present for every member, and **{int(rdf['all_members_qsm_all6_noinfer'].sum()):,}** have all six present without any `infer_*` placeholder. Only {int(rdf['all_members_qsm_axis_target_noinfer'].sum()):,} have non-inferred axis+target for every member.\n\nThis is decisive: **R14 gives us the bounded source-native structures to adjudicate, while QSM cannot mechanically type them.** The right next operation is not all-pairs discovery; it is semantic role adjudication over this bounded source-native queue plus the exact target/condition candidates already found by R4.\n\n## P2/P3 constraint capability\n\nP2 has {len(p2):,} terminal semantic-priority pair rows and P3 has {len(p3):,} GSS pair-authority rows. P2 class distribution is {p2cls}. P3 class distribution is {p3cls}. These are strong for negative authority, bounded relations, proposition identity, and portability ceilings. They are not a substitute for within-source role edges such as principle→application, goal→means, norm→conduct, or commitment→cost.\n\n## What R4 already closes\n\nR4's 508 candidates are useful, not superseded. They cover exact/bounded machinery for same-proposition differentiated target, same-proposition differentiated condition, institution-class differentiation, and a tiny routed-sequence surface. They should become existing evidence in the new typed edge authority, not be rerun from scratch.\n\nWhat R4 does **not** close is the semantic-role universe required by P1. The apparent JE09/JE13/JE15 tags on target/condition candidates are downstream *potential uses*, not proof of reciprocity, boundary order, or target×condition semantic matrices.\n\n## Primitive versus derived relation law\n\nThe P1 sixteen requirements should not become sixteen source-semantic edge types. The recommended primitive/derived split is in `PRIMITIVE_RELATION_CLASS_RECOMMENDATION.csv`. In particular:\n\n- add explicit primitive authority for principle/application, goal/means, commitment/cost, norm/conduct, general/subtarget, reciprocal-role reversal, and complementary-role sets;\n- retain existing target, condition, institution-class, and routed-sequence primitives;\n- treat explicit forced tradeoff as V551 topology unless a cross-item joint relation is actually required;\n- derive internal tension, boundary location, configuration breadth, and target-condition interaction downstream from accepted semantic relations and observed answer patterns.\n\nThis avoids turning every downstream analytic use into a source ontology category.\n\n## Required new authority surface\n\nCreate a common, versioned `INTER_QUESTION_RELATION_AUTHORITY` with stable IDs, explicit relation type, ordered member roles, source-native structure links, separate respondent-composability authority, P2/P3 constraint links, incremental-information rationale, evidence ceiling, prohibited inferences, ownership gate, and terminal adjudication. A proposed non-governing schema is supplied in `INTER_QUESTION_RELATION_AUTHORITY_R1_PROPOSED_SCHEMA.json`.\n\nThe candidate queue in `SEMANTIC_EDGE_ADJUDICATION_QUEUE.csv` is deliberately **discovery-only**. Its keyword-derived type suggestions are recall hints, never authority. Final rulings must be source-first and two-sided.\n\n## Recommended execution order\n\n1. Freeze the corrected 35-wave R14/P2/P3 state and preserve LiTS I/IV.\n2. Adopt the authority precedence rules in the proposed schema; do not rewrite QSM in place during relation adjudication.\n3. Reconcile the full-QSM vocabulary against later manual QRA only where it is needed to support typed-edge review; do not attempt a gratuitous whole-ontology rewrite before V550J.\n4. Adjudicate the bounded R14/R15 source-native multi-relation queue for the missing primitive relation classes, with P2/P3 as constraints.\n5. Union those approved typed edges with R4's already-governed exact target/condition/institution/routing candidates.\n6. Build a common V550J authority schema R2 only where the existing R1 configuration enum cannot truthfully express approved primitives. No source-local special cases.\n7. Serialize exact applicability predicates from R14 routing evidence; unresolved prose-only routing remains blocked.\n8. Freeze a new no-loss denominator and re-adjudicate/compile Analytic V550J.\n9. Only after closure, run V551J → V552 → V552J canaries and then production.\n\n## Stop conditions\n\nDo not treat common driver/facet, QSM inference, lexical similarity, embeddings, P2 cross-source pair authority, P3 proposition authority, or source-native co-membership by itself as sufficient proof of an analytic semantic role edge. Do not force every source-native battery into V550J: if isolated atoms already preserve all downstream information, reject it as wrong ownership/no incremental information.\n'''
    (O/'AUTHORITY_CONVERGENCE_AUDIT_REPORT.md').write_text(report)

    handoff=f'''# Codex next implementation handoff — after semantic authority convergence audit\n\n## Governing objective\n\nComplete Analytic V550J for the full 35-wave Rawlsing production scope without collapsing proposition authority, source-native respondent structure, or downstream structural-pressure logic into one layer. LiTS I/II/III/IV are in scope; Asian Barometer W6 is excluded.\n\n## Do not redo\n\n- Do not reopen the corrected LiTS I/IV R14 recovery.\n- Do not rerun P2/P3/P3C from scratch.\n- Do not discard R4's 508 terminal candidates; treat them as an existing checkpoint and source for already-covered exact target/condition/institution/routing relations.\n- Do not promote the full QSM or the 16,640-row QRR into joint-family authority.\n- Do not authorize from correlation, embedding similarity, common driver/facet, prefix, or co-membership alone.\n\n## Immediate work program\n\n### A. Install no new authority yet; first ingest this audit\nRead `AUTHORITY_CONVERGENCE_AUDIT_REPORT.md`, `VALIDATION_RETURN.json`, `P1_RELATION_AUTHORITY_COVERAGE_MATRIX.csv`, `PRIMITIVE_RELATION_CLASS_RECOMMENDATION.csv`, and `INTER_QUESTION_RELATION_AUTHORITY_R1_PROPOSED_SCHEMA.json`.\n\n### B. Preserve authority precedence\nUse source questionnaire/codebook + R14/R15 as source-native membership/routing authority. Use later manual QRA as stronger than conflicting inherited QSM coordinates on overlap. Use P2/P3/P3C only as semantic equivalence/boundary/portability constraints. QSM/QRR/semantic indices are candidate recall and lineage unless independently governed.\n\n### C. Build the typed-edge adjudication workbench\nStart with `SEMANTIC_EDGE_ADJUDICATION_QUEUE.csv`. It is a bounded source-native queue, not approved authority. Add R4 candidates as already-adjudicated evidence. For each candidate structure, adjudicate whether there is incremental respondent-level information and, if so, assign only a truthful primitive relation/configuration type and ordered member roles.\n\nPriority missing primitives:\n1. `GENERAL_PRINCIPLE_SPECIFIC_APPLICATION`\n2. `GOAL_MEANS`\n3. `COMMITMENT_PERSONAL_COST` with ownership gate\n4. `NORM_EXPECTED_CONDUCT` with narrow evidence ceiling\n5. `GENERAL_TARGET_SUBTARGET` with explicit target hierarchy\n6. `RECIPROCAL_ROLE_REVERSAL`\n7. `SOURCE_NATIVE_COMMON_ROLE_SET` / complementary-role convergence\n8. explicit cross-item priority/tradeoff only when V551 item topology alone is insufficient\n\n### D. Do not over-model derived outputs\nInternal tension topology, boundary location, configuration breadth, and target-condition interaction are downstream derivations from governed relations/roles and observed answers. They are not automatically new source-semantic edge classes.\n\n### E. Schema evolution\nThe current `V550J_AUTHORITY_SCHEMA_R1` already expresses principle/application and means/end, but not all required primitives truthfully. If approved authority requires extension, create one common versioned R2 extension rather than source-local fields. Preserve R1 compatibility/migration evidence and hashes.\n\n### F. Routing\nCompile exact applicability predicates only where R14/R15 source evidence supports them. A source-native object may authorize membership but still remain runtime-blocked if its respondent predicate cannot be serialized exactly. Do not infer routing.\n\n### G. Closure\nAfter typed-edge adjudication, union approved new edges with R4 exact relation authority, freeze a new no-loss denominator, run terminal adjudication, validate mutation/adversarial gates, and only then compile V550J runtime authority. V551J/V552J remain downstream until closure.\n\n## Required outputs\n\n- versioned inter-question relation authority registry\n- complete adjudication ledger with terminal row for every candidate\n- rejected/wrong-ownership ledger\n- blocked-evidence/routing ledger\n- target hierarchy / institution-class authority only where actually needed\n- schema R2 diff and migration contract if necessary\n- denominator revision ledger\n- source/hash manifest\n- mutation/adversarial validation return\n- final V550J closure return\n\n## Acceptance principle\n\nThe goal is not maximum family count. The goal is complete bounded coverage of respondent-level joint information that isolated governed atoms cannot preserve, with no semantic or routing inference beyond the source authority chain.\n'''
    (O/'CODEX_NEXT_IMPLEMENTATION_HANDOFF.md').write_text(handoff)

    readme=f'''# START HERE — Rawlsing V550J Semantic Authority Convergence Audit R1\n\nThis package answers the question: **does Rawlsing already contain the within-source semantic relation authority needed to finish Analytic V550J, or must it be built?**\n\nAnswer: **partially, but not as a complete governed edge layer.** Existing source-native R14/R15, P2/P3, QRA, QSM/QRR, and R4 surfaces can sharply bound and constrain the work. A new typed inter-question semantic edge/hyperedge authority is still required for the missing role relations, but it can be adjudicated over a bounded source-native queue rather than by all-pairs discovery or corpus-wide reinterpretation.\n\nRead in order:\n1. `output/AUTHORITY_CONVERGENCE_AUDIT_REPORT.md`\n2. `output/VALIDATION_RETURN.json`\n3. `output/P1_RELATION_AUTHORITY_COVERAGE_MATRIX.csv`\n4. `output/PRIMITIVE_RELATION_CLASS_RECOMMENDATION.csv`\n5. `output/INTER_QUESTION_RELATION_AUTHORITY_R1_PROPOSED_SCHEMA.json`\n6. `output/CODEX_NEXT_IMPLEMENTATION_HANDOFF.md`\n7. `output/SEMANTIC_EDGE_ADJUDICATION_QUEUE.csv` (discovery/review queue, **not authority**)\n\nThe `inputs/` directory in the cumulative ZIP preserves the exact upstream packages used for lineage. The `input_snapshot/` subset contains the exact files consumed by the reproducible audit script.\n'''
    (O.parent/'README_FIRST.md').write_text(readme)

    # input manifest
    manifest=[]
    for p in sorted(S.iterdir()):
        if p.is_file(): manifest.append({'path':p.name,'bytes':p.stat().st_size,'sha256':sha256(p)})
    pd.DataFrame(manifest).to_csv(O/'INPUT_SHA256_MANIFEST.csv',index=False)

if __name__=='__main__': main()
