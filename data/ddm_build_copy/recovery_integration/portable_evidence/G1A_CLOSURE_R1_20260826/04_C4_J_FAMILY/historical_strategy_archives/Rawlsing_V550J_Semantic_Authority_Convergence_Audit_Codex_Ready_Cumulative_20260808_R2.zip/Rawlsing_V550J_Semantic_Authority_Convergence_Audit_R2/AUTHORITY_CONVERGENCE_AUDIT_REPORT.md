# Rawlsing V550J Semantic Authority Convergence Audit — R1

Status: **AUDIT COMPLETE; GLOBAL ANALYTIC V550J AUTHORITY NOT YET CLOSED.**

## Executive conclusion

The repository does not need a new semantic ontology from zero. It already contains the major substrates required for Analytic V550J: a 35-wave full runtime relation inventory, a full structural mapping, a high-precision manually governed question-relation subset, source-native R14/R15 structures with respondent/routing evidence, P2/P3 proposition and boundary authority, and an executable GSS family model. However, these surfaces do **not** compose automatically into a governing within-source inter-question semantic-relation authority. The missing layer is real but narrower than a corpus-wide reinterpretation: a typed edge/hyperedge adjudication layer over bounded source-native candidate structures.

## Evidence-stack ruling

1. **R14/R15 owns source-native structure, membership, routing, universe, applicability, and completion evidence.** It is the primary bounded candidate substrate.
2. **P2/P3/P3C own proposition relation/boundary/portability constraints.** They may approve, constrain, redirect, or block semantic equivalence; they do not create respondent-level family membership.
3. **The July-29 manual 700-row QRA is a precision calibration/control surface.** Its 236 directional rows are stronger than conflicting inherited QSM mappings on overlap, but it is not full-corpus coverage.
4. **The 18,518-row QSM is discovery/lineage, not final authority.** Its mixed ancestry, inference placeholders, and material disagreement with later manual authority prevent wholesale promotion.
5. **The 16,640-row QRR is a broad runtime inventory/recall surface.** Its coarse question-family and driver labels are useful for discovery but cannot prove the required semantic roles.

## Foundational-registry quality findings

The full QSM has 18,518 rows. Mapping status is {'accepted_context_only': 10742, 'accepted_existing_mapping': 4861, 'accepted_block_child': 2907, 'context_not_applicable': 7, 'women_rights_representation': 1}. `relation_axis_id` contains 6,971 `infer_*` values and `target_entity_id` contains 13,489; only a minority of source-native relation objects can be fully typed from non-inferred coordinates.

The July-29 derived registries are also thin taxonomies rather than deep ontologies: question-block registry 152 IDs (125 singleton-use); relation-axis 146 (127 singleton-use); target-entity 154 (128 singleton-use); structural-domain 22. Their entries generally provide labels/usage/examples but not explicit exclusion criteria or parent-child semantics. This matters especially for `GENERAL_TARGET_SUBTARGET`, institution classes, reciprocity, and boundary-location derivation.

The full-QSM vocabulary and the later 700-row registry vocabulary are fractured. See `QSM_VS_700_REGISTRY_VOCABULARY_FRACTURE.csv`; this is not merely a naming issue because the 236 manually governed directional rows materially disagree with QSM on multiple coordinates. See `QRA700_DIRECTIONAL_VS_QSM_CONFLICTS.csv`.

The current `question_family_registry.yaml` is useful as an **executable expression model**, not as the conceptual universe. It contains three draft GSS families with explicit item-role groups, target-resolution rules, boundary rules, and response-role contracts. Its declared eligible-wave lists also contain historical/non-production GSS waves, so production scope must continue to come from the canonical 35-wave registry rather than from family-registry eligibility. See `CURRENT_GSS_FAMILY_EXPRESSION_MODEL_AUDIT.csv`.

## Source-native candidate substrate

The corrected R14/R15 authority contains 730 source-native objects. Under the conservative relation-member extraction used here, 445 objects contain at least two relation-structure members, totaling 2,785 members. Of those objects, 358 have every relation member matched to QSM, but only 56 have all six QSM structural coordinates present for every member, and **0** have all six present without any `infer_*` placeholder. Only 20 have non-inferred axis+target for every member.

This is decisive: **R14 gives us the bounded source-native structures to adjudicate, while QSM cannot mechanically type them.** The right next operation is not all-pairs discovery; it is semantic role adjudication over this bounded source-native queue plus the exact target/condition candidates already found by R4.

## P2/P3 constraint capability

P2 has 18,831 terminal semantic-priority pair rows and P3 has 57,308 GSS pair-authority rows. P2 class distribution is {'NEGATIVE_AUTHORITY': 14857, 'REDIRECTED_OTHER_DOMAIN_AUTHORITY': 1958, 'COORDINATE_OR_BOUNDED_RELATION_AUTHORITY': 1024, 'PROPOSITION_RELATION_AUTHORITY': 641, 'UNRESOLVED_FAIL_CLOSED_AUTHORITY': 351}. P3 class distribution is {'COORDINATE_OR_BOUNDED_RELATION_AUTHORITY': 37919, 'NEGATIVE_AUTHORITY': 10663, 'NEGATIVE_OR_COORDINATE_AUTHORITY': 6561, 'REDIRECTED_ADMINISTRATIVE_OR_NONRESPONDENT_CONTEXT': 1148, 'REDIRECTED_OTHER_DOMAIN_AUTHORITY': 614, 'PROPOSITION_RELATION_AUTHORITY': 403}. These are strong for negative authority, bounded relations, proposition identity, and portability ceilings. They are not a substitute for within-source role edges such as principle→application, goal→means, norm→conduct, or commitment→cost.

## What R4 already closes

R4's 508 candidates are useful, not superseded. They cover exact/bounded machinery for same-proposition differentiated target, same-proposition differentiated condition, institution-class differentiation, and a tiny routed-sequence surface. They should become existing evidence in the new typed edge authority, not be rerun from scratch.

What R4 does **not** close is the semantic-role universe required by P1. The apparent JE09/JE13/JE15 tags on target/condition candidates are downstream *potential uses*, not proof of reciprocity, boundary order, or target×condition semantic matrices.

## Primitive versus derived relation law

The P1 sixteen requirements should not become sixteen source-semantic edge types. The recommended primitive/derived split is in `PRIMITIVE_RELATION_CLASS_RECOMMENDATION.csv`. In particular:

- add explicit primitive authority for principle/application, goal/means, commitment/cost, norm/conduct, general/subtarget, reciprocal-role reversal, and complementary-role sets;
- retain existing target, condition, institution-class, and routed-sequence primitives;
- treat explicit forced tradeoff as V551 topology unless a cross-item joint relation is actually required;
- derive internal tension, boundary location, configuration breadth, and target-condition interaction downstream from accepted semantic relations and observed answer patterns.

This avoids turning every downstream analytic use into a source ontology category.

## Required new authority surface

Create a common, versioned `INTER_QUESTION_RELATION_AUTHORITY` with stable IDs, explicit relation type, ordered member roles, source-native structure links, separate respondent-composability authority, P2/P3 constraint links, incremental-information rationale, evidence ceiling, prohibited inferences, ownership gate, and terminal adjudication. A proposed non-governing schema is supplied in `INTER_QUESTION_RELATION_AUTHORITY_R1_PROPOSED_SCHEMA.json`.

The candidate queue in `SEMANTIC_EDGE_ADJUDICATION_QUEUE.csv` is deliberately **discovery-only**. Its keyword-derived type suggestions are recall hints, never authority. Final rulings must be source-first and two-sided.

## Recommended execution order

1. Freeze the corrected 35-wave R14/P2/P3 state and preserve LiTS I/IV.
2. Adopt the authority precedence rules in the proposed schema; do not rewrite QSM in place during relation adjudication.
3. Reconcile the full-QSM vocabulary against later manual QRA only where it is needed to support typed-edge review; do not attempt a gratuitous whole-ontology rewrite before V550J.
4. Adjudicate the bounded R14/R15 source-native multi-relation queue for the missing primitive relation classes, with P2/P3 as constraints.
5. Union those approved typed edges with R4's already-governed exact target/condition/institution/routing candidates.
6. Build a common V550J authority schema R2 only where the existing R1 configuration enum cannot truthfully express approved primitives. No source-local special cases.
7. Serialize exact applicability predicates from R14 routing evidence; unresolved prose-only routing remains blocked.
8. Freeze a new no-loss denominator and re-adjudicate/compile Analytic V550J.
9. Only after closure, run V551J → V552 → V552J canaries and then production.

## Stop conditions

Do not treat common driver/facet, QSM inference, lexical similarity, embeddings, P2 cross-source pair authority, P3 proposition authority, or source-native co-membership by itself as sufficient proof of an analytic semantic role edge. Do not force every source-native battery into V550J: if isolated atoms already preserve all downstream information, reject it as wrong ownership/no incremental information.
