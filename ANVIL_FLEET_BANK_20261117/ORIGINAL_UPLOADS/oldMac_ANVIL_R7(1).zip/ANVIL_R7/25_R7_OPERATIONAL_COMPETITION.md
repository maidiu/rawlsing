# R7 operational competition, evidence and receiving law

## H0 — competent controlling authority, source and measurement freeze

Before work, read the canonical PYAT PROGRAMMA OATH and live paired CURRENT_PROGRESS; reconcile protected PRE-MAIN, controlling #1097/#960/#1108/#1133 and current actual code heads/independent grades/leases. The last verified checkpoint in the predecessor analysis is **7fc00289dd801d2d0a8ce159986c7595fc27a4d9** but must not be passed off as newly current. Distinguish full GitHub native owner readback, sourcefree acceptance, unresolved failing CI, external worker runtime and user-authorized branch rights. Do not create HQ authority by preparing ANVIL.

Freeze one real first consumer and actual lawfully available 13-family source path. Freeze the **material comparison floor** `24_R7_MACHINE_POLICY.json` with a concrete seven-shape, repeated/cold real-width geometry, source/rights/first consumer, A/B code and input cuts, honest performed runner type, negative/restore, 6GiB process-tree ceiling. 100k respondents with 3.245 sparse events is NOT dense 600-opportunity respondent width. Source-native physical proof remains source-owner held until granted. Hard limits beyond 6GiB, if any, need owner-specific evidence; do not fabricate latency/disk ceilings.

Every numeric comparator result MUST be reproducible from typed **per-side, per-cell** `ANVIL_R7_MEASUREMENT_RECEIPT` JSON bytes, exact SHA-256, metric unit, interval and geometry. Every nonnumeric hard veto requires separate candidate-specific `ANVIL_R7_VETO_RECEIPT` and source/negative/first-consumer refs. Any displayed advantage not equal to its receipt contents is invalid. Hash-consistent receipts remain **self-described** until the actual runner and independent reviewer authenticate their origin and validity.

### B-discovered materiality and scope

B may establish that a frozen material frame omitted a genuinely outcome-reversing discriminator, e.g. incremental conditional-population invalidation. No after-result goalpost change; no deletion of earlier measurement. Under `tools/r7_decision.py`, an additive versioned before-first-result plan must point at a SHA-matched parent, preserve all old cells, establish a new typed unit and exact B challenge, and carry a C review receipt. A discovered but unmeasured or owner-held discriminator leaves the choice conditional. The R7 machine floor is a **minimum**, not a prohibition on discovering better questions.

No exclusion can by itself prove whole-scope dominance. A legitimately excluded case may yield a **scoped, conditional** conclusion only after B/C and competent owner examine its reversal risk; it cannot be hidden behind long prose. B and C independently question dense geometry, 1/10/100 distinct operations, source meaning, larger repeated operation sets, cold rebuild, hard RSS, retained and scratch disk, cross-world reusable cohorts and actual F1–F4/first-reader effects.

## A — strongest incumbent; B — strongest genuine alternative

A starts from accepted October 28 S2-B/C/D/E, existing saved full C11 direct Parquet/Zstd, native I03, #997/#1006 corrective work, #1103 prepared-session candidate and current actual first-reader. A must not regress source proof or confuse original `body_json`+typed columns, intermediary 13 JSONL journals, old full-object W03 with a single current engine.

B independently starts from **full reverse requirements**: SEAM/26/ANVIL/15, #998/#1009/#1011, historic V549/V550J and K3 functional conservation. It must propose a technically distinguishable executable architecture and expose missing material discriminators rather than merely criticize A. Allow any lawful reuse/adapt/compose, not automatic DuckDB/SQLite/Arrow fashion. A/B authors freeze their own first return before reading substantive opponent results, then one reciprocal challenge only.

## P1.5 — cannot manufacture a decisive result

`tools/r7_stage.py` reads the actual frozen plan and exact input files, recomputes the R7 comparator, checks **all** material cells and permits only a *provisional* matched decisive result. It does not accept a worker's `decision_reverser=false` flag, an invented `runner_receipts` string or a free-text comparator status. If B is unmeasured, an important interval overlaps, a hard veto is failed/held, a C-qualifiable exclusion is pending or an additional B discriminator is unresolved, record exact hold. An unmeasured B is not a defeated B. Use one authorized bounded disposable proof if needed, not two fully built backends.

## P2 — one coherent physical system, not a favorable component benchmark

Bind the **complete R5/R6 SPINE** with all 118 historical ID source meaning/negative/consumer rows, authority/epistemic case, five future paths, six deterministic R5 projections and transitive impact tool. Add `ANVIL_R7_PHYSICAL_DECISION_LEDGER` for **each** material physical choice with selected candidate, existing inherited R5 physical decision ID(s), DAG dependencies, class-specific workload×metric cells, actual first consumer, typed source-semantic effect, negative/restore and source/actor veto. An unknown dependency or storage choice borrowing build-only data fails. Every new choice must be separately justifiable; if a necessary metric is unavailable, hold that choice, not the whole project indiscriminately.

Selection is not the end of construction: P2 explicitly distinguishes (a) executable current consumer, (b) source-static construction specification, (c) reversible future nonpreclusion and (d) future scientific/actor owner-held law. Preserve original source/instrument/weight/time, independent material structural observations, legitimate surrounding-person positions, exogenous world events, actor activity/knowledge/retrospective narration separately. No survey answer becomes private motive or structural cause by diagram.

## C — separately independent, hostile and builder-oriented

C reopens the actual source HEAD/rights, real hardware and metric receipts, typed claims/whole-machine graph (`tools/r7_typed.py`), full legacy SPINE semantics (`r5_contract.py` + `anvil.py`), every physical choice, and the two builder cards. Source-static builder must point to **existing producer and consumer symbols**, actual pinned source root, explicit test command and complete operation ABI; any missing symbol is a HOLD. Executed-first-reader proof additionally needs exact test output, negative/refusal and restoration evidence; no source-static proof promoted into an executed one.

C's culminating adversarial question is **“What is the strongest architectural objection that survives all comparisons, and could its truth change the selected architecture at the claimed scope?”** A YES blocks unconditional selection. A NO requires specific evidence—not a confidence adjective. The local C validator can check payload integrity and typology, not reviewer independence, consent, source science or runner authenticity. C is genuinely independent only after external reviewer/owner verification, never by `reviewer_relationship` text alone.

## H1 — independent external competent receiving

The local H1 checker deliberately refuses to authenticate an alleged protected CAS from self-generated JSON. A competent owner must establish exact live protected ref, independently received C/P2 cut, valid external source/runner/lease/science scope, and one authorized paired CURRENT_PROGRESS MD/JSON update. The owner may accept a **scoped design** without pretending a completed physical build, a **conditional engineering advance** only with an independently verified useful first-consumer change or narrower executable blocker, or an exact HOLD. This architecture inquiry cannot independently mint source rights, experimental causal rules, actual actor grants or protected merges.

## Stop rule and MCR-lite

Use the shortest finite real-work sequence. Every intervention must retain existing source evidence, meaningful negatives and a real later consumer. Current accepted sourcefree engineering remains accepted sourcefree, even if original-source permission is held. Once R7's substantive architecture contest has a valid result, **stop designing competitions and build the selected engine** under proper owner rights. If evidence cannot determine a winner, return the exact falsifier and permit lawful P0 work rather than generating another campaign constitution.
