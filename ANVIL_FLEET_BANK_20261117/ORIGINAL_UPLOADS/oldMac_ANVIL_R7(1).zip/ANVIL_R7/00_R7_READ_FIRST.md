# ANVIL R7 — single controlling entrypoint

**STATUS `R7_AUTHOR_PREPARED_LOCAL_TESTED__INDEPENDENT_C_AND_OWNER_RECEIVING_PENDING`.** This is a repaired **architecture-selection campaign**, not an executed Rawlsing architecture, new source issuer, production release, appointed PYAT HQ, independently accepted design, or permission to merge/dispatch. The exact R5, R6 and independent mainMAC R6 evidence is preserved inside this distribution.

## The non-negotiable mission

The mission is to select **one economically feasible, scientifically meaning-conserving, source-authenticated, reusable empirical pipeline**:

**lawfully qualified SAV/DTA → complete persistent source-direct thirteen-family C11 → verifiable fresh-process cold reads and economical 1/10/100 DISTINCT operations under ≤6 GiB whole process tree → respondent-coherent F1–F4 / shared conditionals, negatives, restart → meaningful actual first consumer (#998) → separately qualified Field Forge, world and actor possibilities.**

This is not a generic database tournament. Its final downstream purpose is a historically conditioned, independently acting person within a changing material and relational world, **not** a survey vector animated by an LLM. Conserve: source-native instrument semantics and languages; source/wave/country time; real individual vs household/roster grain and ordered/multiple responses; eligible/asked/released/observed/unobserved states; sample weights/design and distinct populations/risk/denominators; true same-respondent high-order joints, F2 in both directions, minority/recursive/contradiction exploration, full negative and restoration; empirical descriptions independent of actual material structural causal sources; qualified institutional/resource power, independently existing others and exogenous world events; SOROK's separate actor development, incomplete knowledge, contradictory activity and no predetermined outcomes. Preserve optionality without inventing these later scientific rules today.

**Immediate work priority:** make generic C11 physically and economically operative under the real source and first-reader constraints, with a third-family independent falsifier; DO NOT force all 35 sources, full FF/SEAM/SOROK invention, or historical K4 before this. A lawful P0 engineering correction can proceed when an unrelated science/actor owner is held.

## Authority and version law

1. **Foundation:** PYAT HQ Nov 16 14:42 checkpoint, original ANVIL #1108 mandate and #1097/#960 operating programme, PRE-MAIN PROGRAMMA + OATH and paired CURRENT_PROGRESS, adopted historical five-test rule, MCR-lite. A historical checkpoint explains the mission; it does not overrule later competent receiving.
2. **Later verified documentary change:** as checked during R7 preparation, protected PRE-MAIN at `7fc00289dd801d2d0a8ce159986c7595fc27a4d9` received K3 29 historical families, 26 prospective proposals ALL **NOT_ADOPTED**, and 14 exact proof obligations still **HELD**, at S0–S1 with disclosed failing CI, progress revision 9. Recheck **live HEAD** at H0. This is not science/native/actor accreditation.
3. **Historical conservation:** frozen 45-file R5 including its intact manifest (`R5_BASELINE/`) and *all six executable projections* remain reachable; 44 R5 payload hashes exact. R5/R6 legacy APIs remain for historical scope but **cannot confer R7 selection**. MainMAC R6's 33 source payloads remain verifiable in `MAINMAC_R6_REFERENCE/ANVIL_R6/`; its strict source/graph checks execute through `tools/r7_typed.py`. The authored R6 active machinery remains present, with newer R7 only as the selection front door. No silent degradation of either version's valid behavior.
4. **Single current instruction:** **this file → `25_R7_OPERATIONAL_COMPETITION.md` → relevant R7 role prompt → R7 machine policy/tests.** R5/R6 instructions, anthologies, review maps and examples explain history, but their conflicting stage labels or weaker comparator cannot override the R7 decision protocol. Do not amend a long inherited prompt; edit the controlling R7 document directly when a legitimate repair is justified.
5. **Distinct authority:** authored code+tests ≠ scientific issuer, source permission, independent C, actual host runner, owner grant, protected CAS, genuine performance or current Git state. A structural comparator's `winner` is **provisional arithmetic at its declared receipt content**, never accreditation.

## Executable entrypoints

```bash
python3 tools/run_r7_quality.py
python3 tools/r7_decision.py compare MEASUREMENTS.json FROZEN.json --evidence-root RUN_RECEIPTS/
python3 tools/r7_decision.py check-decisions PHYSICAL_DECISIONS.json MEASUREMENTS.json FROZEN.json --evidence-root RUN_RECEIPTS/
python3 tools/r7_stage.py P15 P15.json --evidence-root RUN_RECEIPTS/
python3 tools/r7_stage.py C C.json --evidence-root RUN_RECEIPTS/ --source-root EXACT_REPO_CHECKOUT/
python3 tools/r7_stage.py H1 H1.json --evidence-root RUN_RECEIPTS/
```

The last H1 command **cannot** grant protected receiving from local assertions. An actual qualified owner must authenticate live GitHub receiving and update the existing PROGRAMMA/paired CURRENT_PROGRESS via authorized CAS. For any code route where source snapshot rights/runner are unavailable, hold the exact grade and continue independently lawful work.

## Mandatory terminal decision form

Answer: **(i) what is the best feasible current design, (ii) why the strongest rival loses at the claimed consumer/workload scope, (iii) which real hard feasibility/source-semantic veto each surviving design passes or fails, (iv) exactly what original R5/K3 function/negative/owner is preserved and used, (v) what subsequent builder/first reader must do, and (vi) which genuinely decision-reversing uncertainty remains.**

If an important uncertainty survives, return `CONDITIONAL_CANDIDATE`/`DECISION_BLOCKED_EXACT` with a real independently checkable material advance or `NO_NEW_PRODUCT_ADVANCE`; do **not** award an incumbent victory by lack of B evidence. Separate documentary/design readiness from execution, native source law, original35 and protected adoption.

**Finite workflow:** H0 exact currentness/authority freeze → independent A and B → one reciprocal challenge → P1.5 smallest lawful matched discriminator → P2 one whole-machine synthesis/physical-decision ledger → distinct independent C (including strongest surviving reverser and real builder) → competent H1 external owner receiving. No new fleet, K3 rerun, source recensus, algorithmic bakeoff for fashion, or replacement SOROK theory.
