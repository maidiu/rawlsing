# ANVIL R7 — COMPLETE ACTIVE CAMPAIGN AND ALL FIVE CONTROLLING MESSAGES

This is the unified R7 operating text. R5/R6 remain source references and regression baselines but older launch-message conflicts do not govern R7. No GitHub/owner/runner rights are created by this artifact.


---

## File: 00_R7_READ_FIRST.md

# ANVIL R7 — single controlling entrypoint

**STATUS `R7_AUTHOR_PREPARED_LOCAL_TESTED__INDEPENDENT_C_AND_OWNER_RECEIVING_PENDING`.** This is a repaired **architecture-selection campaign**, not an executed Rawlsing architecture, new source issuer, production release, appointed PYAT HQ, independently accepted design, or permission to merge/dispatch. The exact R5, R6 and independent mainMAC R6 evidence is preserved inside this distribution.

## The non-negotiable mission

The mission is to select **one economically feasible, scientifically meaning-conserving, source-authenticated, reusable empirical pipeline**:

**lawfully qualified SAV/DTA → complete persistent source-direct thirteen-family C11 → verifiable fresh-process cold reads and economical 1/10/100 DISTINCT operations under ≤6 GiB whole process tree → respondent-coherent F1–F4 / shared conditionals, negatives, restart → meaningful actual first consumer (#998) → separately qualified Field Forge, world and actor possibilities.**

This is not a generic database tournament. Its final downstream purpose is a historically conditioned, independently acting person within a changing material and relational world, **not** a survey vector animated by an LLM. Conserve: source-native instrument semantics and languages; source/wave/country time; real individual vs household/roster grain and ordered/multiple responses; eligible/asked/released/observed/unobserved states; sample weights/design and distinct populations/risk/denominators; true same-respondent high-order joints, F2 in both directions, minority/recursive/contradiction exploration, full negative and restoration; empirical descriptions independent of actual material structural causal sources; qualified institutional/resource power, independently existing others and exogenous world events; SOROK's separate actor development, incomplete knowledge, contradictory activity and no predetermined outcomes. Preserve optionality without inventing these later scientific rules today.

**Immediate work priority:** make generic C11 physically and economically operative under the real source and first-reader constraints, with a third-family independent falsifier; DO NOT force all 35 sources, full FF/SEAM/SOROK invention, or historical K4 before this. A lawful P0 engineering correction can proceed when an unrelated science/actor owner is held.

## Authority and version law

1. **Foundation:** PYAT HQ Nov 16 14:42 checkpoint, original ANVIL #1108 mandate and #1097/#960 operating programme, PRE-MAIN PROGRAMMA + OATH and paired CURRENT_PROGRESS, adopted historical five-test rule, MCR-lite. A historical checkpoint explains the mission; it does not overrule later competent receiving.
2. **Later verified documentary change:** as checked during R7 preparation, protected PRE-MAIN at `7fc00289dd801d2d0a8ce159986c7595fc27a4d9` received K3 29 historical families, 26 prospective proposals ALL **NOT_ADOPTED**, and 14 exact proof obligations still **HELD**, at S0–S1 with disclosed failing CI, progress revision 9. Recheck **live HEAD** at H0. This is not science/native/actor accreditation.
3. **Historical conservation:** frozen 45-file R5 including its intact manifest (`R5_BASELINE/`) and *all six executable projections* remain reachable; 44 R5 payload hashes exact. R5/R6 legacy APIs remain for historical scope but **cannot confer R7 selection**. MainMAC R6's 33 source payloads remain verifiable in `MAINMAC_R6_REFERENCE/ANVIL_R6/`; its strict source/graph checks execute through `tools/r7_typed.py`. The authored R6 active machinery remains present, with newer R7 only as the selection front door. No silent degradation of either version's valid behavior.
4. **Single current instruction:** **this file → `25_R7_OPERATIONAL_COMPETITION.md` → relevant R7 role prompt → R7 machine policy/tests.** R5/R6 instructions, anthologies, review maps and examples explain history, but their conflicting stage labels or weaker comparator cannot override the R7 decision protocol. Do not amend a long inherited prompt; edit the controlling R7 document directly when a legitimate repair is justified.
5. **Distinct authority:** authored code+tests ≠ scientific issuer, source permission, independent C, actual host runner, owner grant, protected CAS, genuine performance or current Git state. A structural comparator's `winner` is **provisional arithmetic at its declared receipt content**, never accreditation.

## Executable entrypoints

```bash
python3 tools/run_r7_quality.py
python3 tools/r7_decision.py compare MEASUREMENTS.json FROZEN.json --evidence-root RUN_RECEIPTS/
python3 tools/r7_decision.py check-decisions PHYSICAL_DECISIONS.json MEASUREMENTS.json FROZEN.json --evidence-root RUN_RECEIPTS/
python3 tools/r7_stage.py P15 P15.json --evidence-root RUN_RECEIPTS/
python3 tools/r7_stage.py C C.json --evidence-root RUN_RECEIPTS/ --source-root EXACT_REPO_CHECKOUT/
python3 tools/r7_stage.py H1 H1.json --evidence-root RUN_RECEIPTS/
```

The last H1 command **cannot** grant protected receiving from local assertions. An actual qualified owner must authenticate live GitHub receiving and update the existing PROGRAMMA/paired CURRENT_PROGRESS via authorized CAS. For any code route where source snapshot rights/runner are unavailable, hold the exact grade and continue independently lawful work.

## Mandatory terminal decision form

Answer: **(i) what is the best feasible current design, (ii) why the strongest rival loses at the claimed consumer/workload scope, (iii) which real hard feasibility/source-semantic veto each surviving design passes or fails, (iv) exactly what original R5/K3 function/negative/owner is preserved and used, (v) what subsequent builder/first reader must do, and (vi) which genuinely decision-reversing uncertainty remains.**

If an important uncertainty survives, return `CONDITIONAL_CANDIDATE`/`DECISION_BLOCKED_EXACT` with a real independently checkable material advance or `NO_NEW_PRODUCT_ADVANCE`; do **not** award an incumbent victory by lack of B evidence. Separate documentary/design readiness from execution, native source law, original35 and protected adoption.

**Finite workflow:** H0 exact currentness/authority freeze → independent A and B → one reciprocal challenge → P1.5 smallest lawful matched discriminator → P2 one whole-machine synthesis/physical-decision ledger → distinct independent C (including strongest surviving reverser and real builder) → competent H1 external owner receiving. No new fleet, K3 rerun, source recensus, algorithmic bakeoff for fashion, or replacement SOROK theory.


---

## File: 25_R7_OPERATIONAL_COMPETITION.md

# R7 operational competition, evidence and receiving law

## H0 — competent controlling authority, source and measurement freeze

Before work, read the canonical PYAT PROGRAMMA OATH and live paired CURRENT_PROGRESS; reconcile protected PRE-MAIN, controlling #1097/#960/#1108/#1133 and current actual code heads/independent grades/leases. The last verified checkpoint in the predecessor analysis is **7fc00289dd801d2d0a8ce159986c7595fc27a4d9** but must not be passed off as newly current. Distinguish full GitHub native owner readback, sourcefree acceptance, unresolved failing CI, external worker runtime and user-authorized branch rights. Do not create HQ authority by preparing ANVIL.

Freeze one real first consumer and actual lawfully available 13-family source path. Freeze the **material comparison floor** `24_R7_MACHINE_POLICY.json` with a concrete seven-shape, repeated/cold real-width geometry, source/rights/first consumer, A/B code and input cuts, honest performed runner type, negative/restore, 6GiB process-tree ceiling. 100k respondents with 3.245 sparse events is NOT dense 600-opportunity respondent width. Source-native physical proof remains source-owner held until granted. Hard limits beyond 6GiB, if any, need owner-specific evidence; do not fabricate latency/disk ceilings.

Every numeric comparator result MUST be reproducible from typed **per-side, per-cell** `ANVIL_R7_MEASUREMENT_RECEIPT` JSON bytes, exact SHA-256, metric unit, interval and geometry. Every nonnumeric hard veto requires separate candidate-specific `ANVIL_R7_VETO_RECEIPT` and source/negative/first-consumer refs. Any displayed advantage not equal to its receipt contents is invalid. Hash-consistent receipts remain **self-described** until the actual runner and independent reviewer authenticate their origin and validity.

### B-discovered materiality and scope

B may establish that a frozen material frame omitted a genuinely outcome-reversing discriminator, e.g. incremental conditional-population invalidation. No after-result goalpost change; no deletion of earlier measurement. Under `tools/r7_decision.py`, an additive versioned before-first-result plan must point at a SHA-matched parent, preserve all old cells, establish a new typed unit and exact B challenge, and carry a C review receipt. A discovered but unmeasured or owner-held discriminator leaves the choice conditional. The R7 machine floor is a **minimum**, not a prohibition on discovering better questions.

No exclusion can by itself prove whole-scope dominance. A legitimately excluded case may yield a **scoped, conditional** conclusion only after B/C and competent owner examine its reversal risk; it cannot be hidden behind long prose. B and C independently question dense geometry, 1/10/100 distinct operations, source meaning, larger repeated operation sets, cold rebuild, hard RSS, retained and scratch disk, cross-world reusable cohorts and actual F1–F4/first-reader effects.

## A — strongest incumbent; B — strongest genuine alternative

A starts from accepted October 28 S2-B/C/D/E, existing saved full C11 direct Parquet/Zstd, native I03, #997/#1006 corrective work, #1103 prepared-session candidate and current actual first-reader. A must not regress source proof or confuse original `body_json`+typed columns, intermediary 13 JSONL journals, old full-object W03 with a single current engine.

B independently starts from **full reverse requirements**: SEAM/26/ANVIL/15, #998/#1009/#1011, historic V549/V550J and K3 functional conservation. It must propose a technically distinguishable executable architecture and expose missing material discriminators rather than merely criticize A. Allow any lawful reuse/adapt/compose, not automatic DuckDB/SQLite/Arrow fashion. A/B authors freeze their own first return before reading substantive opponent results, then one reciprocal challenge only.

## P1.5 — cannot manufacture a decisive result

`tools/r7_stage.py` reads the actual frozen plan and exact input files, recomputes the R7 comparator, checks **all** material cells and permits only a *provisional* matched decisive result. It does not accept a worker's `decision_reverser=false` flag, an invented `runner_receipts` string or a free-text comparator status. If B is unmeasured, an important interval overlaps, a hard veto is failed/held, a C-qualifiable exclusion is pending or an additional B discriminator is unresolved, record exact hold. An unmeasured B is not a defeated B. Use one authorized bounded disposable proof if needed, not two fully built backends.

## P2 — one coherent physical system, not a favorable component benchmark

Bind the **complete R5/R6 SPINE** with all 118 historical ID source meaning/negative/consumer rows, authority/epistemic case, five future paths, six deterministic R5 projections and transitive impact tool. Add `ANVIL_R7_PHYSICAL_DECISION_LEDGER` for **each** material physical choice with selected candidate, existing inherited R5 physical decision ID(s), DAG dependencies, class-specific workload×metric cells, actual first consumer, typed source-semantic effect, negative/restore and source/actor veto. An unknown dependency or storage choice borrowing build-only data fails. Every new choice must be separately justifiable; if a necessary metric is unavailable, hold that choice, not the whole project indiscriminately.

Selection is not the end of construction: P2 explicitly distinguishes (a) executable current consumer, (b) source-static construction specification, (c) reversible future nonpreclusion and (d) future scientific/actor owner-held law. Preserve original source/instrument/weight/time, independent material structural observations, legitimate surrounding-person positions, exogenous world events, actor activity/knowledge/retrospective narration separately. No survey answer becomes private motive or structural cause by diagram.

## C — separately independent, hostile and builder-oriented

C reopens the actual source HEAD/rights, real hardware and metric receipts, typed claims/whole-machine graph (`tools/r7_typed.py`), full legacy SPINE semantics (`r5_contract.py` + `anvil.py`), every physical choice, and the two builder cards. Source-static builder must point to **existing producer and consumer symbols**, actual pinned source root, explicit test command and complete operation ABI; any missing symbol is a HOLD. Executed-first-reader proof additionally needs exact test output, negative/refusal and restoration evidence; no source-static proof promoted into an executed one.

C's culminating adversarial question is **“What is the strongest architectural objection that survives all comparisons, and could its truth change the selected architecture at the claimed scope?”** A YES blocks unconditional selection. A NO requires specific evidence—not a confidence adjective. The local C validator can check payload integrity and typology, not reviewer independence, consent, source science or runner authenticity. C is genuinely independent only after external reviewer/owner verification, never by `reviewer_relationship` text alone.

## H1 — independent external competent receiving

The local H1 checker deliberately refuses to authenticate an alleged protected CAS from self-generated JSON. A competent owner must establish exact live protected ref, independently received C/P2 cut, valid external source/runner/lease/science scope, and one authorized paired CURRENT_PROGRESS MD/JSON update. The owner may accept a **scoped design** without pretending a completed physical build, a **conditional engineering advance** only with an independently verified useful first-consumer change or narrower executable blocker, or an exact HOLD. This architecture inquiry cannot independently mint source rights, experimental causal rules, actual actor grants or protected merges.

## Stop rule and MCR-lite

Use the shortest finite real-work sequence. Every intervention must retain existing source evidence, meaningful negatives and a real later consumer. Current accepted sourcefree engineering remains accepted sourcefree, even if original-source permission is held. Once R7's substantive architecture contest has a valid result, **stop designing competitions and build the selected engine** under proper owner rights. If evidence cannot determine a winner, return the exact falsifier and permit lawful P0 work rather than generating another campaign constitution.


---

## File: 26_R7_NO_LOSS_AND_FAILURE_DISPOSITIONS.md

# R7 conservation and failure-disposition law

## No-loss requirement: value and functionality, not merely archived bytes

**Literal historic retention is necessary but insufficient.** R7 retains all 45 R5 archive entries intact inside `R5_BASELINE/` including original 44 payload hashes and its original manifest; the six operative R5 deterministic outputs remain produced by the ACTIVE `tools/anvil.py`: `DESIGN_DECISION.md`, `COVERAGE_TO_DECISION.tsv` (118 records, *twelve* fields), `GLOBAL_ARCHITECTURE.json`, `BOUNDARY_TRACE.json`, `DOWNSTREAM_BUILD_HANDOFF.jsonl`, `EVIDENCE_AND_FALSIFIER_INDEX.jsonl`. `tools/impact.py` still computes transitive affected first consumers. All original R5 six suites run; active R6 extensions still run; the mainMAC R6 33 source payloads and 38-test suite are independently checkable and its strict typed graph/claim grammar is invoked by `tools/r7_typed.py`. None of those are replaced with an ID-only census or rendered files authenticated only by a user-editable subset manifest.

**Semantic conservation is operative:** each original K3 identity must retain current necessity, original source anchor/semantics, what is positive and negative, consumer or exact hold, architecture effect, evidence and precise decision. No newly adopted requirement or build ticket follows from missing historical crosslink. The governing five-test PYAT historical succession law must be applied for new work. Current K3 29/26/14 is protected at documentary S0–S1 only and cannot be silently promoted to source/native proof. Complete R5 machine inventories are inherited, not reopened as 118 commissions.

## What R5 could already do and what R7 must not weaken

| R5 function/value | Active R7 successor / evidence | What remains held |
|---|---|---|
| 118 exact inherited IDs with source semantics, negative and first consumer | unchanged `anvil.outputs`, `test_r7_conservation.py` checks field-level 118 rows | substantive equivalence to live code and newly selected first readers |
| Original R5 six deterministic projections and missing-output rejection | `anvil.py::outputs/check_dir`, six legacy suites | actual Git and owner evidence |
| Typed graph with source authority, future routes, negative, time, no premature actor promotion | `r5_contract.py`, `anvil.validate`, plus mainMAC strict `r7_typed.py` | actual SEAM/SOROK actor or structural science issuance |
| True high-order same-person F4, reverse F2, minority, recursive, distinct populations | original scientific contracts + strict R5 spine | real selected wave and genuinely executed FF first effect |
| Full-workload A/B and overlap/tie rule, seven workload families, cold/1/10/100, RSS, retained/scratch | R7 floor and per-side typed receipts, source width geometry, hard veto first, uncertain hold | real full-width runner and independent G5 |
| B independent frame challenge, one reciprocal round, bounded probe, non-selected future extension | R7 parent-linked pre-result amendment, original stage order | separate owner selection and C review |
| Original R5 provenance facets/claim levels, source/household/observer and time splits | R5 active guards + mainMAC `validate_source_claim` and R7 C typed proof | authentic sources and crosswave permission |
| R5 distinct current-builder vs future-builder grade, source-static vs executed | `r7_stage.py`, actual symbol check when checkout available, execution receipt readback | external distinct builder/owner test acceptance |
| R5 transitive dependency impact (not just direct links) | unchanged active `tools/impact.py` and negative coverage test | omitted semantic edges still independently challenged |
| Evidence-linked material product advance, no paperwork-only escape | R5/R6 full spine checks and C/H1 independent material delta demand | original executable consumer causality authenticated by reviewer |

## The hostile findings and their proper causal classification

| Reproduced issue | R5 antecedent? | R6 condition | R7 treatment |
|---|---|---|---|
| Wrong whole-set victory with 7 build-only metrics or 6 exclusions | R5 clear pre-existing defect | R6 both substantially repaired | mandatory material *workload × metric* floor; no full victory with exclusions |
| Neither candidate fits 6 GiB, yet A declared winner | R5 trusted asserted hard veto rather than measuring one | inherited by BOTH R6 editions | derives per-side feasibility from validated RSS receipt intervals; both fail means neither wins; crossing ceiling HOLDS |
| Measure JSON can reverse winner while receipts unchanged | R5 no numeric content authentication | ChatGPT R6 checked files but not their numbers; mainMAC mostly metadata | exact typed per-side metric/unit/value/interval/geometry equality against SHA read receipts |
| Fabricated original observation, household person or forbidden time/actor route | R5 genuine weakness | both editions improved different axes | preserve BOTH R5 scientific grammar and mainMAC stricter claim/graph validation, require at C |
| Physical storage borrowing unrelated benchmark or nonexistent dependency | R5 lacked complete physical decision closure | mainMAC R6 still bypassable; ChatGPT partial | one typed physical decision DAG, exact existing dependency IDs and mandatory affected case × metric cells, R5 original decision inheritance |
| P1.5 invents decisive comparison | R5 self-descriptive stage trust | ChatGPT R6 still bypassable | P15 reads exact full R7 comparator/input files and verifies provisional result |
| C/H1 selfdeclare source/runner/builder/owner evidence | R5 source-static boundaries articulated but incompletely enforced | mainMAC C/H1 bypass and ChatGPT H1 partial | read all exact bytes, validate actual producer/consumer symbols where ready, never locally certify independent C/protected H1 |
| mainMAC R6 loses original source-semantic projections and transitive impact | R5 **did** provide them | mainMAC regression | R5 renderer/impact kept as **active**; 118 semantic fields and output completeness verified |
| My R6 ZIP lacked R5 manifest and had stale final hashes | R5 package clean | **new author delivery regression** | restore R5 MANIFEST and require clean-extraction manifest and tests before release |
| Unknown material discriminator cannot alter frozen experiment | R5 closed comparator | both R6 editions permitted partial challenge | pre-result parent-linked additive B discriminator, new metric unit, C review and original cell preservation |
| Source static facts declared physically or scientifically executed | perennial grade-risk | both R6 better but author flags still could mislead | local verdicts explicitly `PROVISIONAL`/`PENDING_EXTERNAL`, H1 impossible through self-attestation |

## Permanently held and separate

Source-native original35 release, Arabic/WVS/third native science; survey sampling, weights, original source-specific ontology; F6 quantified uncertainty and F7 observed comparable time; FF02 independently sourced power mechanisms; N9/N10W world conditions; SOROK actor action/identity/Absolute Horizon, differentiated parent histories and a user's limited gaze, consent and independent agency; independent review/host lease; and protected PRE-MAIN receiving. These are **not** new C11 columns or global P0 engineering blockers where information and valid sourcefree operations can proceed. Their current evidence and source cuts must be rechecked at real implementation time.

## Explicit execution economy

No K1–K3 archaeology; no 35-source bulk requirement; no additional architecture fleet; no ongoing review of unchanged historical acceptance; no preferred database for status; no false 100k from 3.245 events/respondent; no fictional motive from a survey respondent; no future SOROK rules invented by a C11 engineer. Historical code is a comparison/oracle candidate, not automatic implementation. R7's only new machinery is what closes independently demonstrated decision gaps and preserves the effective value inherited from either R6.


---

## File: 27_R7_VALIDATION_AND_SCOPE.md

# R7 validation and receiving boundaries

**Source-grade:** all executable fixtures are local synthetic/structural, including fully constructed typed synthetic measurement receipts; there is no original survey access, real full-width 100k/6GiB source-native execution, independent nonauthor review, actual authenticated host lease, selected C11 architecture, or protected receiving in this package.

## Reproduced hostile failures and actual corrections

- Both contenders >6 GiB: hard feasibility reads each candidate's **actual source/geometry/head-bound receipt** `low,value,high`; two candidates above ⇒ `BOTH_INFEASIBLE`, winner null. A alone >6 GiB ⇒ only B feasible at measured scope; crossing ceiling ⇒ hold; no selfdeclared PASS override.
- Change a reported interval while keeping every receipt byte+SHA unchanged ⇒ `R7_MEASUREMENT_NOT_BOUND_TO_RECEIPT` and RED; change receipt bytes while keeping SHA ⇒ RED; change code head or input/width geometry ⇒ RED. Synthetic receipt contents still do not prove actual host execution.
- Remove a material comparison cell, remove B measurements, exclude many cases, insert unresolved high-importance B challenge, overlap intervals or change frozen digest ⇒ no full-scope winner. B can add a new material metric before first results only via parent-linked immutable version, new typed unit and independent-C review payload (still externally authenticatable).
- Physical decision's nonexistent dependency, borrowed build-only metric, missing case×metric, orphan inherited R5 physical decision or cycle ⇒ RED. This binds every material selection to the observed whole-machine dependency and actual first-reader analysis, subject to further C substantive scrutiny.
- P15 free-text result cannot override actual recomputed comparator; nonexistent receipts and fabricated winner fail. C requires actual matched P15/P2/typed source-graph/decision receipts and existing source symbols for a builder-ready statement; H1 protected receiving always requires external authenticated CAS and cannot be minted locally.
- Original source meaning/negative/consumer fields and six R5 generated projections are still executable. Delete `COVERAGE_TO_DECISION.tsv` without updating SPINE ⇒ R5 deterministic `check_dir` rejects. MainMAC's typed claim/graph rules also run and reject household/person, unobserved original claim, false wave semantics and world-to-actor spoof.

## Tests and exact limits

Use `python3 tools/run_r7_quality.py` from root and inspect `tests/R7_QUALITY_REPORT.json`. It executes the inherited R5/R6 nine local commands, mainMAC's original preflight and 38-suite, four new R7 suites (receipt/decision DAG, P15/C/H1 gates, typed provenance/graph, and functional conservation). Positive synthetic comparisons exist for A and B, an additive pre-result B metric, a complete synthetic P15/C first-reader fixture and inherited full-SPINE. Every local PASS is explicitly **structural**, without scientific, source, runner or actor accreditation.

**Known limits not reducible to file hashes:** semantic validity of country/wave/translation/weights, real respondent-grain source access, independent C's human/agent identity, actual processes behind claimed measurements, previously unimagined cost dependencies, source-native continuity and protected CAS. R7's controls disallow selfcertifying these; independent knowledgeable owners must evaluate them using live sources/host and first consumers. R7 does not simulate signatures or make user-supplied receipts truth by fiat.

**No value/function loss:** `tools/test_r7_conservation.py` checks original 44 payload hashes and all 33 mainMAC payload hashes, the six original semantic outputs and 118 nonempty source/negative/consumer entries, missing-output rejection, transitive impact and K3 nonadopted/held counts. The original R5 tests and mainMAC 38 tests execute directly. This is more than a backup but less than a live semantic parity accreditation.

**Independent next step:** subject the packaged candidate to a truly separate adversarial code/contract review, then competent PYAT authority can dispatch A/B if source rights, current HEADs, leases and the material H0 scope are satisfied. Do not assume a protected merge or operating readiness from this package.


---

## File: prompts/00_H0_CODEX_CONTROLLER.md

# ANVIL R7 — Codex HQ / H0 / P2 controller

**MCR: LITE. Entry:** `00_R7_READ_FIRST.md`, `25_R7_OPERATIONAL_COMPETITION.md`, `24_R7_MACHINE_POLICY.json`, original mandate `12_ORIGINAL_MANDATE_AND_DECISION_LEVERAGE.md`, live #1097/#960/#1108 and SEAM incoming #1133. No self-appointed PYAT authority. Read canonical PROGRAMMA HQ OATH and latest protected paired CURRENT_PROGRESS first.

**Mission:** determine the best *feasible* complete source-qualified 13-family C11 → cold real-width 1/10/100 distinct F1–F4 machine → actual first consumer and nonprecluded historical/social world/actor route. Preserve every material R5 capability and future scientific requirement. Do not choose a storage fashion; compare one strongest incumbent adaptation A with one genuinely independent B, one challenge, at most one bounded decisive falsifier and C receiving. K3 29/26/14 documentary received at `7fc00289…` as of the last checked cut; recheck before work, no K3 re-mining/K4 by default.

**H0 action:** independently verify HEADs, origin/rights, source geometry, honest current S01–S05 grades, owner and host leases, relevant existing #997/#1006/#998/#1009/#1011 source/consumer interfaces. Freeze selected actual first consumer, original source/instrument/routing/weights/identity/negative, A/B code heads, same frozen input hash+width+population+event geometry, exact capacity limits. Provide an explicit B-visible floor including build, cold, query1/10/100, RSS ≤6GiB entire process tree, retained and scratch, true F4/semantic and world nonpreclusion vetoes. Do not promote 3.245 events/respondent as full width; keep real 100k dense tests for authorized host. Establish and hash an H0 R7 frozen plan and physical decision ledger skeleton; classify source/owner-held fields honestly.

**Dispatch:** A and B receive the same frozen H0 constitution and allowed source cuts, no opponent findings before their P0 freeze. Each must return runnable whole-machine arrangement, concrete true first consumer, invalidation/rollback/rights, actual chosen data/measurement paths and minimal decision-reversing experiment. One reciprocal challenge only. If B supplies a new material metric, use versioned pre-result parent-linked amendment and C qualifying challenge; never suppress to preserve the first H0 frame.

**P1.5/P2:** the actual data comes through `tools/r7_decision.py`; never take the older `compare_candidates.py`, `r6_comparator.py` or mainMAC `r6.py` as the R7 verdict. R7 P15 verifies exact frozen input and receipt contents; a numerical winner is **provisional** pending independent runner/science/C. Bind EVERY material physical decision, not only one, to required exact workload×metric cells, existing dependency DAG, negatives, downstream effects and real first consumer; preserve `tools/anvil.py` six complete deterministic R5 outputs and `tools/impact.py` transitively. Produce one complete `ANVIL_SPINE_R6` (fully legacy-functional), R7 decision ledger, typed boundary/graph witness, receipts, both current and future builder cards and exact holds.

**No premature authority:** sourcefree author tests do not become original35/native, independent G5, source law, actor permissions or protected receiving. If any material reverser is still plausible, hold the architectural winner, name the smallest lawful probe, and let already authorized P0 work proceed. Do not spawn new K3 fleets, new SOROK science, a production bakeoff, or protected edits without existing competent rights. One subsequent truly independent C, then competent external H1.

**Terminal return:** exact Git source/PR/branch/head and lease evidence, runnable sourcefree or native proof grades, candidate-specific hard vetoes, full case×metric receipts and hashes, A/B comparison, physical decision DAG, six R5 semantic outputs, strongest surviving objection, first builder with actual symbols and test, two relevant future-source holds, owner actions, no cosmetic paperwork progress, honest scope. See `tools/r7_stage.py` for P15/C local readback; it explicitly refuses protected H1 accreditation.


---

## File: prompts/01_ARCHITECT_A.md

# ANVIL R7 — DeepSeek A, strongest current-engine adaptation

**MCR: LITE · Independent A0:** Read `00_R7_READ_FIRST.md`, `25_R7_OPERATIONAL_COMPETITION.md`, `24_R7_MACHINE_POLICY.json`, R5 original `12_ORIGINAL_MANDATE_AND_DECISION_LEVERAGE.md`, active `tools/anvil.py`, `tools/impact.py`, current #1097/#960/#997/#1006/#998. Use immutable H0 source and candidate heads. Do not read B substantive work until A0 is frozen.

**Build the strongest actual architecture**, not an argument for the incumbent. Reuse accepted sourcefree S2-C/D full 13-family Parquet/Zstd where economical, direct source→C11 qualified projection, native cold I03, actual grouped negative and output/restore. Investigate exactly where old JSONL staging, typed+`body_json`, cold hash, temp SQLite per-session index and preparatory repeated population masks multiply read/build costs. A correct sparse 100k test is not dense questionnaire proof. Do not assume existing building blocks are already production-qualified or wrong merely because current cold query is expensive.

**Required present scope:** one authorized generic SAV/DTA path; original native question/variable/code/routing/absent states; country/wave/source and design/weights; respondent and household distinct; ordered/repeated/multiple events and true same-person k≥3 joints; F2 both directions with correct denominators; F3 minority/recursive/branch evidence; semantic negative/refusal/revocation and restore; 1/10/100 DISTINCT query economics, full process tree ≤6GiB, retained/scratch/cold source reads, actual sourcefree first reader #998. No all35 first, no FF02 or Sorok psychology invention.

**Beyond present:** conserve independent observed material power, surrounding social fields/others, world as-of/time, exogenous events, actor's separately owned activity and inaccessible private motives without embedding them in C11 or asserting survey response = psychology. Cite SEAM incoming #1133 and R5 full future paths. A source static extension is NOT an executed actor first effect.

**Return A0:** exact actual code functions/ABIs and SHA, source and runner permission grade, one whole-machine physical candidate plus immutable source-preserving transformations, realistic resource/cost model and explicit first consumer. List specific ways B can win and which missing test would reverse your choice. Supply hash-pinned proposed comparator receipts only for runs genuinely executed under valid host; otherwise `UNRUN_HELD`. Do not use old R5 comparator as proof. No PR launch/merge by writing this document. After B0 freeze, exactly one reciprocal challenge and bounded response.


---

## File: prompts/02_ARCHITECT_B.md

# ANVIL R7 — Independent DeepSeek B, true rival and frame challenger

**MCR: LITE · Independent B0:** Read `00_R7_READ_FIRST.md`, `25_R7_OPERATIONAL_COMPETITION.md`, the exact H0 constitution and the full R5 legacy function/negative/consumer outputs. Start from actual downstream needs and source loss, **not** A's architecture. Do not see A0 substantive findings until both A0/B0 are frozen.

**Mission:** find the strongest feasible alternative to current source→sealed complete C11→cold 1/10/100→F1–F4/real first-reader engineering. Build a technically different credible machine from existing legal components, not a generic opposition essay. Treat source semantics/instrument/routing/weights/identity/true k-way joint and time as hard vetoes; preserve the useful historical pre-FORGE DDM's respondent-wide pattern, recursive/conditional and minority capabilities without restoring known code bugs.

**Independent reverse path:** SEAM/26 and ANVIL/15 require full position-conditioned social configurations and differently situated others, with separately qualified material resource/institutional relations and real world/actor/time constraints. The respondent's measured position is not a child's fate; structural power does not follow from popularity; actor perception, acquired identification, alienation and independent activity remain SOROK-owned. A future nonpreclusion claim must identify preserved information and workable owner/first-consumer path, not simply graph connectivity.

**Challenge H0 itself:** is the decisive cost actually cold query latency, durable population membership construction, branch invalidation across new conditions, full-width first-reader output or another legitimate discriminator? If H0 omitted an outcome-reversing metric, specify it with source/consumer causality, challenger evidence, minimal lawful matched measurement and exact `B_discriminators` pre-result amendment. No opportunistic post-result scope changes. Real source permission holds must be honest and need not block independent lawful sourcefree engineering.

**Return B0:** one coherent fully source-preserving rival, actual producer/consumer and code paths or precise required adapter, matched workload/cost model, source-native and synthetic proof ceilings, construction hazards, explicit falsifier that might defeat A, and exact implementation reuse/no-build reasoning. Freeze B0; then one A/B reciprocal challenge, not a recurring fleet. A winning B must pass the same ≤6GiB whole process tree, 100k full-width, true same-person, scientific-semantic and world/actor no-premature-claim tests as A.


---

## File: prompts/03_INDEPENDENT_C.md

# ANVIL R7 — independent Browser C hostile receiving

**MCR: LITE · Requires genuinely distinct nonauthor reviewer.** Read `00_R7_READ_FIRST.md`, `25_R7_OPERATIONAL_COMPETITION.md`, both frozen A/B work, exact H0 and all versioned pre-result amendments, B's frame challenge, P1.5 actual receipts, final P2 full R5/R6 SPINE and R7 physical decision ledger. Check current Git/source owner rights independently; the R7 tool's local `PASS` is not your independent badge.

**Attack the thing that determines selection.** Recompute every measurement from exact typed receipt bytes. Change numeric JSON without changing receipt: reject. Change receipt bytes or runner geometry/head/input/source grade: reject. Make both exceed 6 GiB: neither wins. Introduce an unresolved high-materiality B metric or overlap: no A default. Exclude six workloads: cannot claim full-set superiority. Make a storage decision borrow one index benchmark or reference nonexistent dependency: reject. Probe a prior legal R5 output/negative/first consumer and compute transitive impact; absence is no-loss defect, not mere documentary variance.

**Attack scientific boundaries.** Value not observed/asked/released, modeled or design-only sect/race/ancestry turned into an individual value, household versus respondent, original code/meaning/translation, crosswave comparison without authority, respondent co-occurrence called structural cause, majority support called hegemony, adult observation time treated as childhood, future SOROK actor psyche inferred from source. Use a new unanticipated instrument/interpretation case, not only the original four. Test independently sourced material world and independent exogenous world events, other positioned persons, actual actor/world/historical time paths and no false `SRC→C11` future route.

**Attack construction.** Open the actual first consumer producer and receiver symbols at frozen code head; validate exact ABI and negative/restart test, actual cash/CPU/disk/RSS and sequence; distinguish `SPECIFICATION_CONSTRUCTION_READY` from `EXECUTED_FIRST_READER_PROOF` and future `EXACT_BUILDER_HOLD`. The local `tools/r7_stage.py C ... --source-root CHECKOUT` verifies syntax and readback, not that the builder can implement or that you are independent; you must test or issue exact external hold. Try deleting `COVERAGE_TO_DECISION.tsv`: R5 `anvil.check_dir` must fail. Make C/H1 accept fabricated C/P2/CAS receipt names: reject.

**The final mandatory question:** **What is the strongest architecture objection that survived all completed tests, and could its truth reverse the selected whole-machine design at its claimed scope?** If yes, a conditional/blocked verdict is compulsory. If no, justify with exact source/test/first-consumer evidence, not an empty claim. Preserve no-paperwork-only product delta, original 118-row source semantics and historical five-test work law. No K3 restart, invented SOROK science, source rights, actor permission or owner CAS.

**Return one finite independent verdict:** `C_ACCEPT_SCOPED` only at actually authenticated scope, `C_ACCEPT_DOCUMENTARY_HOLD` with exact decision reverser and genuine verified material advance, `C_REVISE_EXACT_DEFECTS`, or `C_DECISION_BLOCKED_EXACT`. Include exact heads, all G1–G5/source/runner/actor rights, first reader and builder tests, adversarial negatives and future authorizations still held. Do not manufacture accreditation by placing your name in JSON.


---

## File: prompts/04_H1_OWNER_RECEIVING.md

# ANVIL R7 — qualified PYAT H1 owner receiving

**Not a ChatGPT-local structural gate.** H1 requires independent, qualified live owner authority and actual protected paired CAS, not a forged `protected_received_YN=YES`. Begin with canonical PROGRAMMA HQ OATH, live PRE-MAIN HEAD, current PROGRAMMA/CURRENT_PROGRESS MD+JSON, actually independent C cut, source/science/actor rights and actual selected original/fixture execution. External currentness outranks the last Nov16 7fc baseline. No automatic merge, no unqualified source-native or actor scientific adoption.

1. Verify exact current A/B/H0/P1.5/P2/C HEADs, C's separate status, source/rights and real runner evidence, measured full-width 100k/6GiB economic scope, six legacy outputs, genuinely useful first consumer, complete physical decision/negative/dependency graph and hard/uncertain competitor disposition.
2. If the choice is well supported, accept only the demonstrated **architecture and engineering/scientific/source/actor grade**. A scoped DESIGN_READY is not production, an executable first reader is not source-native science, and a future nonpreclusion path is not a performed SOROK person.
3. If uncertainty genuinely reverses selection, hold that decision and name the smallest authorized falsifier while lawful existing source→C11 work progresses. `NO_NEW_PRODUCT_ADVANCE` is a permissible honest failure; it cannot be dressed up as useful narrowing absent independently checked before/after first-consumer evidence.
4. Only competent receiving updates the **existing** PROGRAMMA and paired CURRENT_PROGRESS via exact non-force CAS, with independent review and post-CAS readback; do not invent an extra status bank or appoint a new HQ. Disclose red CI and unfinished obligations without false GREEN.

`tools/r7_stage.py H1` deliberately **rejects self-declared protected receiving**. It can precheck metadata and receipt integrity, but live CAS/owner status requires external GitHub and source confirmation. The terminal handoff reports exact material acceptance, proof grade, no-loss comparison, first builder, unresolved owner holds and immediate next actual engineering work—not another R8 campaign.
